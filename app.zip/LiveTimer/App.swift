import SwiftUI
import ActivityKit
@main struct LiveTimerApp: App {
    var body: some Scene { WindowGroup { MainView() } }
}
struct MainView: View {
    @State private var status = "尚未启动"
    @State private var active = false
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                Image(systemName: "car.fill").font(.system(size: 48)).foregroundColor(.blue)
                Text("锁屏 · 灵动岛测试").font(.title2.bold())
                Text(status).font(.footnote).foregroundColor(.secondary).multilineTextAlignment(.center)
                Button("启动实时计时") { start() }
                    .buttonStyle(.borderedProminent).disabled(active)
                Button("结束实时计时") { stop() }
                    .buttonStyle(.bordered).disabled(!active)
                Text("启动后锁屏查看实时活动；长按灵动岛查看展开样式。测试完成后点击结束。")
                    .font(.footnote).foregroundColor(.secondary)
            }.padding().navigationTitle("实时活动测试")
                .onAppear { active = !Activity<TimerAttributes>.activities.isEmpty }
        }
    }
    func start() {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else {
            status = "系统未允许实时活动，请检查设置中的实时活动权限"; return
        }
        let start = Date()
        let state = TimerAttributes.ContentState(startedAt: start, endsAt: start.addingTimeInterval(30*60))
        do {
            _ = try Activity<TimerAttributes>.request(attributes: TimerAttributes(label: "发动机计时测试"), contentState: state, pushType: nil)
            active = true; status = "已请求启动，请查看锁屏和灵动岛"
        } catch { status = "启动失败：\(error.localizedDescription)" }
    }
    func stop() {
        Task {
            for item in Activity<TimerAttributes>.activities {
                await item.end(dismissalPolicy: .immediate)
            }
            await MainActor.run { active = false; status = "已结束" }
        }
    }
}
