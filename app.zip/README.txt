LiveTimer 1.0.0 / Build 1 - 独立 ActivityKit 验证工程
用途：验证 iOS 16.5 + TrollStore 安装的 IPA 是否可正常注册 WidgetKit Extension 和启动 Live Activity。
不是怠速记录正式版本，不包含怠速历史数据，不会更改原 App。
操作：用 BuildMate 编译本 ZIP -> 用 TrollStore 安装 -> 打开 App 点击启动 -> 锁屏观察 -> 查看灵动岛 -> 返回 App 点击结束。
注意：仅源码静态校验，未在 macOS/Xcode 真机编译。若编译工具未打包 PlugIns/*.appex，实时活动不会出现。
IPA 应包含 Payload/LiveTimer.app/PlugIns/LiveTimerWidget.appex。
