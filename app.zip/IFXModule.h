#import <Foundation/Foundation.h>
@interface IFXModule : NSObject
@property(nonatomic,copy,readonly) NSString *key;
- (instancetype)initWithKey:(NSString *)key;
- (void)start;
- (void)stop;
@end
