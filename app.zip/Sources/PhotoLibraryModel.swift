import Foundation
import Photos
import UIKit
import Vision

struct PhotoItem: Identifiable, Hashable {
    let id: String
    let asset: PHAsset
    let date: Date
    let width: Int
    let height: Int
    static func == (lhs: Self, rhs: Self) -> Bool { lhs.id == rhs.id }
    func hash(into hasher: inout Hasher) { hasher.combine(id) }
}

struct SimilarGroup: Identifiable {
    let id: String
    var items: [PhotoItem]
    var suggested: Set<String>
    var title: String { items.first?.date.formatted(date: .abbreviated, time: .shortened) ?? "相似照片" }
}

private struct PhotoDescriptor {
    let item: PhotoItem
    let feature: VNFeaturePrintObservation
    let hash: UInt64
    let quality: Double
    let faces: Int
}

@MainActor final class PhotoLibraryModel: ObservableObject {
    @Published var permission: PHAuthorizationStatus = PHPhotoLibrary.authorizationStatus(for: .readWrite)
    @Published var groups: [SimilarGroup] = []
    @Published var pending: Set<String> = []
    @Published var scannedCount = 0
    @Published var totalCount = 0
    @Published var progress = "尚未扫描"
    @Published var scanning = false
    @Published var errorMessage: String?
    @Published var scopeDays = 90
    @Published var sensitivity = 0.38
    @Published var photoMode = 0 // 0: 照片, 1: 人脸照片, 2: 截图
    @Published var crossDate = true
    private var scanTask: Task<Void, Never>?
    private let manager = PHCachingImageManager()
    private var itemIndex: [String: PhotoItem] = [:]

    func authorize() async {
        if permission == .notDetermined { permission = await PHPhotoLibrary.requestAuthorization(for: .readWrite) }
        else { permission = PHPhotoLibrary.authorizationStatus(for: .readWrite) }
    }
    func cancel() { scanTask?.cancel(); scanTask = nil; scanning = false; progress = "扫描已停止" }
    func startScan() {
        guard permission == .authorized || permission == .limited else { errorMessage = "请先允许访问照片"; return }
        cancel()
        scanning = true; groups = []; pending = []; scannedCount = 0; totalCount = 0
        progress = "读取照片列表…"
        let days = scopeDays, threshold = sensitivity, mode = photoMode, allowCrossDate = crossDate
        scanTask = Task { [weak self] in
            guard let self else { return }
            let options = PHFetchOptions()
            options.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: true)]
            if days > 0, let cutoff = Calendar.current.date(byAdding: .day, value: -days, to: Date()) {
                options.predicate = NSPredicate(format: "creationDate >= %@", cutoff as NSDate)
            }
            let result = PHAsset.fetchAssets(with: .image, options: options)
            var items: [PhotoItem] = []
            result.enumerateObjects { asset, _, _ in
                let screenshot = asset.mediaSubtypes.contains(.photoScreenshot)
                if (mode == 2) != screenshot { return }
                items.append(PhotoItem(id: asset.localIdentifier, asset: asset,
                                       date: asset.creationDate ?? .distantPast,
                                       width: asset.pixelWidth, height: asset.pixelHeight))
            }
            self.totalCount = items.count
            self.itemIndex = Dictionary(uniqueKeysWithValues: items.map { ($0.id, $0) })
            // Analyze each photo once. Vision works on reduced thumbnails to avoid retaining full originals.
            var descriptors: [PhotoDescriptor] = []
            for item in items {
                if Task.isCancelled { break }
                if let image = await self.thumbnail(for: item.asset, size: CGSize(width: 320, height: 320)),
                   let cg = image.cgImage {
                    let featureRequest = VNGenerateImageFeaturePrintRequest()
                    let faceRequest = VNDetectFaceRectanglesRequest()
                    if (try? VNImageRequestHandler(cgImage: cg).perform([featureRequest, faceRequest])) != nil,
                       let feature = featureRequest.results?.first {
                        let faces = faceRequest.results?.count ?? 0
                        if mode != 1 || faces > 0 {
                            descriptors.append(PhotoDescriptor(item: item, feature: feature,
                                hash: self.differenceHash(image), quality: self.quality(image), faces: faces))
                        }
                    }
                }
                self.scannedCount += 1
                if self.scannedCount % 8 == 0 || self.scannedCount == items.count {
                    self.progress = "提取照片特征：\(self.scannedCount)/\(items.count)"
                }
                if self.scannedCount % 12 == 0 { await Task.yield() }
            }
            if Task.isCancelled { self.scanning = false; return }
            self.progress = "正在寻找相似照片…"
            // Union-find: each photo belongs to at most one group. Time-neighbor matching plus
            // cross-date near-identical dHash matching; avoid comparing every pair of a large library.
            let n = descriptors.count
            var parent = Array(0..<n)
            func root(_ index: Int) -> Int {
                var i = index
                while parent[i] != i { i = parent[i] }
                return i
            }
            func merge(_ a: Int, _ b: Int) {
                let ra = root(a), rb = root(b)
                if ra != rb { parent[rb] = ra }
            }
            if n > 1 {
                for i in 1..<n {
                    if Task.isCancelled { break }
                    let a = descriptors[i]
                    var j = i - 1
                    // Up to 80 neighbors within 15 minutes: catches separate taps and short sessions.
                    while j >= 0 && i - j <= 80 && a.item.date.timeIntervalSince(descriptors[j].item.date) <= 900 {
                        let b = descriptors[j]
                        var distance: Float = 10
                        if (try? a.feature.computeDistance(&distance, to: b.feature)) != nil,
                           distance <= Float(threshold) { merge(i, j) }
                        j -= 1
                    }
                    if i % 30 == 0 { self.progress = "比对拍摄场景：\(i)/\(n)"; await Task.yield() }
                }
            }
            if allowCrossDate && !Task.isCancelled {
                // dHash bands create small candidate pools for cross-date near-identical images.
                // Exact hashes always share bands; near matches can share at least one band.
                var bands: [UInt64: [Int]] = [:]
                for i in descriptors.indices {
                    if Task.isCancelled { break }
                    let hash = descriptors[i].hash
                    for band in 0..<4 {
                        let key = UInt64(band) << 16 | ((hash >> UInt64(band * 16)) & 0xffff)
                        let candidates = bands[key] ?? []
                        for j in candidates.suffix(120) {
                            if descriptors[i].item.width == 0 || descriptors[j].item.width == 0 { continue }
                            let bits = (hash ^ descriptors[j].hash).nonzeroBitCount
                            if bits <= 4 {
                                let left = descriptors[i].item, right = descriptors[j].item
                                let ratioA = Double(left.width) / Double(max(left.height, 1))
                                let ratioB = Double(right.width) / Double(max(right.height, 1))
                                var distance: Float = 10
                                if abs(ratioA - ratioB) < 0.08,
                                   (try? descriptors[i].feature.computeDistance(&distance, to: descriptors[j].feature)) != nil,
                                   distance < 0.24 { merge(i, j) }
                            }
                        }
                        bands[key, default: []].append(i)
                    }
                    if i % 50 == 0 { self.progress = "检查跨日期重复：\(i)/\(n)"; await Task.yield() }
                }
            }
            var grouped: [Int: [Int]] = [:]
            if !Task.isCancelled {
                for i in descriptors.indices { grouped[root(i), default: []].append(i) }
                let output: [SimilarGroup] = grouped.values.compactMap { indices in
                    guard indices.count > 1 else { return nil }
                    let sorted = indices.sorted { descriptors[$0].item.date < descriptors[$1].item.date }
                    // Quality is a suggestion, not a deletion decision.
                    let best = indices.max { descriptors[$0].quality < descriptors[$1].quality }!
                    let members = sorted.map { descriptors[$0].item }
                    return SimilarGroup(id: members[0].id, items: members,
                                        suggested: [descriptors[best].item.id])
                }
                self.groups = output.sorted { $0.items.count > $1.items.count }
                self.progress = "完成：\(items.count) 张候选照片，发现 \(output.count) 组相似照片"
            }
            self.scanning = false
            self.scanTask = nil
        }
    }

    private func differenceHash(_ image: UIImage) -> UInt64 {
        guard let cg = image.cgImage else { return 0 }
        let w = 9, h = 8
        var pixels = [UInt8](repeating: 0, count: w * h)
        guard let ctx = CGContext(data: &pixels, width: w, height: h, bitsPerComponent: 8,
                                  bytesPerRow: w, space: CGColorSpaceCreateDeviceGray(),
                                  bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return 0 }
        ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
        var hash: UInt64 = 0
        for y in 0..<8 { for x in 0..<8 {
            if pixels[y * w + x] > pixels[y * w + x + 1] { hash |= UInt64(1) << UInt64(y * 8 + x) }
        }}
        return hash
    }
    private func quality(_ image: UIImage) -> Double {
        guard let cg = image.cgImage else { return 0 }
        let w = 64, h = 64
        var pixels = [UInt8](repeating: 0, count: w * h)
        guard let ctx = CGContext(data: &pixels, width: w, height: h, bitsPerComponent: 8,
                                  bytesPerRow: w, space: CGColorSpaceCreateDeviceGray(),
                                  bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return 0 }
        ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
        var edge = 0.0
        for y in 1..<(h - 1) { for x in 1..<(w - 1) {
            let p = y * w + x
            let lap = 4 * Int(pixels[p]) - Int(pixels[p-1]) - Int(pixels[p+1]) - Int(pixels[p-w]) - Int(pixels[p+w])
            edge += Double(lap * lap)
        }}
        return edge / Double((w - 2) * (h - 2))
    }
    func thumbnail(for asset: PHAsset, size: CGSize) async -> UIImage? {
        await withCheckedContinuation { continuation in
            let opts = PHImageRequestOptions()
            opts.deliveryMode = .highQualityFormat
            opts.resizeMode = .fast
            opts.isNetworkAccessAllowed = false
            opts.isSynchronous = true
            var image: UIImage?
            manager.requestImage(for: asset, targetSize: size, contentMode: .aspectFit, options: opts) { result, _ in image = result }
            continuation.resume(returning: image)
        }
    }
    func chooseKeep(_ id: String, groupID: String) {
        guard let i = groups.firstIndex(where: { $0.id == groupID }) else { return }
        groups[i].suggested.insert(id)
        pending.remove(id)
    }
    func chooseDelete(_ id: String, groupID: String) {
        guard let i = groups.firstIndex(where: { $0.id == groupID }) else { return }
        // Prevent a whole group from being marked for deletion by mistake.
        if groups[i].suggested.count == 1 && groups[i].suggested.contains(id) {
            errorMessage = "请先选择另一张保留照片；每组至少保留一张。"
            return
        }
        groups[i].suggested.remove(id)
        pending.insert(id)
    }
    func queueUnselected(in group: SimilarGroup) {
        guard !group.suggested.isEmpty else { errorMessage = "请先为本组选择至少一张保留照片"; return }
        for item in group.items where !group.suggested.contains(item.id) { pending.insert(item.id) }
    }
    func removeFromQueue(_ id: String) { pending.remove(id) }
    func deletePending() async {
        let ids = pending
        guard !ids.isEmpty else { return }
        let assets = ids.compactMap { itemIndex[$0]?.asset }
        guard assets.count == ids.count else { errorMessage = "部分照片已失效，请重新扫描"; return }
        do {
            try await PHPhotoLibrary.shared().performChanges {
                PHAssetChangeRequest.deleteAssets(assets as NSArray)
            }
            pending.subtract(ids)
            groups = groups.compactMap { group in
                var copy = group
                copy.items.removeAll { ids.contains($0.id) }
                return copy.items.count > 1 ? copy : nil
            }
            progress = "已提交系统删除请求。可在照片 App 的「最近删除」中恢复。"
        } catch { errorMessage = "删除未完成：\(error.localizedDescription)" }
    }
    func item(for id: String) -> PhotoItem? { itemIndex[id] }
}
