import Foundation
import Photos
import UIKit
import Vision

struct PhotoItem: Identifiable, Hashable {
    let id: String
    let asset: PHAsset
    let date: Date
    let width: Int
    let height: Int
    static func == (lhs: Self, rhs: Self) -> Bool { lhs.id == rhs.id }
    func hash(into hasher: inout Hasher) { hasher.combine(id) }
}

struct SimilarGroup: Identifiable {
    let id: String
    var items: [PhotoItem]
    var suggested: Set<String>
    var title: String { items.first?.date.formatted(date: .abbreviated, time: .shortened) ?? "相似照片" }
}

@MainActor final class PhotoLibraryModel: ObservableObject {
    @Published var permission: PHAuthorizationStatus = PHPhotoLibrary.authorizationStatus(for: .readWrite)
    @Published var groups: [SimilarGroup] = []
    @Published var pending: Set<String> = []
    @Published var scannedCount = 0
    @Published var totalCount = 0
    @Published var progress = "尚未扫描"
    @Published var scanning = false
    @Published var errorMessage: String?
    @Published var scopeDays = 90
    @Published var sensitivity = 0.38
    private var scanTask: Task<Void, Never>?
    private let manager = PHCachingImageManager()
    private var itemIndex: [String: PhotoItem] = [:]

    func authorize() async {
        if permission == .notDetermined {
            permission = await PHPhotoLibrary.requestAuthorization(for: .readWrite)
        } else { permission = PHPhotoLibrary.authorizationStatus(for: .readWrite) }
    }
    func cancel() { scanTask?.cancel(); scanTask = nil; scanning = false; progress = "扫描已停止" }
    func startScan() {
        guard permission == .authorized || permission == .limited else { errorMessage = "请先允许访问照片"; return }
        cancel()
        scanning = true; groups = []; pending = []; scannedCount = 0; totalCount = 0
        progress = "读取照片列表…"
        let days = scopeDays, threshold = sensitivity
        scanTask = Task { [weak self] in
            guard let self else { return }
            let options = PHFetchOptions()
            options.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: true)]
            if days > 0 { options.predicate = NSPredicate(format: "creationDate >= %@", Calendar.current.date(byAdding: .day, value: -days, to: Date())! as NSDate) }
            let result = PHAsset.fetchAssets(with: .image, options: options)
            var items: [PhotoItem] = []
            result.enumerateObjects { asset, _, _ in
                items.append(PhotoItem(id: asset.localIdentifier, asset: asset, date: asset.creationDate ?? .distantPast, width: asset.pixelWidth, height: asset.pixelHeight))
            }
            self.totalCount = items.count
            self.itemIndex = Dictionary(uniqueKeysWithValues: items.map { ($0.id, $0) })
            // Cluster near-in-time photos first; this keeps expensive Vision work bounded.
            var buckets: [[PhotoItem]] = []
            for item in items {
                if let last = buckets.indices.last, let previous = buckets[last].last,
                   item.date.timeIntervalSince(previous.date) <= 45 {
                    buckets[last].append(item)
                } else { buckets.append([item]) }
            }
            var output: [SimilarGroup] = []
            for bucket in buckets where bucket.count > 1 {
                if Task.isCancelled { break }
                // Vision descriptors are computed from small thumbnails; unavailable iCloud assets are skipped.
                var features: [(PhotoItem, VNFeaturePrintObservation, Double)] = []
                for item in bucket {
                    if Task.isCancelled { break }
                    if let image = await self.thumbnail(for: item.asset, size: CGSize(width: 240, height: 240)),
                       let cg = image.cgImage {
                        let request = VNGenerateImageFeaturePrintRequest()
                        if (try? VNImageRequestHandler(cgImage: cg).perform([request])) != nil,
                           let feature = request.results?.first {
                            let sharpness = self.quality(image)
                            features.append((item, feature, sharpness))
                        }
                    }
                    self.scannedCount += 1
                    self.progress = "正在分析 \(self.scannedCount)/\(items.count) 张"
                }
                var clusters: [[Int]] = []
                for index in features.indices {
                    var match: Int?
                    for ci in clusters.indices {
                        guard let representative = clusters[ci].first else { continue }
                        var distance: Float = 1
                        if (try? features[index].1.computeDistance(&distance, to: features[representative].1)) != nil,
                           distance <= Float(threshold) { match = ci; break }
                    }
                    if let match { clusters[match].append(index) }
                    else { clusters.append([index]) }
                }
                for cluster in clusters where cluster.count > 1 {
                    guard let best = cluster.max(by: { features[$0].2 < features[$1].2 }) else { continue }
                    let members = cluster.map { features[$0].0 }
                    output.append(SimilarGroup(id: members[0].id, items: members,
                                               suggested: [features[best].0.id]))
                }
            }
            if !Task.isCancelled {
                self.groups = output.sorted { $0.items.count > $1.items.count }
                self.progress = "完成：发现 \(output.count) 组相似照片"
            }
            self.scanning = false
            self.scanTask = nil
        }
    }

    private func quality(_ image: UIImage) -> Double {
        guard let cg = image.cgImage, let provider = cg.dataProvider,
              let data = provider.data as Data? else { return 0 }
        // Lightweight contrast / edge variation heuristic, not a face or aesthetic classifier.
        let bytes = [UInt8](data)
        let strideBytes = cg.bytesPerRow, pixelStride = max(cg.bitsPerPixel / 8, 1)
        guard strideBytes > 0, cg.width > 2, cg.height > 2, bytes.count >= strideBytes * cg.height else { return 0 }
        var sum = 0.0, count = 0
        for y in stride(from: 1, to: cg.height - 1, by: 4) {
            for x in stride(from: 1, to: cg.width - 1, by: 4) {
                let i = y * strideBytes + x * pixelStride
                if i + pixelStride < bytes.count && i + strideBytes < bytes.count {
                    sum += abs(Double(bytes[i]) - Double(bytes[i + pixelStride]))
                    sum += abs(Double(bytes[i]) - Double(bytes[i + strideBytes]))
                    count += 2
                }
            }
        }
        return count == 0 ? 0 : sum / Double(count)
    }
    func thumbnail(for asset: PHAsset, size: CGSize) async -> UIImage? {
        await withCheckedContinuation { continuation in
            let opts = PHImageRequestOptions()
            opts.deliveryMode = .highQualityFormat
            opts.resizeMode = .fast
            opts.isNetworkAccessAllowed = false
            opts.isSynchronous = true
            var image: UIImage?
            manager.requestImage(for: asset, targetSize: size, contentMode: .aspectFit, options: opts) { result, _ in image = result }
            continuation.resume(returning: image)
        }
    }
    func chooseKeep(_ id: String, groupID: String) {
        guard let i = groups.firstIndex(where: { $0.id == groupID }) else { return }
        groups[i].suggested.insert(id)
        pending.remove(id)
    }
    func chooseDelete(_ id: String, groupID: String) {
        guard let i = groups.firstIndex(where: { $0.id == groupID }) else { return }
        groups[i].suggested.remove(id)
        pending.insert(id)
    }
    func queueUnselected(in group: SimilarGroup) {
        for item in group.items where !group.suggested.contains(item.id) { pending.insert(item.id) }
    }
    func queueAllSuggestedRemovals() {
        for group in groups { queueUnselected(in: group) }
    }
    func removeFromQueue(_ id: String) { pending.remove(id) }
    func deletePending() async {
        let ids = pending
        guard !ids.isEmpty else { return }
        let assets = ids.compactMap { itemIndex[$0]?.asset }
        do {
            try await PHPhotoLibrary.shared().performChanges {
                PHAssetChangeRequest.deleteAssets(assets as NSArray)
            }
            pending.subtract(ids)
            groups = groups.compactMap { group in
                var copy = group
                copy.items.removeAll { ids.contains($0.id) }
                return copy.items.count > 1 ? copy : nil
            }
            progress = "已提交系统删除请求。可在照片 App 的「最近删除」中恢复。"
        } catch { errorMessage = "删除未完成：\(error.localizedDescription)" }
    }
    func item(for id: String) -> PhotoItem? { itemIndex[id] }
}
