import SwiftUI

@main
struct PhotoPickApp: App {
    @StateObject private var library = PhotoLibraryModel()
    var body: some Scene {
        WindowGroup {
            MainView().environmentObject(library)
                .preferredColorScheme(.dark)
        }
    }
}
