import SwiftUI
import Photos

struct AssetThumb: View {
    let asset: PHAsset
    var size: CGFloat = 100
    @State private var image: UIImage?
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12).fill(.white.opacity(0.08))
            if let image { Image(uiImage: image).resizable().scaledToFill() }
            else { ProgressView().tint(.white) }
        }
        .frame(width: size, height: size).clipped().cornerRadius(12)
        .task(id: asset.localIdentifier) {
            let opts = PHImageRequestOptions()
            opts.deliveryMode = .opportunistic; opts.isNetworkAccessAllowed = true
            PHImageManager.default().requestImage(for: asset, targetSize: CGSize(width: size * 3, height: size * 3), contentMode: .aspectFill, options: opts) { result, _ in
                if let result { DispatchQueue.main.async { image = result } }
            }
        }
    }
}

struct MainView: View {
    @EnvironmentObject var model: PhotoLibraryModel
    @State private var tab = 0
    var body: some View {
        TabView(selection: $tab) {
            NavigationStack { scanPage }.tabItem { Label("扫描", systemImage: "sparkle.magnifyingglass") }.tag(0)
            NavigationStack { groupsPage }.tabItem { Label("相似分组", systemImage: "square.stack.3d.up") }.tag(1)
            NavigationStack { pendingPage }.tabItem { Label("待删除", systemImage: "trash") }.tag(2)
        }
        .tint(.cyan)
        .alert("提示", isPresented: Binding(get: { model.errorMessage != nil }, set: { if !$0 { model.errorMessage = nil } })) {
            Button("知道了", role: .cancel) { model.errorMessage = nil }
        } message: { Text(model.errorMessage ?? "") }
        .task { await model.authorize() }
    }
    private var scanPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VStack(alignment: .leading, spacing: 10) {
                    Image(systemName: "photo.stack.fill").font(.system(size: 42)).foregroundStyle(.cyan)
                    Text("PhotoPick Pro").font(.largeTitle.bold())
                    Text("把相似照片放在一起，留下最值得珍藏的瞬间。所有筛选在本机进行，删除前由你决定。")
                        .foregroundStyle(.secondary)
                }.padding(20).frame(maxWidth: .infinity, alignment: .leading)
                    .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 22))
                HStack {
                    stat("照片", "\(model.totalCount)", "photo")
                    stat("相似组", "\(model.groups.count)", "square.stack")
                    stat("待删除", "\(model.pending.count)", "trash")
                }
                VStack(alignment: .leading, spacing: 16) {
                    Text("扫描范围").font(.headline)
                    Picker("扫描范围", selection: $model.scopeDays) {
                        Text("近30天").tag(30); Text("近90天").tag(90)
                        Text("近一年").tag(365); Text("全部").tag(0)
                    }.pickerStyle(.segmented)
                    Text("相似程度：\(Int((1 - model.sensitivity) * 100))%（越高越严格）")
                    Slider(value: $model.sensitivity, in: 0.20...0.55)
                    Text("重点识别短时间连续拍摄的相似照片；不同日期的重复照片暂不跨日期匹配。")
                        .font(.caption).foregroundStyle(.secondary)
                    if model.scanning { ProgressView(); Button("停止扫描", role: .destructive) { model.cancel() } }
                    else {
                        Button { model.startScan() } label: {
                            Label("开始扫描相册", systemImage: "sparkles")
                                .frame(maxWidth: .infinity).padding(12)
                        }.buttonStyle(.borderedProminent).disabled(model.permission != .authorized && model.permission != .limited)
                    }
                    Text(model.progress).font(.footnote).foregroundStyle(.secondary)
                    if model.permission != .authorized && model.permission != .limited {
                        Button("申请相册权限") { Task { await model.authorize() } }
                        Text("如曾拒绝授权，请到系统设置中允许照片访问。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }.padding(18).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18))
                Text("安全原则：不会自动删除任何照片。推荐仅依据图像特征与清晰度启发式评分，不能准确判断孩子的表情或纪念价值。")
                    .font(.footnote).foregroundStyle(.secondary)
            }.padding()
        }.navigationTitle("智能整理")
    }
    private func stat(_ title: String, _ number: String, _ icon: String) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon).foregroundStyle(.cyan)
            Text(number).font(.title2.bold())
            Text(title).font(.caption).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity).padding(.vertical, 14)
            .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
    }
    private var groupsPage: some View {
        Group {
            if model.groups.isEmpty {
                ContentUnavailableViewCompat(title: "还没有相似照片组", detail: "先到「扫描」页面开始分析相册。", icon: "square.stack")
            } else {
                ScrollView {
                    LazyVStack(spacing: 14) {
                        ForEach(model.groups) { group in
                            NavigationLink { GroupReviewView(groupID: group.id) } label: {
                                HStack(spacing: 14) {
                                    if let first = group.items.first { AssetThumb(asset: first.asset, size: 94) }
                                    VStack(alignment: .leading, spacing: 8) {
                                        Text(group.title).font(.headline).foregroundStyle(.primary)
                                        Text("\(group.items.count) 张相似照片").foregroundStyle(.secondary)
                                        Text("点击逐张挑选").font(.caption).foregroundStyle(.cyan)
                                    }
                                    Spacer(); Image(systemName: "chevron.right").foregroundStyle(.secondary)
                                }.padding(12).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18))
                            }.buttonStyle(.plain)
                        }
                    }.padding()
                }
            }
        }.navigationTitle("相似分组")
    }
    @State private var confirmDelete = false
    private var pendingPage: some View {
        VStack {
            if model.pending.isEmpty {
                ContentUnavailableViewCompat(title: "待删除清单为空", detail: "在相似分组中挑选照片后，才会出现在这里。", icon: "checkmark.shield")
            } else {
                Text("已选 \(model.pending.count) 张 · 点击缩略图可从清单移除")
                    .font(.footnote).foregroundStyle(.secondary).padding(.top)
                ScrollView {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 94), spacing: 8)], spacing: 8) {
                        ForEach(model.pending.sorted(), id: \.self) { id in
                            if let item = model.item(for: id) {
                                Button { model.removeFromQueue(id) } label: {
                                    ZStack(alignment: .topTrailing) {
                                        AssetThumb(asset: item.asset, size: 100)
                                        Image(systemName: "xmark.circle.fill").foregroundStyle(.white, .black).padding(5)
                                    }
                                }.buttonStyle(.plain)
                            }
                        }
                    }.padding()
                }
                Button(role: .destructive) { confirmDelete = true } label: {
                    Label("确认删除这 \(model.pending.count) 张照片", systemImage: "trash.fill")
                        .frame(maxWidth: .infinity).padding(12)
                }.buttonStyle(.borderedProminent).tint(.red).padding()
            }
        }.navigationTitle("安全删除")
            .confirmationDialog("确定删除所选照片？", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("提交系统删除确认", role: .destructive) { Task { await model.deletePending() } }
                Button("取消", role: .cancel) {}
            } message: { Text("此操作会调用 iOS 照片删除接口。照片通常会进入系统「最近删除」，请确认清单后再继续。") }
    }
}

struct ContentUnavailableViewCompat: View {
    let title: String, detail: String, icon: String
    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: icon).font(.system(size: 48)).foregroundStyle(.cyan)
            Text(title).font(.title3.bold())
            Text(detail).font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }.padding(32).frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct GroupReviewView: View {
    @EnvironmentObject var model: PhotoLibraryModel
    let groupID: String
    @State private var selectedID: String?
    private var group: SimilarGroup? { model.groups.first { $0.id == groupID } }
    var body: some View {
        ScrollView {
            if let group {
                VStack(alignment: .leading, spacing: 16) {
                    Text("共 \(group.items.count) 张 · 默认推荐保留一张，请自己确认")
                        .font(.footnote).foregroundStyle(.secondary)
                    if let selected = group.items.first(where: { $0.id == selectedID }) ?? group.items.first {
                        PhotoPreview(asset: selected.asset).frame(height: 350)
                        HStack {
                            Button { model.chooseKeep(selected.id, groupID: groupID) } label: {
                                Label("保留", systemImage: "heart.fill").frame(maxWidth: .infinity)
                            }.buttonStyle(.borderedProminent).tint(.green)
                            Button { model.chooseDelete(selected.id, groupID: groupID) } label: {
                                Label("待删除", systemImage: "trash").frame(maxWidth: .infinity)
                            }.buttonStyle(.borderedProminent).tint(.orange)
                        }
                    }
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 95), spacing: 9)], spacing: 10) {
                        ForEach(group.items) { item in
                            Button { selectedID = item.id } label: {
                                ZStack(alignment: .bottom) {
                                    AssetThumb(asset: item.asset, size: 100)
                                    Text(model.pending.contains(item.id) ? "待删除" : (group.suggested.contains(item.id) ? "推荐保留" : "未选择"))
                                        .font(.caption2.bold()).padding(4).frame(maxWidth: .infinity)
                                        .background(model.pending.contains(item.id) ? Color.orange : (group.suggested.contains(item.id) ? Color.green : Color.black.opacity(0.65)))
                                }.overlay(RoundedRectangle(cornerRadius: 12).stroke(selectedID == item.id ? Color.cyan : Color.clear, lineWidth: 3))
                            }.buttonStyle(.plain)
                        }
                    }
                    Button("把本组未保留照片加入待删除清单") { model.queueUnselected(in: group) }
                        .buttonStyle(.bordered).frame(maxWidth: .infinity)
                    Text("支持点击照片查看大图、双指缩放。每张照片均可手动标记保留或待删除。")
                        .font(.caption).foregroundStyle(.secondary)
                }.padding()
            }
        }.navigationTitle("逐张精选").navigationBarTitleDisplayMode(.inline)
    }
}

struct PhotoPreview: View {
    let asset: PHAsset
    @State private var image: UIImage?
    @State private var scale: CGFloat = 1
    var body: some View {
        GeometryReader { geo in
            ZStack {
                RoundedRectangle(cornerRadius: 18).fill(.white.opacity(0.05))
                if let image {
                    Image(uiImage: image).resizable().scaledToFit().scaleEffect(scale)
                        .gesture(MagnificationGesture().onChanged { scale = min(max($0, 1), 5) }.onEnded { _ in })
                } else { ProgressView() }
            }.frame(width: geo.size.width, height: geo.size.height).clipped().cornerRadius(18)
        }.task(id: asset.localIdentifier) {
            scale = 1
            let options = PHImageRequestOptions()
            options.deliveryMode = .highQualityFormat; options.isNetworkAccessAllowed = true
            PHImageManager.default().requestImage(for: asset, targetSize: CGSize(width: 1200, height: 1200), contentMode: .aspectFit, options: options) { result, _ in
                if let result { DispatchQueue.main.async { image = result } }
            }
        }
    }
}
