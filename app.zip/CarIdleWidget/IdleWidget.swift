import SwiftUI
import WidgetKit
import ActivityKit

// UI-only refinement. Keep the proven ActivityKit attributes and timing behavior unchanged.
struct IdleActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var startTime: Date
        var targetMinutes: Int
    }
    var title: String
}

@available(iOS 16.2, *)
struct IdleWidget: Widget {
    private let accent = Color(red: 0.27, green: 0.92, blue: 0.57)
    private let panel = Color(red: 0.12, green: 0.15, blue: 0.20)
    private let muted = Color(red: 0.72, green: 0.77, blue: 0.83)

    private func runningTimer(_ start: Date, size: Font) -> some View {
        Text(timerInterval: start...Date.distantFuture, countsDown: false)
            .font(size)
            .monospacedDigit()
            .foregroundColor(.white)
            .lineLimit(1)
            .minimumScaleFactor(0.75)
    }

    var body: some WidgetConfiguration {
        ActivityConfiguration(for: IdleActivityAttributes.self) { context in
            HStack(alignment: .center, spacing: 14) {
                Image(systemName: "car.fill")
                    .font(.system(size: 21, weight: .semibold))
                    .foregroundColor(accent)
                    .frame(width: 46, height: 46)
                    .background(accent.opacity(0.13), in: RoundedRectangle(cornerRadius: 14))

                VStack(alignment: .leading, spacing: 5) {
                    HStack(spacing: 6) {
                        Circle().fill(accent).frame(width: 6, height: 6)
                        Text("发动机运行中")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.white)
                    }
                    runningTimer(context.state.startTime, size: .system(size: 29, weight: .bold, design: .rounded))
                    Text("目标时长  ·  \(context.state.targetMinutes) 分钟")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(muted)
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 13)
            .activityBackgroundTint(panel)
            .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    HStack(spacing: 7) {
                        Image(systemName: "car.fill")
                            .foregroundColor(accent)
                        Text("发动机运行")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(.white)
                    }
                    .lineLimit(1)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text("目标 \(context.state.targetMinutes) 分钟")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(muted)
                        .lineLimit(1)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    HStack(alignment: .center, spacing: 12) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("本次运行时长")
                                .font(.system(size: 11, weight: .medium))
                                .foregroundColor(muted)
                            runningTimer(context.state.startTime, size: .system(size: 30, weight: .bold, design: .rounded))
                        }
                        Spacer(minLength: 0)
                        Image(systemName: "timer")
                            .font(.system(size: 20, weight: .medium))
                            .foregroundColor(accent)
                            .frame(width: 42, height: 42)
                            .background(accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 13))
                    }
                    .padding(.top, 5)
                    .padding(.bottom, 4)
                }
            } compactLeading: {
                Image(systemName: "car.fill")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(accent)
            } compactTrailing: {
                runningTimer(context.state.startTime, size: .system(size: 12, weight: .semibold, design: .rounded))
                    .frame(maxWidth: 66)
            } minimal: {
                Image(systemName: "car.fill")
                    .foregroundColor(accent)
            }
        }
    }
}

@main
struct IdleWidgetBundle: WidgetBundle {
    var body: some Widget { IdleWidget() }
}
