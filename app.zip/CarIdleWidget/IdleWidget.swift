import SwiftUI
import WidgetKit
import ActivityKit

// V2.3.6 Fix3: UI only. Do not change ActivityKit data, start/end, or timing.
struct IdleActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var startTime: Date
        var targetMinutes: Int
    }
    var title: String
}

@available(iOS 16.2, *)
struct IdleWidget: Widget {
    private let green = Color(red: 0.25, green: 0.94, blue: 0.54)
    private let secondary = Color(red: 0.78, green: 0.82, blue: 0.87)
    private let darkBackground = Color(red: 0.12, green: 0.14, blue: 0.18)

    private func clock(_ date: Date, fontSize: CGFloat) -> some View {
        Text(timerInterval: date...Date.distantFuture, countsDown: false)
            .font(.system(size: fontSize, weight: .bold, design: .rounded))
            .monospacedDigit()
            .foregroundStyle(Color.white)
            .environment(\.colorScheme, .dark)
            .lineLimit(1)
            .minimumScaleFactor(0.75)
    }

    var body: some WidgetConfiguration {
        ActivityConfiguration(for: IdleActivityAttributes.self) { context in
            // Force a dark color environment for timerInterval's internally rendered text.
            HStack(alignment: .center, spacing: 13) {
                Image(systemName: "car.fill")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(green)
                    .frame(width: 46, height: 46)
                    .background(green.opacity(0.13), in: RoundedRectangle(cornerRadius: 13))

                VStack(alignment: .leading, spacing: 5) {
                    HStack(spacing: 6) {
                        Circle().fill(green).frame(width: 6, height: 6)
                        Text("发动机运行中")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(Color.white)
                            .lineLimit(1)
                    }
                    clock(context.state.startTime, fontSize: 30)
                    Text("目标 \(context.state.targetMinutes) 分钟")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(secondary)
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .foregroundStyle(Color.white)
            .environment(\.colorScheme, .dark)
            .activityBackgroundTint(darkBackground)
            .activitySystemActionForegroundColor(Color.white)
        } dynamicIsland: { context in
            DynamicIsland {
                // One full-width bottom region avoids leading/trailing width competition.
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack(spacing: 7) {
                            Image(systemName: "car.fill")
                                .foregroundStyle(green)
                            Text("发动机运行中")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundStyle(Color.white)
                                .lineLimit(1)
                            Spacer(minLength: 8)
                            Text("目标 \(context.state.targetMinutes) 分钟")
                                .font(.system(size: 11, weight: .medium))
                                .foregroundStyle(secondary)
                                .lineLimit(1)
                        }
                        HStack(alignment: .firstTextBaseline, spacing: 8) {
                            clock(context.state.startTime, fontSize: 30)
                            Spacer(minLength: 8)
                            Text("运行时长")
                                .font(.system(size: 11, weight: .medium))
                                .foregroundStyle(secondary)
                        }
                    }
                    .padding(.horizontal, 5)
                    .padding(.top, 3)
                    .padding(.bottom, 7)
                    .foregroundStyle(Color.white)
                    .environment(\.colorScheme, .dark)
                }
            } compactLeading: {
                Image(systemName: "car.fill")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(green)
            } compactTrailing: {
                clock(context.state.startTime, fontSize: 12)
                    .frame(maxWidth: 66)
            } minimal: {
                Image(systemName: "car.fill")
                    .foregroundStyle(green)
            }
        }
    }
}

@main
struct IdleWidgetBundle: WidgetBundle {
    var body: some Widget { IdleWidget() }
}
