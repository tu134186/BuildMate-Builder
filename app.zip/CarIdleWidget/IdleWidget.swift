import SwiftUI
import WidgetKit
import ActivityKit

// Clean UI: only Widget presentation. Keep ActivityKit state and app logic unchanged.
struct IdleActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var startTime: Date
        var targetMinutes: Int
    }
    var title: String
}

@available(iOS 16.2, *)
struct IdleWidget: Widget {
    private let green = Color(red: 0.25, green: 0.94, blue: 0.54)
    private let panel = Color(red: 0.105, green: 0.115, blue: 0.14)
    private let muted = Color(red: 0.80, green: 0.84, blue: 0.89)

    private func elapsed(_ start: Date, size: CGFloat) -> some View {
        Text(timerInterval: start...Date.distantFuture, countsDown: false)
            .font(.system(size: size, weight: .semibold, design: .rounded))
            .monospacedDigit()
            .foregroundColor(.white)
            .lineLimit(1)
            .minimumScaleFactor(0.8)
    }

    var body: some WidgetConfiguration {
        ActivityConfiguration(for: IdleActivityAttributes.self) { context in
            HStack(spacing: 12) {
                Image(systemName: "car.fill")
                    .font(.system(size: 20, weight: .medium))
                    .foregroundColor(green)
                VStack(alignment: .leading, spacing: 5) {
                    Text("发动机运行中")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(.white)
                        .lineLimit(1)
                    Text("目标\(context.state.targetMinutes)分钟")
                        .font(.system(size: 11))
                        .foregroundColor(muted)
                        .lineLimit(1)
                }
                Spacer(minLength: 6)
                elapsed(context.state.startTime, size: 28)
            }
            .padding(.horizontal, 17)
            .padding(.vertical, 18)
            .frame(maxWidth: .infinity)
            .activityBackgroundTint(panel)
            .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                // The bottom region sits below the TrueDepth camera cutout.
                DynamicIslandExpandedRegion(.bottom) {
                    HStack(alignment: .center, spacing: 10) {
                        Image(systemName: "car.fill")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(green)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("发动机运行中")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundColor(.white)
                                .lineLimit(1)
                            Text("目标\(context.state.targetMinutes)分钟")
                                .font(.system(size: 10))
                                .foregroundColor(muted)
                                .lineLimit(1)
                        }
                        Spacer(minLength: 4)
                        elapsed(context.state.startTime, size: 25)
                    }
                    .padding(.horizontal, 4)
                    .padding(.bottom, 3)
                }
            } compactLeading: {
                Image(systemName: "car.fill")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(green)
            } compactTrailing: {
                elapsed(context.state.startTime, size: 12)
                    .fixedSize(horizontal: true, vertical: false)
            } minimal: {
                Image(systemName: "car.fill")
                    .foregroundColor(green)
            }
            .contentMargins(.trailing, 0, for: .compactTrailing)
        }
    }
}

@main
struct IdleWidgetBundle: WidgetBundle {
    var body: some Widget { IdleWidget() }
}
