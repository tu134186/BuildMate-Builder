import SwiftUI
import WidgetKit
import ActivityKit

// V2.3.6 Fix4 — only Live Activity presentation changed.
// ActivityKit attributes/state and start/update/end behavior are unchanged.
struct IdleActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var startTime: Date
        var targetMinutes: Int
    }
    var title: String
}

@available(iOS 16.2, *)
struct IdleWidget: Widget {
    private let green = Color(red: 0.25, green: 0.94, blue: 0.54)
    private let panel = Color(red: 0.105, green: 0.115, blue: 0.14)
    private let muted = Color(red: 0.82, green: 0.85, blue: 0.90)

    // Timer text is system-updated; keep it a native timer rather than manually
    // calculating a static duration. Use foregroundColor explicitly on the Text.
    private func runningTime(_ start: Date, size: CGFloat) -> some View {
        Text(timerInterval: start...Date.distantFuture, countsDown: false)
            .font(.system(size: size, weight: .bold, design: .rounded))
            .monospacedDigit()
            .foregroundColor(.white)
            .lineLimit(1)
            .minimumScaleFactor(0.75)
    }

    var body: some WidgetConfiguration {
        ActivityConfiguration(for: IdleActivityAttributes.self) { context in
            // Lock Screen: opaque background + per-Text foregroundColor (not
            // foregroundStyle inheritance). The island uses a separate layout.
            HStack(alignment: .center, spacing: 14) {
                Image(systemName: "car.fill")
                    .font(.system(size: 23, weight: .semibold))
                    .foregroundColor(green)
                    .frame(width: 45, height: 45)
                    .background(green.opacity(0.15), in: RoundedRectangle(cornerRadius: 12))

                VStack(alignment: .leading, spacing: 6) {
                    Text("发动机运行中")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.white)
                        .lineLimit(1)
                        .fixedSize(horizontal: true, vertical: false)

                    runningTime(context.state.startTime, size: 29)

                    Text("目标时长 · \(context.state.targetMinutes) 分钟")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(muted)
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 15)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(panel)
            .environment(\.colorScheme, .dark)
            .activityBackgroundTint(panel)
            .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                // Center is BELOW the TrueDepth cutout. Do not place long
                // Chinese text in the narrow leading/trailing camera-side areas.
                DynamicIslandExpandedRegion(.center) {
                    HStack(spacing: 7) {
                        Image(systemName: "car.fill")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(green)
                        Text("发动机运行中")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.white)
                            .lineLimit(1)
                            .fixedSize(horizontal: true, vertical: false)
                        Spacer(minLength: 4)
                        Text("目标\(context.state.targetMinutes)分")
                            .font(.system(size: 11, weight: .medium))
                            .foregroundColor(muted)
                            .lineLimit(1)
                    }
                    .padding(.horizontal, 8)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("本次运行时长")
                                .font(.system(size: 10, weight: .medium))
                                .foregroundColor(muted)
                            runningTime(context.state.startTime, size: 28)
                        }
                        Spacer(minLength: 6)
                        Text("运行中")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(green)
                    }
                    .padding(.horizontal, 8)
                    .padding(.bottom, 4)
                }
            } compactLeading: {
                Image(systemName: "car.fill")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(green)
            } compactTrailing: {
                runningTime(context.state.startTime, size: 12)
                    .frame(maxWidth: 66, alignment: .trailing)
            } minimal: {
                Image(systemName: "car.fill")
                    .foregroundColor(green)
            }
            // Official WidgetKit API; reduce only the compact trailing right
            // inset, leaving a small safety gap from the island's rounded edge.
            .contentMargins(.trailing, 2, for: .compactTrailing)
        }
    }
}

@main
struct IdleWidgetBundle: WidgetBundle {
    var body: some Widget { IdleWidget() }
}
