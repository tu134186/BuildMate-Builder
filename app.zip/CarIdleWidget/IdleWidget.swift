import SwiftUI
import WidgetKit
import ActivityKit

struct IdleActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var startTime: Date
        var targetMinutes: Int
    }
    var title: String
}

@available(iOS 16.1, *)
struct IdleWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: IdleActivityAttributes.self) { context in
            HStack(spacing: 14) {
                Image(systemName: "car.fill")
                    .font(.title2).foregroundColor(.green)
                VStack(alignment: .leading, spacing: 5) {
                    Text("发动机运行中").font(.headline)
                    Text(timerInterval: context.state.startTime...Date.distantFuture, countsDown: false)
                        .font(.title2.monospacedDigit().bold())
                    Text("目标时长：\(context.state.targetMinutes)分钟")
                        .font(.caption).foregroundColor(.secondary)
                }
                Spacer(minLength: 0)
            }
            .padding()
            .activityBackgroundTint(Color.black.opacity(0.88))
            .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Label("发动机运行中", systemImage: "car.fill").foregroundColor(.green)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text("目标\(context.state.targetMinutes)分").font(.caption)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("本次运行时长").font(.caption).foregroundColor(.secondary)
                        Text(timerInterval: context.state.startTime...Date.distantFuture, countsDown: false)
                            .font(.title2.monospacedDigit().bold())
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
            } compactLeading: {
                Image(systemName: "car.fill").foregroundColor(.green)
            } compactTrailing: {
                Text(timerInterval: context.state.startTime...Date.distantFuture, countsDown: false)
                    .monospacedDigit().font(.caption2)
                    .frame(maxWidth: 65)
            } minimal: {
                Image(systemName: "car.fill").foregroundColor(.green)
            }
        }
    }
}

@main
struct IdleWidgetBundle: WidgetBundle {
    var body: some Widget { IdleWidget() }
}
