#import "RSRootController.h"
#import <Preferences/PSSpecifier.h>
#import <CoreFoundation/CoreFoundation.h>
@implementation RSRootController
- (NSArray *)specifiers {if(!_specifiers)_specifiers=[self loadSpecifiersFromPlistName:@"Root" target:self];return _specifiers;}
- (void)resetDefaults {
 NSString *domain=@"com.tu.recordingsharingan.settings";
 NSDictionary *defaults=@{@"rotationSpeed":@1.0,@"leftXOffset":@0.0,@"rightXOffset":@0.0,@"yOffset":@0.0,@"leftSize":@31.0,@"rightSize":@37.0};
 for(NSString *key in defaults)CFPreferencesSetAppValue((__bridge CFStringRef)key,(__bridge CFPropertyListRef)defaults[key],(__bridge CFStringRef)domain);
 CFPreferencesAppSynchronize((__bridge CFStringRef)domain);
 CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),CFSTR("com.tu.recordingsharingan.settings.changed"),NULL,NULL,YES);
 [self reloadSpecifiers];
}
@end
