#import "IFXModule.h"
@implementation IFXModule
- (instancetype)initWithKey:(NSString *)key { if ((self = [super init])) _key = [key copy]; return self; }
- (void)start { /* Reserved for separately implemented and verified module. */ }
- (void)stop { /* Reserved for separately implemented and verified module. */ }
@end
