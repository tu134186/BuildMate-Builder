# RecordingSharingan 7.11.9.4.3.2.6.17

Thumbnail gallery; independent left/right materials; display-only renaming; 0.1 increments and existing materials preserved.
Device validation pending.
