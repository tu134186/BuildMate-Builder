# RecordingSharingan 6.21

Based on user-provided 6.20 source.

## Change in 6.21
- During active screen recording only, extend `SBSystemApertureContainerView` 7pt to the left (`origin.x -= 7`, `width += 7`), keeping the right edge fixed.
- Outside screen recording, pass the original frame unchanged.
- No material assets, settings UI, rotation, or other behavior intentionally changed.

## Verification
Source-level change only. A Theos build and on-device recording test are still required to confirm that the runtime container corresponds to the recording aperture and that the material no longer clips.
