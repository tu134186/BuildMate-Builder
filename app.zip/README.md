# PhotoPick Pro V1.0.0 / Build 1

本机相册相似照片筛选器，支持 iOS 16+，SwiftUI + PhotoKit + Vision。

## 当前已实现
- 获取照片权限；近 30/90/365 天或全部照片扫描。
- 根据拍摄时间间隔（45 秒内）初筛连续照片，再通过 Vision 特征距离聚类。
- 对同组照片用轻量对比度/边缘变化启发式推荐保留 1 张；**不具备可靠的表情、闭眼、美学评分**。
- 分组查看、单张预览、双指放大、手动保留/待删除、组内批量加入待删除。
- 待删除清单可逐张移除；最终必须经 App 确认及 iOS 系统授权才能删除。
- 不上传照片，不依赖第三方服务。iCloud 未下载到本地的原图可能被跳过。

## 尚未实现/限制
- **不支持跨日期的全库视觉重复查找**，只对时间接近的照片做相似聚类。
- **不支持专门解析连拍内部帧**；照片库暴露的连拍资源会作为普通资产参与时间聚类。
- 未提供真实 AI 表情、闭眼或人物质量判断。
- 未计算准确的可释放容量；删除照片后需按系统「最近删除」机制释放空间。
- 目前无断点续扫、扫描数据库缓存、后台扫描。
- 由于此环境没有 Xcode/iOS SDK，未进行 iOS 真机编译验证。

## 编译
工程使用 XcodeGen：
```
xcodegen generate
xcodebuild -project PhotoPickPro.xcodeproj -scheme PhotoPickPro -configuration Release -sdk iphoneos CODE_SIGNING_ALLOWED=NO build
```
使用 BuildMate 时，上传本源码 ZIP，选择支持 XcodeGen 的编译工作流。

## 安全
建议先用「近30天」扫描测试，确认分组与删除行为。删除操作不会自动执行；系统「最近删除」可恢复期内仍占空间。
