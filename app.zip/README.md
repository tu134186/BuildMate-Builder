# 动态岛 V1.1.4 — 设置空白第二次修复

V1.1.3 已打包 Root.plist，但设置页仍为空。复核源码发现 Preferences bundle 未提供 Info.plist / NSPrincipalClass，PreferenceLoader 无法可靠实例化 IFXRootController。

本版新增 Preferences/Info.plist，明确 NSPrincipalClass=IFXRootController，并通过 IslandFXPrefs_INFO_PLIST 显式打包。保留 Root.plist 和所有模块开关；未修改 SpringBoard tweak 逻辑及编译服务。

这是基于源码的修复假设，未在云端编译或真机验证。若仍空白，需要安装后的 bundle 文件清单或 Settings 崩溃日志，不能继续凭猜测改。
