# 动态岛 V1.1.5 — PreferenceLoader 入口修复

## 源码核查发现

V1.1.4 的 `layout/Library/PreferenceLoader/Preferences/IslandFXPrefs.plist` 只有 `bundle`、`cell`、`isController`、`label`，**缺少 `detail` 控制器类名**。

此次补入 `detail = IFXRootController`，与 `Preferences/IFXRootController.m` 中实际类名一致。此前已存在 `Root.plist` 和 `Preferences/Info.plist`，不再反复修改这些文件的打包规则。

## 注意

这是明确的源码配置缺口，但尚未在 Theos 云端编译、设备安装或运行时验证。若仍空白，应获取设置进程日志、安装后 Info.plist、PreferenceLoader 运行时加载信息。

本版不实现岛屿视觉效果；IFXModule 的 start/stop 仍是占位实现。未修改 G/C 编译助手。
