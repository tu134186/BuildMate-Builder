# 动态岛 V1.1.2 — Theos 打包目录修复

## 本次修改

- 将源码 ZIP 根目录直接设为 Theos 工程根目录，`Makefile`、`control`、`layout/` 均在 ZIP 顶层，避免云端解压后执行 `make package` 时找不到 `control`。
- `control` 版本更新为 1.1.2；保留原有 arm64/arm64e、rootless、Preferences 子工程动态链接配置。
- 其余 Tweak 和设置模块保持 V1.1.1 不变；当前装饰模块仍是设置架构占位，未实现实际视觉效果。

## 编译说明

在 BuildMate 选择 Theos DEB 编译，直接上传此 ZIP。若编译服务会自行进入源码子目录，应以含 `Makefile` 和 `control` 的目录作为工作目录。

本包仅完成静态目录和 Plist 检查，**尚未进行 G/C 云端编译和真机测试**。
