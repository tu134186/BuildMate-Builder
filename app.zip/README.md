# 动态岛 V1.1.3 — 修复设置页空白

## 根因
V1.1.2 的 Preferences/Makefile 没有把 Preferences/Root.plist 打进 IslandFXPrefs.bundle。IFXRootController 调用 loadSpecifiersFromPlistName:@"Root" 时找不到文件，导致设置页为空。

## 修复
- Preferences/Makefile 增加 `IslandFXPrefs_RESOURCE_FILES = Root.plist`，让 Theos 在 bundle 中安装 Root.plist。
- 同步 control 版本和设置页底部版本为 V1.1.3。
- 其余 tweak 主链和 G/C 编译工作流均未修改。

## 验证
已静态检查工程文件，尚未经过 Theos 云编译或真机验证。装饰模块仍为功能框架，尚未实现视觉效果。
