import SwiftUI

// V2.3.2: a shared visual system used across primary and secondary screens.
enum AppleDesign {
    static let accent = Color(red: 0.04, green: 0.43, blue: 0.96)
    static let positive = Color(red: 0.08, green: 0.70, blue: 0.49)
    static let background = Color(red: 0.955, green: 0.969, blue: 0.989)
    static let surface = Color.white
    static let inset = Color(red: 0.91, green: 0.94, blue: 0.98)
    static let text = Color(red: 0.09, green: 0.16, blue: 0.26)
    static let shadow = Color(red: 0.15, green: 0.32, blue: 0.55).opacity(0.09)
}
struct AppleScreenStyle: ViewModifier {
    func body(content: Content) -> some View {
        content.tint(AppleDesign.accent).preferredColorScheme(.light)
    }
}
struct ProCard: ViewModifier {
    func body(content: Content) -> some View {
        content.background(AppleDesign.surface)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).strokeBorder(Color.white.opacity(0.9), lineWidth: 1))
            .shadow(color: AppleDesign.shadow, radius: 15, x: 0, y: 6)
    }
}
struct ProScreen: ViewModifier {
    func body(content: Content) -> some View {
        content
            .scrollContentBackground(.hidden)
            .background(AppleDesign.background.ignoresSafeArea())
            .toolbarBackground(AppleDesign.background, for: .navigationBar)
            .tint(AppleDesign.accent)
            .preferredColorScheme(.light)
    }
}
extension View {
    func appleScreenStyle() -> some View { modifier(AppleScreenStyle()) }
    func proCard() -> some View { modifier(ProCard()) }
    func proScreen() -> some View { modifier(ProScreen()) }
}


// Unified native list/form styling for all internal screens (iOS 16+).
struct ProGroupedRows: ViewModifier {
    func body(content: Content) -> some View {
        content
            .listStyle(.insetGrouped)
            .scrollContentBackground(.hidden)
            .background(AppleDesign.background.ignoresSafeArea())
            .environment(\.defaultMinListRowHeight, 54)
            .tint(AppleDesign.accent)
            .preferredColorScheme(.light)
    }
}
struct ProSectionHeader: ViewModifier {
    func body(content: Content) -> some View {
        content.font(.subheadline.weight(.semibold))
            .foregroundStyle(AppleDesign.text)
    }
}
extension View {
    func proGroupedRows() -> some View { modifier(ProGroupedRows()) }
    func proSectionHeader() -> some View { modifier(ProSectionHeader()) }
}
