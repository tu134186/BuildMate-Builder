import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct StatCard: View {
    let value: String, label: String, color: Color, icon: String
    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon).font(.system(size: 18)).foregroundStyle(color)
            Text(value).font(.headline.bold()).foregroundStyle(color)
                .lineLimit(1).minimumScaleFactor(0.6).monospacedDigit()
            Text(label).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - 快捷功能按钮
