import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct ChartPoint: Identifiable {
    let id = UUID()
    let label: String
    let minutes: Double
}

// MARK: - 报表统计卡片
