import SwiftUI
import UIKit
import ActivityKit

struct ContentView: View {
    @StateObject private var store = IdleStore()
    @State private var now = Date()
    @State private var showSettings = false
    @State private var showHistory = false
    @State private var showMaintenance = false
    @State private var showReport = false
    @State private var selectedRecord: IdleRecord?
    @State private var countdownFinished = false
    @State private var showCancelConfirm = false
    @State private var importCount = 0
    @State private var showImportResult = false

    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 14) {
                    welcomeHeader
                    heroCard
                    if !store.records.isEmpty { overviewCard }
                    if let maintenance = store.upcomingMaintenance.first {
                        attentionCard(maintenance)
                    }
                    if !store.records.isEmpty { nextStartCard }
                    if let recent = store.records.first { recentRecordCard(recent) }
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 22)
            }
            .background(AppleDesign.background.ignoresSafeArea())
            .navigationTitle("怠速记录")
            .navigationBarTitleDisplayMode(.inline)
            .safeAreaInset(edge: .bottom, spacing: 0) { bottomNavigation }
            .onAppear {
                IdleLiveActivity.shared.sync(start: store.currentRecord?.startTime, targetMinutes: store.countdownMinutes)
            }
            .onChange(of: store.countdownMinutes) { minutes in
                IdleLiveActivity.shared.sync(start: store.currentRecord?.startTime, targetMinutes: minutes)
            }
            .onReceive(NotificationCenter.default.publisher(for: UserDefaults.didChangeNotification)) { _ in
                IdleLiveActivity.shared.sync(start: store.currentRecord?.startTime, targetMinutes: store.countdownMinutes)
            }
            .onReceive(timer) { _ in
                now = Date()
                if store.isRunning && remainingSeconds <= 0 && !countdownFinished {
                    countdownFinished = true
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                }
            }
            .alert("确认取消", isPresented: $showCancelConfirm) {
                Button("继续计时", role: .cancel) {}
                Button("不保存", role: .destructive) {
                    store.cancelCurrent()
                    IdleLiveActivity.shared.endAll()
                    countdownFinished = false
                }
            } message: {
                Text("本次启动记录会被丢弃。")
            }
            .alert("导入完成", isPresented: $showImportResult) {
                Button("好的") {}
            } message: {
                Text("成功导入 \(importCount) 条历史记录。")
            }
            .fullScreenCover(isPresented: $showSettings) {
                SettingsView(store: store, onImport: { count in
                    importCount = count
                    showImportResult = true
                })
            }
            .fullScreenCover(isPresented: $showHistory) { HistoryListView(store: store) }
            .fullScreenCover(isPresented: $showMaintenance) { MaintenanceView(store: store) }
            .fullScreenCover(isPresented: $showReport) { ReportView(store: store) }
            .fullScreenCover(item: $selectedRecord) { record in
                RecordDetailView(store: store, record: record) {
                    store.delete(record)
                    selectedRecord = nil
                }
            }
        }
    }

    private var welcomeHeader: some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text("欢迎回来").font(.system(size: 27, weight: .bold, design: .rounded)).foregroundStyle(AppleDesign.text)
                Text("每一次启动，都值得记录").font(.subheadline).foregroundStyle(.secondary)
            }
            Spacer()

        }.padding(.vertical, 8)
    }

    private var bottomNavigation: some View {
        HStack(spacing: 0) {
            tabItem("首页", "house.fill", selected: true) {}
            tabItem("历史", "clock.arrow.circlepath") { showHistory = true }
            tabItem("统计", "chart.bar.fill") { showReport = true }
            tabItem("保养", "wrench.adjustable") { showMaintenance = true }
            tabItem("我的", "person.crop.circle") { showSettings = true }
        }
        .padding(.top, 10).padding(.bottom, 5)
        .background(.regularMaterial)
        .overlay(alignment: .top) { Rectangle().fill(AppleDesign.inset).frame(height: 1) }
    }
    private func tabItem(_ name: String, _ icon: String, selected: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 19, weight: selected ? .semibold : .regular))
                Text(name).font(.system(size: 10, weight: selected ? .bold : .medium))
            }.foregroundStyle(selected ? AppleDesign.accent : Color.gray)
                .frame(maxWidth: .infinity)
        }.buttonStyle(.plain)
    }

    private var heroCard: some View {
        VStack(spacing: 18) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 5) {
                    Label(store.isRunning ? "发动机运行中" : "当前已熄火", systemImage: store.isRunning ? "bolt.car.fill" : "car.fill")
                        .font(.headline)
                    Text(store.isRunning ? "正在记录本次怠速" : statusSubtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Circle()
                    .fill(store.isRunning ? AppleDesign.positive : Color.secondary.opacity(0.25))
                    .frame(width: 12, height: 12)
                    .padding(.top, 4)
            }

            if store.isRunning {
                VStack(spacing: 5) {
                    Text(elapsedText)
                        .font(.system(size: 54, weight: .bold, design: .rounded))
                        .monospacedDigit()
                        .minimumScaleFactor(0.75)
                        .transaction { transaction in transaction.animation = nil }
                        .animation(nil, value: elapsedText)
                    if remainingSeconds > 0 {
                        Text("目标还剩 \(remainingText)")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.orange)
                    } else {
                        Label("已达到目标时长", systemImage: "checkmark.circle.fill")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(AppleDesign.positive)
                    }
                }
                .frame(maxWidth: .infinity)

                HStack(spacing: 10) {
                    Button { showCancelConfirm = true } label: {
                        Label("取消", systemImage: "xmark")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(AppleDesign.inset)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .buttonStyle(.plain)

                    Button {
                        store.stop()
                        IdleLiveActivity.shared.endAll()
                        countdownFinished = false
                    } label: {
                        Label("熄火保存", systemImage: "stop.fill")
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color.red)
                            .foregroundStyle(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .buttonStyle(.plain)
                }
            } else {
                VStack(spacing: 6) {
                    Text("准备开始记录")
                        .font(.system(size: 30, weight: .bold, design: .rounded))
                    Text("启动后自动记录本次怠速时长")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 6)

                Button {
                    store.start()
                    IdleLiveActivity.shared.sync(start: store.currentRecord?.startTime, targetMinutes: store.countdownMinutes)
                    countdownFinished = false
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                } label: {
                    Label("启动并开始记录", systemImage: "play.fill")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(AppleDesign.positive)
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(18)
        .proCard()
    }

    private var overviewCard: some View {
        HStack(spacing: 0) {
            dashboardMetric(title: "总次数", value: "\(store.totalCount)", icon: "number")
            Divider().frame(height: 46)
            dashboardMetric(title: "总时长", value: store.totalDurationText, icon: "clock.fill")
            Divider().frame(height: 46)
            dashboardMetric(title: "距上次", value: "\(String(format: "%.1f", store.daysSinceLast))天", icon: "calendar")
        }
        .padding(.vertical, 15)
        .proCard()
    }

    private func dashboardMetric(title: String, value: String, icon: String) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.subheadline.bold()).monospacedDigit().lineLimit(1).minimumScaleFactor(0.55)
            Text(title).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    private func attentionCard(_ item: MaintenanceRecord) -> some View {
        Button { showMaintenance = true } label: {
            HStack(spacing: 12) {
                Image(systemName: item.type.icon)
                    .font(.title3)
                    .frame(width: 42, height: 42)
                    .background((item.isOverdue ? Color.red : Color.orange).opacity(0.12))
                    .foregroundStyle(item.isOverdue ? .red : .orange)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 3) {
                    Text("保养提醒 · \(item.displayName)").font(.subheadline.bold()).foregroundStyle(.primary)
                    Text(item.isOverdue ? "已超期 \(abs(item.daysRemaining)) 天" : "还有 \(item.daysRemaining) 天到期")
                        .font(.caption).foregroundStyle(item.isOverdue ? .red : .orange)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption.bold()).foregroundStyle(.tertiary)
            }
            .padding(14)
            .background(AppleDesign.surface)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private var nextStartCard: some View {
        let interval = Double(max(store.reminderIntervalDays, 1))
        let elapsed = store.daysSinceLast
        let remaining = interval - elapsed
        let progress = min(max(elapsed / interval, 0), 1)
        let overdue = remaining <= 0

        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("下次启动提醒").font(.subheadline.bold())
                    if store.reminderEnabled {
                        Text(overdue ? "已到建议启动时间" : "约 \(Int(remaining.rounded(.up))) 天后")
                            .font(.title3.bold())
                            .foregroundStyle(overdue ? .red : .primary)
                    } else {
                        Text("提醒未开启").font(.title3.bold()).foregroundStyle(.secondary)
                    }
                }
                Spacer()
                Button(store.reminderEnabled ? "调整" : "开启") { showSettings = true }
                    .font(.caption.bold())
                    .buttonStyle(.bordered)
            }
            if store.reminderEnabled {
                ProgressView(value: progress)
                    .tint(overdue ? .red : .blue)
                Text("当前已闲置 \(String(format: "%.1f", elapsed)) 天 · 间隔 \(store.reminderIntervalDays) 天")
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .proCard()
    }

    private func recentRecordCard(_ record: IdleRecord) -> some View {
        Button { selectedRecord = record } label: {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("最近一次").font(.caption).foregroundStyle(.secondary)
                    Text("\(record.shortDateText)  \(record.startTimeText)").font(.subheadline.bold()).foregroundStyle(.primary)
                    Text("持续 \(record.durationText)").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption.bold()).foregroundStyle(.tertiary)
            }
            .padding(15)
            .background(AppleDesign.surface)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private var statusSubtitle: String {
        guard let last = store.records.first else { return "还没有历史记录" }
        return "上次 \(last.shortDateText) · \(last.durationText)"
    }

    private var elapsedSeconds: Int {
        guard let start = store.currentRecord?.startTime else { return 0 }
        return max(0, Int(now.timeIntervalSince(start)))
    }

    private var elapsedText: String {
        let total = elapsedSeconds
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let seconds = total % 60
        if hours > 0 { return String(format: "%02d:%02d:%02d", hours, minutes, seconds) }
        return String(format: "%02d:%02d", minutes, seconds)
    }

    private var remainingSeconds: Int { store.countdownMinutes * 60 - elapsedSeconds }
    private var remainingText: String {
        let total = max(0, remainingSeconds)
        return String(format: "%02d:%02d", total / 60, total % 60)
    }
}
