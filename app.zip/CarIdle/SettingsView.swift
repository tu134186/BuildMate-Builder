import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct SettingsView: View {
    @ObservedObject var store: IdleStore
    let onImport: (Int) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var showVersionHistory = false
    @State private var showFileImporter = false
    @State private var showClearConfirm = false
    @State private var showActivityView = false
    @State private var backupURL: URL?
    @State private var backupInfo = "尚未导出备份"
    @State private var importAlertTitle = ""
    @State private var importAlertMessage = ""
    @State private var showImportResult = false

    private var vehicleAgeText: String {
        guard let regDate = store.vehicleRegistrationDate else { return "—" }
        let years = Calendar.current.dateComponents([.year], from: regDate, to: Date()).year ?? 0
        return "\(years)年"
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("怠速倒计时") {
                    HStack {
                        Text("目标时长"); Spacer()
                        Picker("", selection: $store.countdownMinutes) {
                            Text("10分钟").tag(10); Text("15分钟").tag(15); Text("20分钟").tag(20)
                            Text("30分钟").tag(30); Text("45分钟").tag(45); Text("60分钟").tag(60)
                        }.pickerStyle(.menu)
                    }
                    Text("启动后达到目标时长会震动提醒").font(.caption).foregroundStyle(.secondary)
                }
                Section("启动提醒") {
                    Toggle("开启提醒", isOn: $store.reminderEnabled)
                    if store.reminderEnabled {
                        HStack {
                            Text("间隔天数"); Spacer()
                            Picker("", selection: $store.reminderIntervalDays) {
                                Text("5天").tag(5); Text("7天").tag(7); Text("10天").tag(10); Text("14天").tag(14)
                            }.pickerStyle(.menu)
                        }
                        Text("熄火后\(store.reminderIntervalDays)天会推送通知提醒启动车辆").font(.caption).foregroundStyle(.secondary)
                    }
                }
                Section("数据防丢") {
                    Button {
                        if let url = store.fullBackupFileURL() {
                            backupURL = url
                            backupInfo = store.backupFileInfo(url)
                            showActivityView = true
                        }
                    } label: {
                        HStack {
                            Image(systemName: "square.and.arrow.up").foregroundStyle(AppleDesign.positive)
                            Text("导出完整备份"); Spacer()
                            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                        }
                    }
                    Text(backupInfo)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button {
                        showFileImporter = true
                    } label: {
                        HStack {
                            Image(systemName: "doc.badge.plus").foregroundStyle(AppleDesign.positive)
                            Text("导入完整备份"); Spacer()
                            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                        }
                    }
                    Button(role: .destructive) {
                        showClearConfirm = true
                    } label: {
                        HStack {
                            Image(systemName: "trash")
                            Text("清空全部怠速记录")
                        }
                    }
                    Text("完整备份包含怠速记录、保养记录、车辆注册日期和主要设置。备份文件保存到“文件”App 后，删除本 App 也不会丢。恢复时自动去重。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("车辆信息") {
                    if let regDate = store.vehicleRegistrationDate {
                        DatePicker("注册日期", selection: Binding(
                            get: { regDate },
                            set: { store.vehicleRegistrationDate = $0 }
                        ), displayedComponents: .date)
                        HStack {
                            Text("车龄")
                            Spacer()
                            Text(vehicleAgeText)
                                .foregroundStyle(.secondary)
                        }
                        if let next = store.nextInspection {
                            HStack {
                                Text("下次年检")
                                Spacer()
                                VStack(alignment: .trailing, spacing: 2) {
                                    Text(next.dateText)
                                        .foregroundStyle(.secondary)
                                    Text(next.type.title)
                                        .font(.caption)
                                        .foregroundStyle(next.type == .online ? .red : .blue)
                                }
                            }
                        }
                    } else {
                        Button {
                            store.vehicleRegistrationDate = Date()
                        } label: {
                            HStack {
                                Text("设置注册日期")
                                    .foregroundStyle(.blue)
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                            }
                        }
                    }
                    Text("设置后自动计算年检倒计时：第6/10年上线检测，第2/4/8年手机申领，满10年后每年检测")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("关于") {
                    HStack { Text("版本"); Spacer(); Text(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "2.2.1").foregroundStyle(.secondary) }
                    Button {
                        showVersionHistory = true
                    } label: {
                        HStack {
                            Text("更新日志")
                            Spacer()
                            Text("查看历史版本").font(.caption).foregroundStyle(.secondary)
                            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                        }
                    }
                    Text("怠速记录 · 保养提醒 · 报表趋势 · 年检提醒").font(.caption).foregroundStyle(.secondary)
                }
            }.proGroupedRows()
            .navigationTitle("设置").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItemGroup(placement: .topBarLeading) { Button("返回") { dismiss() } } }
            .fullScreenCover(isPresented: $showVersionHistory) {
                VersionHistoryView()
            }
            .sheet(isPresented: $showActivityView) {
                ActivityView(activityItems: backupURL.map { [$0] } ?? [])
            }
            .sheet(isPresented: $showFileImporter) {
                AllFileDocumentPicker { url in
                    showFileImporter = false
                    let scoped = url.startAccessingSecurityScopedResource()
                    defer {
                        if scoped { url.stopAccessingSecurityScopedResource() }
                    }
                    guard let data = try? Data(contentsOf: url),
                          !data.isEmpty,
                          let content = String(data: data, encoding: .utf8) else { return }
                    let result = store.importFullBackupDetailed(content)
                        if !result.valid {
                            importAlertTitle = "导入失败"
                            importAlertMessage = "这不是有效的怠速记录完整备份，或文件内容已经损坏。"
                        } else if !result.persisted {
                            importAlertTitle = "导入未完成"
                            importAlertMessage = "备份已读取，但写入本机数据后校验失败。请不要删除原备份文件。"
                        } else if result.addedCount == 0 {
                            importAlertTitle = "备份已验证"
                            importAlertMessage = "备份包含：\(result.backupCount) 条\n新增恢复：0 条\n已存在跳过：\(result.skippedCount) 条\n当前总记录：\(result.totalCount) 条\n数据已持久化保存。"
                        } else {
                            importAlertTitle = "恢复成功"
                            importAlertMessage = "备份包含：\(result.backupCount) 条\n成功恢复：\(result.addedCount) 条\n已存在跳过：\(result.skippedCount) 条\n当前总记录：\(result.totalCount) 条\n数据已持久化保存。"
                            onImport(result.addedCount)
                        }
                        showImportResult = true
                }
            }
            .alert(importAlertTitle, isPresented: $showImportResult) {
                Button("知道了", role: .cancel) {}
            } message: {
                Text(importAlertMessage)
            }
            .alert("确认清空", isPresented: $showClearConfirm) {
                Button("取消", role: .cancel) {}
                Button("清空全部", role: .destructive) {
                    store.clearAll()
                }
            } message: {
                Text("将删除全部\(store.records.count)条怠速记录，此操作不可恢复。建议先导出备份。")
            }
        }
    }
}

// MARK: - 更新日志


// MARK: - iOS 16 兼容的“所有文件”导入器
private struct AllFileDocumentPicker: UIViewControllerRepresentable {
    let onPick: (URL) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(documentTypes: ["public.item"], in: .import)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: (URL) -> Void

        init(onPick: @escaping (URL) -> Void) {
            self.onPick = onPick
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { return }
            onPick(url)
        }
    }
}
