import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct AddMaintenanceView: View {
    @ObservedObject var store: IdleStore
    var preselectedType: MaintenanceType?
    @Environment(\.dismiss) private var dismiss
    @State private var selectedType: MaintenanceType
    @State private var customName = ""
    @State private var selectedDate = Date()
    @State private var intervalDays: Int
    @State private var noteText = ""

    init(store: IdleStore, preselectedType: MaintenanceType? = nil) {
        self.store = store
        self.preselectedType = preselectedType
        _selectedType = State(initialValue: preselectedType ?? .battery)
        _intervalDays = State(initialValue: (preselectedType ?? .battery).defaultIntervalDays)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("保养类型") {
                    Picker("类型", selection: $selectedType) {
                        ForEach(MaintenanceType.allCases) { type in
                            HStack(spacing: 6) {
                                Image(systemName: type.icon)
                                Text(type.rawValue)
                            }.tag(type)
                        }
                    }
                    .pickerStyle(.menu)
                    .onChange(of: selectedType) { newType in
                        intervalDays = newType.defaultIntervalDays
                    }
                    if selectedType == .custom {
                        TextField("项目名称，如：空气滤芯", text: $customName)
                    }
                }
                Section("更换日期") {
                    DatePicker("选择日期", selection: $selectedDate, displayedComponents: .date)
                        .datePickerStyle(.graphical)
                }
                Section("保养周期") {
                    Stepper(value: $intervalDays, in: 7...3650, step: 30) {
                        HStack {
                            Text("周期")
                            Spacer()
                            Text("\(intervalDays) 天（约\(intervalDays / 30)个月）")
                                .foregroundStyle(.secondary).monospacedDigit()
                        }
                    }
                    Text("到期前30天会在主页提醒，超期显示红色警告")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("备注（可选）") {
                    TextField("如：风帆60Ah，350元", text: $noteText, axis: .vertical)
                        .lineLimit(2...4)
                }
                Section {
                    Button {
                        store.addMaintenanceRecord(
                            type: selectedType,
                            customName: customName,
                            date: selectedDate,
                            intervalDays: intervalDays,
                            note: noteText
                        )
                        dismiss()
                    } label: {
                        HStack { Spacer(); Text("保存记录").bold(); Spacer() }
                    }
                }
            }.proGroupedRows()
            .navigationTitle("记录保养").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItemGroup(placement: .topBarLeading) { Button("取消") { dismiss() } } }
        }
    }
}

// MARK: - 保养记录详情
