import SwiftUI

struct AddHistoryRecordView: View {
    @ObservedObject var store: IdleStore
    @Environment(\.dismiss) private var dismiss
    @State private var date = Date()
    @State private var durationMinutes = 30
    @State private var note = ""
    @State private var showError = false

    var body: some View {
        NavigationStack {
            Form {
                DatePicker("日期时间", selection: $date, in: ...Date())
                Stepper("持续时间：\(durationMinutes)分钟", value: $durationMinutes, in: 1...1440)
                TextField("备注（例如：老家高速回深圳）", text: $note)
            }.proGroupedRows()
            .navigationTitle("添加启动记录")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        if store.addManualRecord(start: date, durationMinutes: durationMinutes, note: note) {
                            dismiss()
                        } else { showError = true }
                    }
                }
            }
            .alert("无法保存", isPresented: $showError) {
                Button("确定", role: .cancel) { }
            } message: { Text("记录结束时间不能超过当前时间，请调整日期或持续时间。") }
        }
    }
}
