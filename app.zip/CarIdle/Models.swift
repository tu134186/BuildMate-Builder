import Foundation

struct IdleRecord: Identifiable, Codable, Equatable {
    var id = UUID()
    var startTime: Date
    var endTime: Date?
    var note: String = ""

    var duration: TimeInterval? {
        guard let end = endTime else { return nil }
        return end.timeIntervalSince(startTime)
    }

    var durationText: String {
        guard let d = duration else { return "进行中" }
        let total = Int(d)
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let seconds = total % 60
        if hours > 0 {
            return "\(hours)小时\(minutes)分"
        }
        if minutes > 0 {
            return "\(minutes)分\(seconds)秒"
        }
        return "\(seconds)秒"
    }

    var dateText: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年M月d日"
        return formatter.string(from: startTime)
    }

    var shortDateText: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "M月d日"
        return formatter.string(from: startTime)
    }

    var startTimeText: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: startTime)
    }

    var endTimeText: String {
        guard let end = endTime else { return "—" }
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: end)
    }

    func daysSince(_ date: Date) -> Int {
        Int(date.timeIntervalSince(startTime) / 86400)
    }
}

// MARK: - 保养类型
enum MaintenanceType: String, Codable, CaseIterable, Identifiable {
    case battery = "电瓶"
    case oil = "机油"
    case tire = "轮胎"
    case insurance = "保险"
    case inspection = "年检"
    case custom = "自定义"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .battery: return "battery.100"
        case .oil: return "drop.fill"
        case .tire: return "circle.hexagonpath.fill"
        case .insurance: return "shield.fill"
        case .inspection: return "doc.text.viewfinder"
        case .custom: return "wrench.fill"
        }
    }

    var defaultIntervalDays: Int {
        switch self {
        case .battery: return 730
        case .oil: return 180
        case .tire: return 365
        case .insurance: return 365
        case .inspection: return 365
        case .custom: return 90
        }
    }
}

// MARK: - 保养记录
struct MaintenanceRecord: Identifiable, Codable, Equatable {
    var id = UUID()
    var type: MaintenanceType
    var customName: String = ""
    var date: Date
    var intervalDays: Int
    var note: String = ""

    var displayName: String {
        type == .custom ? (customName.isEmpty ? "自定义" : customName) : type.rawValue
    }

    var daysSince: Int {
        Int(Date().timeIntervalSince(date) / 86400)
    }

    var daysRemaining: Int {
        intervalDays - daysSince
    }

    var isOverdue: Bool {
        daysRemaining <= 0
    }

    /// 0=正常 1=即将到期(30天内) 2=已超期
    var statusLevel: Int {
        if daysRemaining <= 0 { return 2 }
        if daysRemaining <= 30 { return 1 }
        return 0
    }

    var dateText: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年M月d日"
        return formatter.string(from: date)
    }

    var shortDateText: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "M月d日"
        return formatter.string(from: date)
    }
}

// MARK: - 报表周期
enum ReportPeriod: String, CaseIterable, Identifiable {
    case week = "周报"
    case month = "月报"
    case year = "年报"
    var id: String { rawValue }

    var calendarComponent: Calendar.Component {
        switch self {
        case .week: return .weekOfYear
        case .month: return .month
        case .year: return .year
        }
    }
}

// MARK: - 年检类型
enum InspectionType {
    case online   // 上线检测
    case mobile   // 手机申领检验标志

    var title: String {
        switch self {
        case .online: return "上线检测"
        case .mobile: return "手机申领"
        }
    }

    var icon: String {
        switch self {
        case .online: return "wrench.and.screwdriver"
        case .mobile: return "iphone"
        }
    }

    var color: String {
        switch self {
        case .online: return "red"
        case .mobile: return "blue"
        }
    }
}

// MARK: - 年检结果
struct InspectionResult {
    let date: Date
    let type: InspectionType
    let yearsSinceRegistration: Int

    var dateText: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年M月d日"
        return formatter.string(from: date)
    }

    var shortDateText: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "M月d日"
        return formatter.string(from: date)
    }
}
