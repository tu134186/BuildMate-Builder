import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct ReportView: View {
    @ObservedObject var store: IdleStore
    @Environment(\.dismiss) private var dismiss
    @State private var period: ReportPeriod = .month
    @State private var anchorDate = Date()

    private var records: [IdleRecord] { store.records(in: period, anchor: anchorDate) }

    private var totalDuration: TimeInterval { records.reduce(0) { $0 + ($1.duration ?? 0) } }

    private var totalDurationText: String {
        let total = Int(totalDuration)
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        if hours == 0 { return "\(minutes)分钟" }
        return "\(hours)小时\(minutes)分"
    }

    private var avgDurationText: String {
        guard records.count > 0 else { return "0分钟" }
        let avg = Int(totalDuration) / records.count
        let minutes = avg / 60
        let seconds = avg % 60
        if minutes == 0 { return "\(seconds)秒" }
        return "\(minutes)分\(seconds)秒"
    }

    private var avgIntervalText: String {
        guard records.count >= 2 else { return "—" }
        var intervals: [Double] = []
        let sorted = records.sorted { $0.startTime > $1.startTime }
        for i in 0..<(sorted.count - 1) {
            intervals.append(sorted[i].startTime.timeIntervalSince(sorted[i + 1].startTime) / 86400)
        }
        return String(format: "%.1f天", intervals.reduce(0, +) / Double(intervals.count))
    }

    // 图表数据
    private var chartPoints: [ChartPoint] {
        let calendar = Calendar.current
        let range = store.dateRange(for: period, anchor: anchorDate)
        var points: [ChartPoint] = []

        switch period {
        case .week:
            for dayOffset in 0..<7 {
                let dayStart = calendar.date(byAdding: .day, value: dayOffset, to: range.start)!
                let dayEnd = calendar.date(byAdding: .day, value: 1, to: dayStart)!
                let minutes = records.filter { $0.startTime >= dayStart && $0.startTime < dayEnd }
                    .reduce(0.0) { $0 + ($1.duration ?? 0) / 60 }
                let formatter = DateFormatter()
                formatter.dateFormat = "EEE"
                formatter.locale = Locale(identifier: "zh_CN")
                points.append(ChartPoint(label: formatter.string(from: dayStart), minutes: minutes))
            }
        case .month:
            let days = calendar.dateComponents([.day], from: range.start, to: range.end).day ?? 30
            for dayOffset in 0..<days {
                let dayStart = calendar.date(byAdding: .day, value: dayOffset, to: range.start)!
                let dayEnd = calendar.date(byAdding: .day, value: 1, to: dayStart)!
                let minutes = records.filter { $0.startTime >= dayStart && $0.startTime < dayEnd }
                    .reduce(0.0) { $0 + ($1.duration ?? 0) / 60 }
                let day = calendar.component(.day, from: dayStart)
                points.append(ChartPoint(label: "\(day)", minutes: minutes))
            }
        case .year:
            for monthOffset in 0..<12 {
                let monthStart = calendar.date(byAdding: .month, value: monthOffset, to: range.start)!
                let monthEnd = calendar.date(byAdding: .month, value: 1, to: monthStart)!
                let minutes = records.filter { $0.startTime >= monthStart && $0.startTime < monthEnd }
                    .reduce(0.0) { $0 + ($1.duration ?? 0) / 60 }
                let m = calendar.component(.month, from: monthStart)
                points.append(ChartPoint(label: "\(m)月", minutes: minutes))
            }
        }
        return points
    }

    private var reportText: String {
        let title = "\(store.periodTitle(for: period, anchor: anchorDate))\(period.rawValue)"
        var lines = ["【\(title)】", ""]
        lines.append("总次数：\(records.count)次")
        lines.append("总时长：\(totalDurationText)")
        lines.append("平均时长：\(avgDurationText)")
        lines.append("平均间隔：\(avgIntervalText)")
        lines.append("")
        if records.isEmpty { lines.append("本周期暂无记录") }
        else {
            lines.append("——明细——")
            for r in records {
                var line = "\(r.shortDateText) \(r.startTimeText) → \(r.endTimeText)  \(r.durationText)"
                if !r.note.isEmpty { line += "  备注：\(r.note)" }
                lines.append(line)
            }
        }
        return lines.joined(separator: "\n")
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    Picker("报表周期", selection: $period) {
                        ForEach(ReportPeriod.allCases) { p in Text(p.rawValue).tag(p) }
                    }
                    .pickerStyle(.segmented).padding(.horizontal, 4)

                    HStack {
                        Button { anchorDate = store.shiftPeriod(period, anchor: anchorDate, by: -1) } label: {
                            Image(systemName: "chevron.left.circle.fill").font(.title2).foregroundStyle(.blue)
                        }.buttonStyle(.plain)
                        Spacer()
                        Text(store.periodTitle(for: period, anchor: anchorDate)).font(.headline).monospacedDigit()
                        Spacer()
                        Button { anchorDate = store.shiftPeriod(period, anchor: anchorDate, by: 1) } label: {
                            Image(systemName: "chevron.right.circle.fill").font(.title2).foregroundStyle(.blue)
                        }.buttonStyle(.plain)
                    }.padding(.horizontal, 8)

                    // 趋势图
                    VStack(alignment: .leading, spacing: 8) {
                        Text("怠速时长趋势").font(.subheadline.bold()).foregroundStyle(.secondary)
                        if chartPoints.contains(where: { $0.minutes > 0 }) {
                            Chart(chartPoints) { point in
                                BarMark(
                                    x: .value("时间", point.label),
                                    y: .value("分钟", point.minutes)
                                )
                                .foregroundStyle(Color.blue)
                                .cornerRadius(3)
                            }
                            .chartYAxis {
                                AxisMarks(position: .leading)
                            }
                            .chartXAxis {
                                AxisMarks(position: .bottom)
                            }
                            .frame(height: 180)
                        } else {
                            VStack(spacing: 8) {
                                Image(systemName: "chart.bar").font(.system(size: 32)).foregroundStyle(.secondary)
                                Text("本周期暂无数据").font(.subheadline).foregroundStyle(.secondary)
                            }
                            .frame(maxWidth: .infinity).padding(.vertical, 30)
                        }
                    }
                    .padding(16)
                    .background(AppleDesign.surface)
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                    // 统计卡片
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        ReportStatCard(value: "\(records.count)", label: "总次数", icon: "number.circle", color: .blue)
                        ReportStatCard(value: totalDurationText, label: "总时长", icon: "clock", color: .green)
                        ReportStatCard(value: avgDurationText, label: "平均时长", icon: "timer", color: .orange)
                        ReportStatCard(value: avgIntervalText, label: "平均间隔", icon: "calendar", color: .purple)
                    }

                    // 明细
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text("明细记录").font(.subheadline.bold()).foregroundStyle(.secondary)
                            Spacer()
                            ShareLink(item: reportText) {
                                HStack(spacing: 4) {
                                    Image(systemName: "square.and.arrow.up")
                                    Text("分享").font(.caption)
                                }.foregroundStyle(.blue)
                            }
                        }.padding(.horizontal, 4)

                        if records.isEmpty {
                            VStack(spacing: 10) {
                                Image(systemName: "doc.text.magnifyingglass").font(.system(size: 36)).foregroundStyle(.secondary)
                                Text("本周期暂无记录").font(.subheadline).foregroundStyle(.secondary)
                            }.frame(maxWidth: .infinity).padding(.vertical, 40)
                        } else {
                            VStack(spacing: 8) {
                                ForEach(records) { record in
                                    VStack(alignment: .leading, spacing: 3) {
                                        HStack(spacing: 6) {
                                            Text(record.shortDateText).font(.subheadline.bold())
                                            if let interval = store.intervalDays(for: record) {
                                                Text("间隔\(interval)天").font(.caption2).foregroundStyle(.secondary)
                                                    .padding(.horizontal, 5).padding(.vertical, 1)
                                                    .background(Color.secondary.opacity(0.15)).clipShape(Capsule())
                                            }
                                            Spacer()
                                            Text(record.durationText).font(.subheadline.bold()).foregroundStyle(AppleDesign.positive)
                                        }
                                        Text("\(record.startTimeText) → \(record.endTimeText)").font(.caption).foregroundStyle(.secondary)
                                        if !record.note.isEmpty {
                                            Text(record.note).font(.caption).foregroundStyle(.orange).lineLimit(2)
                                        }
                                    }
                                    .padding(12)
                                    .background(AppleDesign.inset)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                }
                            }
                        }
                    }
                    .padding(16)
                    .background(AppleDesign.surface)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                }
                .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 20)
            }
            .background(AppleDesign.background)
            .navigationTitle("生成报表").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItemGroup(placement: .topBarLeading) { Button("返回") { dismiss() } } }
        }
    }
}

