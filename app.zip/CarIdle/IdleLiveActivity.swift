import Foundation
import ActivityKit

struct IdleActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var startTime: Date
        var targetMinutes: Int
    }
    var title: String
}

@MainActor
final class IdleLiveActivity {
    static let shared = IdleLiveActivity()
    private init() {}
    private var enabled: Bool { UserDefaults.standard.object(forKey: "liveActivityEnabled") as? Bool ?? true }

    func sync(start: Date?, targetMinutes: Int) {
        guard enabled, let start = start else {
            endAll()
            return
        }
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { return }
        let state = IdleActivityAttributes.ContentState(startTime: start, targetMinutes: targetMinutes)
        if let existing = Activity<IdleActivityAttributes>.activities.first {
            if existing.content.state.startTime == start && existing.content.state.targetMinutes == targetMinutes { return }
            Task {
                await existing.update(ActivityContent(state: state, staleDate: nil))
            }
        } else {
            do {
                _ = try Activity<IdleActivityAttributes>.request(
                    attributes: IdleActivityAttributes(title: "发动机运行中"),
                    content: ActivityContent(state: state, staleDate: nil),
                    pushType: nil
                )
            } catch {
                NSLog("[CarIdle] Live Activity start failed: %@", String(describing: error))
            }
        }
    }

    func endAll() {
        Task {
            for activity in Activity<IdleActivityAttributes>.activities {
                await activity.end(nil, dismissalPolicy: .immediate)
            }
        }
    }
}
