import Foundation
import ActivityKit

struct IdleActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var startTime: Date
        var targetMinutes: Int
    }
    var title: String
}

@MainActor
final class IdleLiveActivity {
    static let shared = IdleLiveActivity()
    private init() {}
    private var enabled: Bool { UserDefaults.standard.object(forKey: "liveActivityEnabled") as? Bool ?? true }
    // 常驻轻量刷新任务：配合 Info.plist 的 NSSupportsLiveActivitiesFrequentUpdates，
    // 让灵动岛/锁屏上的倒计时像系统计时器一样持续走动。
    private var refreshTask: Task<Void, Never>?

    func sync(start: Date?, targetMinutes: Int) {
        guard enabled, let start = start else {
            endAll()
            return
        }
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { return }
        let state = IdleActivityAttributes.ContentState(startTime: start, targetMinutes: targetMinutes)
        if let existing = Activity<IdleActivityAttributes>.activities.first {
            if existing.content.state.startTime == start && existing.content.state.targetMinutes == targetMinutes {
                startRefreshIfNeeded(state: state)
                return
            }
            Task {
                await existing.update(ActivityContent(state: state, staleDate: nil))
                startRefreshIfNeeded(state: state)
            }
        } else {
            do {
                _ = try Activity<IdleActivityAttributes>.request(
                    attributes: IdleActivityAttributes(title: "计时器"),
                    content: ActivityContent(state: state, staleDate: nil),
                    pushType: nil
                )
                startRefreshIfNeeded(state: state)
            } catch {
                NSLog("[CarIdle] Live Activity start failed: %@", String(describing: error))
            }
        }
    }

    func endAll() {
        stopRefresh()
        Task {
            for activity in Activity<IdleActivityAttributes>.activities {
                await activity.end(nil, dismissalPolicy: .immediate)
            }
        }
    }

    private func startRefreshIfNeeded(state: IdleActivityAttributes.ContentState) {
        guard refreshTask == nil else { return }
        refreshTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(10))
                guard !Task.isCancelled else { return }
                for activity in Activity<IdleActivityAttributes>.activities {
                    await activity.update(ActivityContent(state: state, staleDate: nil))
                }
                if Activity<IdleActivityAttributes>.activities.isEmpty {
                    self?.stopRefresh()
                    return
                }
            }
        }
    }

    private func stopRefresh() {
        refreshTask?.cancel()
        refreshTask = nil
    }
}
