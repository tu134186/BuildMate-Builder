import SwiftUI
import UIKit

@main
struct CarIdleApp: App {
    init() {
        UITableView.appearance().backgroundColor = UIColor(red: 0.955, green: 0.969, blue: 0.989, alpha: 1)
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor(red: 0.09, green: 0.16, blue: 0.26, alpha: 1)]
    }
    var body: some Scene {
        WindowGroup {
            ContentView()
                .appleScreenStyle()
        }
    }
}
