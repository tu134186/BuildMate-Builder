import Foundation

// ZIP store mode (method 0), valid for Xcode source archives without external dependencies.
enum TargetProjectExporter {
    enum ExportError: LocalizedError { case tooLarge
        var errorDescription: String? { "导出文件过大" }
    }
    static func export(_ project: DesignProject) throws -> URL {
        let root = "GeneratedApp/"
        let safeName = "GeneratedApp"
        let yml = """
        name: GeneratedApp
        options:
          bundleIdPrefix: com.generated
          deploymentTarget:
            iOS: '16.0'
        settings:
          base:
            SWIFT_VERSION: '5.9'
            CODE_SIGNING_ALLOWED: 'NO'
        targets:
          GeneratedApp:
            type: application
            platform: iOS
            sources: [Sources]
            settings:
              base:
                PRODUCT_BUNDLE_IDENTIFIER: com.generated.uistudioapp
                INFOPLIST_KEY_CFBundleDisplayName: GeneratedApp
                INFOPLIST_KEY_UILaunchScreen_Generation: 'YES'
                GENERATE_INFOPLIST_FILE: 'YES'
                MARKETING_VERSION: 1.0.0
                CURRENT_PROJECT_VERSION: 1
        """
        let app = """
        import SwiftUI
        @main struct GeneratedAppMain: App {
            var body: some Scene { WindowGroup { StudioGeneratedRoot() } }
        }
        """
        let readme = """
        # UIStudio Pro generated project
        Source project: \(project.name)
        This is a SwiftUI UI scaffold. Business logic and real data are not generated.
        Build: run `xcodegen generate` and build GeneratedApp.xcodeproj with Xcode.
        """
        let data = try JSONEncoder().encode(project)
        let entries: [(String, Data)] = [
            (root + "project.yml", Data(yml.utf8)),
            (root + "Sources/GeneratedAppMain.swift", Data(app.utf8)),
            (root + "Sources/GeneratedViews.swift", Data(SwiftSourceGenerator.generate(project).utf8)),
            (root + "Design/project.json", data),
            (root + "README.md", Data(readme.utf8))
        ]
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(safeName)-\(project.id.uuidString.prefix(8)).zip")
        try StoredZIP.write(entries, to: url)
        return url
    }
}

enum StoredZIP {
    private static func u16(_ n: UInt16) -> Data { Data([UInt8(n & 255), UInt8((n >> 8) & 255)]) }
    private static func u32(_ n: UInt32) -> Data { u16(UInt16(n & 65535)) + u16(UInt16((n >> 16) & 65535)) }
    private static func crc32(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xFFFFFFFF
        for b in data {
            crc ^= UInt32(b)
            for _ in 0..<8 { crc = (crc >> 1) ^ ((crc & 1) == 1 ? 0xEDB88320 : 0) }
        }
        return ~crc
    }
    static func write(_ files: [(String, Data)], to url: URL) throws {
        var body = Data(), directory = Data()
        for (path, payload) in files {
            let name = Data(path.utf8)
            guard name.count <= 65535, payload.count <= Int(UInt32.max), body.count <= Int(UInt32.max) else { throw TargetProjectExporter.ExportError.tooLarge }
            let size = UInt32(payload.count), crc = crc32(payload), offset = UInt32(body.count)
            body += u32(0x04034B50) + u16(20) + u16(0x0800) + u16(0) + u16(0) + u16(0)
            body += u32(crc) + u32(size) + u32(size) + u16(UInt16(name.count)) + u16(0)
            body += name + payload
            directory += u32(0x02014B50) + u16(20) + u16(20) + u16(0x0800) + u16(0) + u16(0) + u16(0)
            directory += u32(crc) + u32(size) + u32(size) + u16(UInt16(name.count))
            directory += u16(0) + u16(0) + u16(0) + u16(0) + u32(0) + u32(offset) + name
        }
        guard files.count <= 65535, body.count <= Int(UInt32.max), directory.count <= Int(UInt32.max) else { throw TargetProjectExporter.ExportError.tooLarge }
        let end = u32(0x06054B50) + u16(0) + u16(0) + u16(UInt16(files.count)) + u16(UInt16(files.count)) + u32(UInt32(directory.count)) + u32(UInt32(body.count)) + u16(0)
        try (body + directory + end).write(to: url, options: .atomic)
    }
}
