import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct ProjectEditor: View {
    @EnvironmentObject var store: StudioStore
    let projectID: UUID
    @State private var pageIndex = 0
    @State private var selected: UUID?
    @State private var showComponents = false
    @State private var showCode = false
    @State private var showAddPage = false
    @State private var pageName = "新页面"
    @State private var history: [DesignProject] = []
    @State private var future: [DesignProject] = []
    @State private var showRenamePage = false
    @State private var renameValue = ""
    @State private var showPreview = false
    @State private var showInspector = false
    @State private var showLayers = false
    @State private var deviceWidth: CGFloat = 320
    @State private var draggingID: UUID?
    @State private var showDeletePage = false
    @State private var showLayoutHelp = false
    private var project: DesignProject? { store.projects.first(where: { $0.id == projectID }) }
    var body: some View {
        Group {
            if let project = project, !project.pages.isEmpty {
                VStack(spacing: 0) {
                    HStack {
                        TextField("项目名称", text: Binding(get: { project.name }, set: { name in mutate { $0.name = name } })).font(.headline)
                        Button { showCode = true } label: { Label("代码", systemImage: "chevron.left.forwardslash.chevron.right") }.buttonStyle(.bordered)
                    }.padding(.horizontal).padding(.top, 8)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(Array(project.pages.enumerated()), id: \.element.id) { index, page in
                                Button(page.name) { pageIndex = index; selected = nil }.buttonStyle(.borderedProminent).tint(pageIndex == index ? .blue : .gray)
                                    .contextMenu { Button("重命名") { pageIndex = index; renameValue = page.name; showRenamePage = true }; Button("复制页面") { duplicatePage(at: index) }; Button("删除页面", role: .destructive) { pageIndex = index; showDeletePage = true }.disabled(project.pages.count <= 1) }
                            }
                            Button { showAddPage = true } label: { Image(systemName: "plus") }.buttonStyle(.bordered)
                        }.padding(.horizontal)
                    }.padding(.vertical, 10)
                    HStack(spacing: 12) {
                        Button { undo() } label: { Image(systemName: "arrow.uturn.backward") }.disabled(history.isEmpty)
                        Button { redo() } label: { Image(systemName: "arrow.uturn.forward") }.disabled(future.isEmpty)
                        Spacer()
                        Button { mutate { p in
                            let enabling = !(p.pages[pageIndex].freeLayout ?? false)
                            p.pages[pageIndex].freeLayout = enabling
                            if enabling { for i in p.pages[pageIndex].elements.indices {
                                if p.pages[pageIndex].elements[i].freeX == nil { p.pages[pageIndex].elements[i].freeX = Double(deviceWidth / 2) }
                                if p.pages[pageIndex].elements[i].freeY == nil { p.pages[pageIndex].elements[i].freeY = Double(50 + i * 75) }
                                if p.pages[pageIndex].elements[i].freeWidth == nil { p.pages[pageIndex].elements[i].freeWidth = 230 }
                            } }
                        } } label: { Label(project.pages[pageIndex].freeLayout == true ? "自由" : "堆叠", systemImage: "rectangle.dashed") }
                        Button { showLayers = true } label: { Label("图层", systemImage: "square.3.layers.3d") }
                        Button { showPreview = true } label: { Image(systemName: "eye") }
                        Button { showComponents = true } label: { Image(systemName: "plus.circle.fill").font(.title3) }
                    }.buttonStyle(.bordered).padding(.horizontal).padding(.vertical, 8)
                    HStack {
                        Label("设计画布", systemImage: "iphone.gen3") .font(.subheadline.bold())
                        Spacer()
                        Picker("设备宽度", selection: $deviceWidth) {
                            Text("紧凑").tag(CGFloat(290))
                            Text("标准").tag(CGFloat(320))
                            Text("宽屏").tag(CGFloat(360))
                        }.pickerStyle(.menu)
                    }.padding(.horizontal)
                    ScrollView {
                        VStack(spacing: 0) {
                            HStack { Text("9:41"); Spacer(); Image(systemName: "wifi"); Image(systemName: "battery.100percent") }
                                .font(.system(size: 11, weight: .semibold)).padding(.horizontal, 20).padding(.top, 14)
                            Capsule().fill(Color.black).frame(width: 92, height: 25).padding(.top, -12)
                            Text(project.pages[min(pageIndex, project.pages.count - 1)].name).font(.headline).padding(.top, 14)
                            Group {
                                if project.pages[pageIndex].freeLayout == true {
                                    ZStack(alignment: .topLeading) {
                                        Color.clear.frame(height: 550)
                                        ForEach(project.pages[pageIndex].elements) { element in
                                            let width = min(max(element.freeWidth ?? 230, 70), Double(deviceWidth - 30))
                                            ElementPreview(element: element)
                                                .frame(width: width)
                                                .overlay(RoundedRectangle(cornerRadius: 9).stroke(selected == element.id ? .cyan : .clear, lineWidth: 2))
                                                .overlay(alignment: .topLeading) { if selected == element.id { Circle().fill(.cyan).frame(width: 10, height: 10).offset(x: -4, y: -4) } }
                                                .position(x: min(max(element.freeX ?? Double(deviceWidth / 2), width / 2), Double(deviceWidth) - width / 2), y: min(max(element.freeY ?? 55, element.height / 2), 550 - element.height / 2))
                                                .onTapGesture { selected = element.id; showInspector = true }
                                                .gesture(DragGesture(minimumDistance: 5, coordinateSpace: .named("freeCanvas")).onChanged { value in
                                                    if selected != element.id { selected = element.id }
                                                    let x = min(max(value.location.x, width / 2), Double(deviceWidth) - width / 2)
                                                    let y = min(max(value.location.y, element.height / 2), 550 - element.height / 2)
                                                    updatePosition(element.id, x: x, y: y)
                                                })
                                        }
                                    }.frame(width: deviceWidth, height: 550).coordinateSpace(name: "freeCanvas")
                                } else {
                                    VStack(spacing: 12) {
                                        ForEach(project.pages[pageIndex].elements) { element in
                                            ElementPreview(element: element)
                                                .padding(5)
                                                .overlay(RoundedRectangle(cornerRadius: 9).stroke(selected == element.id ? .cyan : .clear, lineWidth: 2))
                                                .contentShape(Rectangle())
                                                .onTapGesture { selected = element.id; showInspector = true }
                                                .onDrag { draggingID = element.id; return NSItemProvider(object: element.id.uuidString as NSString) }
                                                .onDrop(of: [.text], isTargeted: nil) { _ in
                                                    guard let dragged = draggingID, dragged != element.id else { return false }
                                                    mutate { p in
                                                        let list = p.pages[pageIndex].elements
                                                        if let i = list.firstIndex(where: { $0.id == dragged }), let j = list.firstIndex(where: { $0.id == element.id }) { p.pages[pageIndex].elements.move(fromOffsets: IndexSet(integer: i), toOffset: j > i ? j + 1 : j) }
                                                    }
                                                    draggingID = nil
                                                    return true
                                                }
                                        }
                                    }.padding(14).frame(maxWidth: .infinity).frame(minHeight: 350, alignment: .top)
                                }
                            }
                            if project.pages[pageIndex].elements.isEmpty {
                                Button("＋ 添加第一个组件") { showComponents = true }.padding(.vertical, 30)
                            }
                            Spacer(minLength: 18)
                            Capsule().fill(.white.opacity(0.7)).frame(width: 100, height: 4).padding(.bottom, 9)
                        }
                        .frame(width: deviceWidth)
                        .background(Color(red: 0.06, green: 0.09, blue: 0.15), in: RoundedRectangle(cornerRadius: 32))
                        .overlay(RoundedRectangle(cornerRadius: 32).stroke(.white.opacity(0.24), lineWidth: 2))
                        .padding(.vertical, 12)
                        Text("长按拖动组件排序 · 点击组件编辑属性").font(.caption).foregroundStyle(.secondary).padding(.bottom, 12)
                    }.frame(maxWidth: .infinity)
                }
                .sheet(isPresented: $showInspector) {
                    NavigationStack {
                        ScrollView {
                            if let current = self.project, current.pages.indices.contains(pageIndex),
                               let id = selected, let element = current.pages[pageIndex].elements.first(where: { $0.id == id }) {
                                ElementInspector(element: element, freeLayout: current.pages[pageIndex].freeLayout == true, onChange: { edited in
                                    mutate { p in if let idx = p.pages[pageIndex].elements.firstIndex(where: { $0.id == id }) { p.pages[pageIndex].elements[idx] = edited } }
                                }, onDuplicate: {
                                    mutate { p in guard let i = p.pages[pageIndex].elements.firstIndex(where: { $0.id == id }) else { return }; var copy = p.pages[pageIndex].elements[i]; copy.id = UUID(); p.pages[pageIndex].elements.insert(copy, at: i + 1); selected = copy.id }
                                }, onDelete: {
                                    mutate { $0.pages[pageIndex].elements.removeAll(where: { $0.id == id }) }; selected = nil; showInspector = false
                                }, onMove: { direction in moveElement(id, direction) })
                            }
                        }.padding(.top).navigationTitle("组件属性").navigationBarTitleDisplayMode(.inline)
                            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("完成") { showInspector = false } } }
                    }.presentationDetents([.medium, .large])
                }
                .sheet(isPresented: $showLayers) {
                    NavigationStack {
                        List {
                            ForEach(project.pages[pageIndex].elements) { element in
                                Button { selected = element.id; showLayers = false; showInspector = true } label: {
                                    HStack { Image(systemName: "square.3.layers.3d"); Text(element.title); Spacer(); Image(systemName: "chevron.right") }
                                }
                            }.onMove { source, destination in mutate { $0.pages[pageIndex].elements.move(fromOffsets: source, toOffset: destination) } }
                        }.environment(\.editMode, .constant(.active))
                        .navigationTitle("图层排序")
                        .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("完成") { showLayers = false } } }
                    }
                }
                .sheet(isPresented: $showComponents) { ComponentPicker { kind in
                    let labels = ["title":"新标题", "text":"文本内容", "card":"信息卡片", "button":"点击按钮", "toggle":"开关选项", "divider":"分隔线", "image":"photo", "badge":"状态标签", "progress":"完成进度", "field":"输入内容", "icon":"star.fill", "spacer":"间距"]
                    var element = DesignElement(kind: kind, title: labels[kind] ?? "组件", height: kind == "card" ? 110 : 54)
                    if project.pages[pageIndex].freeLayout == true { element.freeX = Double(deviceWidth / 2); element.freeY = Double(75 + (project.pages[pageIndex].elements.count % 6) * 65); element.freeWidth = 230 }
                    mutate { $0.pages[pageIndex].elements.append(element) }; selected = element.id; showComponents = false
                }.presentationDetents([.medium, .large]) }
                .sheet(isPresented: $showCode) { CodeExportView(project: project) }
                .sheet(isPresented: $showPreview) { NavigationStack { ScrollView { VStack(spacing: 12) { ForEach(project.pages[min(pageIndex, project.pages.count - 1)].elements) { ElementPreview(element: $0) } }.padding() }.background(Color(red: 0.06, green: 0.09, blue: 0.15)).navigationTitle("页面预览").toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("关闭") { showPreview = false } } } } }
                .alert("重命名页面", isPresented: $showRenamePage) { TextField("页面名称", text: $renameValue); Button("保存") { let name = renameValue.trimmingCharacters(in: .whitespacesAndNewlines); guard !name.isEmpty else { return }; mutate { $0.pages[pageIndex].name = name } }; Button("取消", role: .cancel) {} }
                .confirmationDialog("删除当前页面？", isPresented: $showDeletePage) {
                    Button("删除页面", role: .destructive) { mutate { p in if p.pages.count > 1 && p.pages.indices.contains(pageIndex) { p.pages.remove(at: pageIndex) } }; pageIndex = max(0, min(pageIndex, (self.project?.pages.count ?? 1) - 1)); selected = nil }
                }
                .alert("添加页面", isPresented: $showAddPage) {
                    TextField("页面名称", text: $pageName)
                    Button("添加") { let name = pageName.trimmingCharacters(in: .whitespacesAndNewlines); guard !name.isEmpty else { return }; mutate { $0.pages.append(DesignPage(name: name, elements: [])) }; if let count = self.project?.pages.count { pageIndex = count - 1 }; pageName = "新页面" }
                    Button("取消", role: .cancel) { }
                }
            } else { Text("项目不存在").foregroundStyle(.secondary) }
        }.navigationTitle("可视化编辑器").navigationBarTitleDisplayMode(.inline)
         
    }
    private func updatePosition(_ id: UUID, x: Double, y: Double) {
        guard var p = project, p.pages.indices.contains(pageIndex), let index = p.pages[pageIndex].elements.firstIndex(where: { $0.id == id }) else { return }
        p.pages[pageIndex].elements[index].freeX = x
        p.pages[pageIndex].elements[index].freeY = y
        store.update(p)
    }
    private func moveElement(_ id: UUID, _ direction: Int) {
        mutate { p in
            guard let i = p.pages[pageIndex].elements.firstIndex(where: { $0.id == id }) else { return }
            let j = i + direction
            if p.pages[pageIndex].elements.indices.contains(j) { p.pages[pageIndex].elements.swapAt(i, j) }
        }
    }
    private func mutate(_ block: (inout DesignProject) -> Void) {
        guard var p = project else { return }
        history.append(p); if history.count > 30 { history.removeFirst() }; future.removeAll()
        block(&p); store.update(p)
    }
    private func undo() { guard let old = history.popLast(), let current = project else { return }; future.append(current); store.update(old); if pageIndex >= old.pages.count { pageIndex = 0 }; selected = nil }
    private func redo() { guard let next = future.popLast(), let current = project else { return }; history.append(current); store.update(next); if pageIndex >= next.pages.count { pageIndex = 0 }; selected = nil }
    private func duplicatePage(at index: Int) { guard let p = project, p.pages.indices.contains(index) else { return }; var copy = p.pages[index]; copy.id = UUID(); copy.name += " 副本"; mutate { $0.pages.insert(copy, at: index + 1) }; pageIndex = index + 1; selected = nil }
}

struct ElementPreview: View {
    let element: DesignElement
    var body: some View {
        Group {
            switch element.kind {
            case "title": Text(element.title).font(.system(size: element.fontSize, weight: .bold)).frame(maxWidth: .infinity, alignment: .leading)
            case "text": Text(element.title).font(.system(size: element.fontSize)).frame(maxWidth: .infinity, alignment: .leading)
            case "card": HStack { Image(systemName: "car.side.fill").font(.title).foregroundStyle(.cyan); Text(element.title).font(.system(size: element.fontSize, weight: .semibold)); Spacer() }.padding().frame(maxWidth: .infinity).background(Color(hex: element.colorHex), in: RoundedRectangle(cornerRadius: element.cornerRadius))
            case "button": Text(element.title).font(.system(size: element.fontSize, weight: .semibold)).frame(maxWidth: .infinity).background(Color(hex: element.colorHex), in: RoundedRectangle(cornerRadius: element.cornerRadius))
            case "toggle": HStack { Text(element.title).font(.system(size: element.fontSize)); Spacer(); Image(systemName: "switch.2").foregroundStyle(.green) }.padding(.horizontal).background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: element.cornerRadius))
            case "image": Image(systemName: element.title.isEmpty ? "photo" : element.title).resizable().scaledToFit().foregroundStyle(Color(hex: element.colorHex)).frame(maxWidth: .infinity)
            case "icon": Image(systemName: element.title.isEmpty ? "star.fill" : element.title).font(.system(size: element.fontSize + 14)).foregroundStyle(Color(hex: element.colorHex)).frame(maxWidth: .infinity)
            case "badge": Text(element.title).font(.system(size: element.fontSize, weight: .medium)).padding(.horizontal, 14).background(Color(hex: element.colorHex), in: Capsule()).frame(maxWidth: .infinity, alignment: .leading)
            case "progress": VStack(alignment: .leading) { Text(element.title).font(.caption); ProgressView(value: 0.65).tint(Color(hex: element.colorHex)) }
            case "field": HStack { Text(element.title).foregroundStyle(.secondary); Spacer(); Image(systemName: "pencil") }.padding(.horizontal).background(.white.opacity(0.1), in: RoundedRectangle(cornerRadius: element.cornerRadius))
            case "spacer": Color.clear
            default: Rectangle().fill(.white.opacity(0.25)).frame(height: 1)
            }
        }.frame(height: element.kind == "divider" ? 12 : element.height)
    }
}

struct ComponentPicker: View {
    var onSelect: (String) -> Void
    let items: [(String, String, String)] = [("title","标题","textformat.size"),("text","文本","text.alignleft"),("card","卡片","rectangle.on.rectangle"),("button","按钮","hand.tap"),("toggle","开关","switch.2"),("divider","分隔线","minus"),("image","图片占位","photo"),("icon","SF 图标","star.fill"),("badge","状态标签","tag.fill"),("progress","进度条","chart.bar.fill"),("field","输入框","rectangle.and.pencil.and.ellipsis"),("spacer","空白间距","arrow.up.and.down")]
    var body: some View {
        NavigationStack {
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) {
                ForEach(items, id: \.0) { item in
                    Button { onSelect(item.0) } label: { VStack(spacing: 10) { Image(systemName: item.2).font(.title2); Text(item.1) }.frame(maxWidth: .infinity).frame(height: 90).background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14)) }.buttonStyle(.plain)
                }
            }.padding().navigationTitle("组件库").navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct ElementInspector: View {
    let element: DesignElement
    var freeLayout: Bool = false
    var onChange: (DesignElement) -> Void
    var onDuplicate: () -> Void
    var onDelete: () -> Void
    var onMove: (Int) -> Void
    var body: some View {
        VStack(spacing: 8) {
            HStack { Text("属性编辑").font(.headline); Spacer(); Button { onMove(-1) } label: { Image(systemName: "arrow.up") }; Button { onMove(1) } label: { Image(systemName: "arrow.down") }; Button(action: onDuplicate) { Image(systemName: "plus.square.on.square") }.accessibilityLabel("复制组件"); Button(role: .destructive, action: onDelete) { Image(systemName: "trash") } }.padding(.bottom, 4)
            TextField("文字内容", text: Binding(get: { element.title }, set: { var e = element; e.title = $0; onChange(e) })).textFieldStyle(.roundedBorder)
            HStack { Text("字号 \(Int(element.fontSize))"); Slider(value: Binding(get: { element.fontSize }, set: { var e = element; e.fontSize = $0; onChange(e) }), in: 12...36) }
            if freeLayout {
                HStack { Text("宽度 \(Int(element.freeWidth ?? 230))"); Slider(value: Binding(get: { element.freeWidth ?? 230 }, set: { var e = element; e.freeWidth = $0; onChange(e) }), in: 70...320) }
                HStack { Text("横坐标 \(Int(element.freeX ?? 160))"); Slider(value: Binding(get: { element.freeX ?? 160 }, set: { var e = element; e.freeX = $0; onChange(e) }), in: 40...320) }
                HStack { Text("纵坐标 \(Int(element.freeY ?? 55))"); Slider(value: Binding(get: { element.freeY ?? 55 }, set: { var e = element; e.freeY = $0; onChange(e) }), in: 30...520) }
            }
            HStack { Text("高度 \(Int(element.height))"); Slider(value: Binding(get: { element.height }, set: { var e = element; e.height = $0; onChange(e) }), in: 32...220) }
            HStack { Text("圆角 \(Int(element.cornerRadius))"); Slider(value: Binding(get: { element.cornerRadius }, set: { var e = element; e.cornerRadius = $0; onChange(e) }), in: 0...36) }
            HStack { Text("背景色"); Spacer(); ForEach(["#1877F2","#173C67","#7C3AED","#059669","#EA580C"], id: \.self) { hex in Button { var e = element; e.colorHex = hex; onChange(e) } label: { Circle().fill(Color(hex: hex)).frame(width: 26, height: 26).overlay(Circle().stroke(.white, lineWidth: element.colorHex == hex ? 2 : 0)) } } }
        }.font(.subheadline).padding().background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16)).padding(.horizontal).padding(.bottom, 8)
    }
}
