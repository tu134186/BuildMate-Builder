import SwiftUI
import UIKit

struct ProjectEditor: View {
    @EnvironmentObject var store: StudioStore
    let projectID: UUID
    @State private var pageIndex = 0
    @State private var selected: UUID?
    @State private var showComponents = false
    @State private var showCode = false
    @State private var showAddPage = false
    @State private var pageName = "新页面"
    @State private var history: [DesignProject] = []
    private var project: DesignProject? { store.projects.first(where: { $0.id == projectID }) }
    var body: some View {
        Group {
            if let project = project, !project.pages.isEmpty {
                VStack(spacing: 0) {
                    HStack {
                        TextField("项目名称", text: Binding(get: { project.name }, set: { name in mutate { $0.name = name } })).font(.headline)
                        Button { showCode = true } label: { Label("代码", systemImage: "chevron.left.forwardslash.chevron.right") }.buttonStyle(.bordered)
                    }.padding(.horizontal).padding(.top, 8)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(Array(project.pages.enumerated()), id: \.element.id) { index, page in
                                Button(page.name) { pageIndex = index; selected = nil }.buttonStyle(.borderedProminent).tint(pageIndex == index ? .blue : .gray)
                            }
                            Button { showAddPage = true } label: { Image(systemName: "plus") }.buttonStyle(.bordered)
                        }.padding(.horizontal)
                    }.padding(.vertical, 10)
                    ScrollView {
                        VStack(spacing: 12) {
                            HStack { Text("实时画布").font(.caption.bold()); Spacer(); Text("点选组件进行编辑").font(.caption).foregroundStyle(.secondary) }
                            VStack(spacing: 12) {
                                ForEach(project.pages[min(pageIndex, project.pages.count - 1)].elements) { element in
                                    ElementPreview(element: element)
                                        .overlay(RoundedRectangle(cornerRadius: element.cornerRadius).stroke(selected == element.id ? Color.blue : .clear, lineWidth: 2))
                                        .contentShape(Rectangle())
                                        .onTapGesture { selected = element.id }
                                }
                                if project.pages[pageIndex].elements.isEmpty { VStack { Image(systemName: "square.dashed"); Text("空白页面 · 点击下方添加组件") }.foregroundStyle(.secondary).frame(height: 140) }
                            }.padding(18).frame(maxWidth: .infinity).background(Color(red: 0.06, green: 0.09, blue: 0.15), in: RoundedRectangle(cornerRadius: 24))
                        }.padding()
                    }
                    HStack(spacing: 12) {
                        Button { undo() } label: { Label("撤销", systemImage: "arrow.uturn.backward") }.disabled(history.isEmpty)
                        Spacer()
                        Button { showComponents = true } label: { Label("添加组件", systemImage: "plus.square.fill") }.buttonStyle(.borderedProminent)
                    }.padding(.horizontal).padding(.vertical, 8)
                    if let selected = selected, let element = project.pages[pageIndex].elements.first(where: { $0.id == selected }) {
                        ElementInspector(element: element, onChange: { edited in
                            mutate { p in if let idx = p.pages[pageIndex].elements.firstIndex(where: { $0.id == selected }) { p.pages[pageIndex].elements[idx] = edited } }
                        }, onDelete: {
                            mutate { $0.pages[pageIndex].elements.removeAll(where: { $0.id == selected }) }; self.selected = nil
                        }, onMove: { direction in
                            mutate { p in
                                guard let i = p.pages[pageIndex].elements.firstIndex(where: { $0.id == selected }) else { return }
                                let j = i + direction
                                if p.pages[pageIndex].elements.indices.contains(j) { p.pages[pageIndex].elements.swapAt(i, j) }
                            }
                        })
                    }
                }
                .sheet(isPresented: $showComponents) { ComponentPicker { kind in
                    let labels = ["title":"新标题", "text":"文本内容", "card":"信息卡片", "button":"点击按钮", "toggle":"开关选项", "divider":"分隔线"]
                    let element = DesignElement(kind: kind, title: labels[kind] ?? "组件", height: kind == "card" ? 110 : 54)
                    mutate { $0.pages[pageIndex].elements.append(element) }; selected = element.id; showComponents = false
                }.presentationDetents([.medium]) }
                .sheet(isPresented: $showCode) { CodeExportView(project: project) }
                .alert("添加页面", isPresented: $showAddPage) {
                    TextField("页面名称", text: $pageName)
                    Button("添加") { let name = pageName.trimmingCharacters(in: .whitespacesAndNewlines); guard !name.isEmpty else { return }; mutate { $0.pages.append(DesignPage(name: name, elements: [])) }; if let count = self.project?.pages.count { pageIndex = count - 1 }; pageName = "新页面" }
                    Button("取消", role: .cancel) { }
                }
            } else { Text("项目不存在").foregroundStyle(.secondary) }
        }.navigationTitle("可视化编辑器").navigationBarTitleDisplayMode(.inline)
    }
    private func mutate(_ block: (inout DesignProject) -> Void) {
        guard var p = project else { return }
        history.append(p); if history.count > 30 { history.removeFirst() }
        block(&p); store.update(p)
    }
    private func undo() { guard let old = history.popLast() else { return }; store.update(old); if pageIndex >= old.pages.count { pageIndex = 0 }; selected = nil }
}

struct ElementPreview: View {
    let element: DesignElement
    var body: some View {
        Group {
            switch element.kind {
            case "title": Text(element.title).font(.system(size: element.fontSize, weight: .bold)).frame(maxWidth: .infinity, alignment: .leading)
            case "text": Text(element.title).font(.system(size: element.fontSize)).frame(maxWidth: .infinity, alignment: .leading)
            case "card": HStack { Image(systemName: "car.side.fill").font(.title).foregroundStyle(.cyan); Text(element.title).font(.system(size: element.fontSize, weight: .semibold)); Spacer() }.padding().frame(maxWidth: .infinity).background(Color(hex: element.colorHex), in: RoundedRectangle(cornerRadius: element.cornerRadius))
            case "button": Text(element.title).font(.system(size: element.fontSize, weight: .semibold)).frame(maxWidth: .infinity).background(Color(hex: element.colorHex), in: RoundedRectangle(cornerRadius: element.cornerRadius))
            case "toggle": HStack { Text(element.title).font(.system(size: element.fontSize)); Spacer(); Image(systemName: "switch.2").foregroundStyle(.green) }.padding(.horizontal).background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: element.cornerRadius))
            default: Rectangle().fill(.white.opacity(0.25)).frame(height: 1)
            }
        }.frame(height: element.kind == "divider" ? 12 : element.height)
    }
}

struct ComponentPicker: View {
    var onSelect: (String) -> Void
    let items: [(String, String, String)] = [("title","标题","textformat.size"),("text","文本","text.alignleft"),("card","卡片","rectangle.on.rectangle"),("button","按钮","hand.tap"),("toggle","开关","switch.2"),("divider","分隔线","minus")]
    var body: some View {
        NavigationStack {
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) {
                ForEach(items, id: \.0) { item in
                    Button { onSelect(item.0) } label: { VStack(spacing: 10) { Image(systemName: item.2).font(.title2); Text(item.1) }.frame(maxWidth: .infinity).frame(height: 90).background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14)) }.buttonStyle(.plain)
                }
            }.padding().navigationTitle("组件库").navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct ElementInspector: View {
    let element: DesignElement
    var onChange: (DesignElement) -> Void
    var onDelete: () -> Void
    var onMove: (Int) -> Void
    var body: some View {
        VStack(spacing: 8) {
            HStack { Text("属性编辑").font(.headline); Spacer(); Button { onMove(-1) } label: { Image(systemName: "arrow.up") }; Button { onMove(1) } label: { Image(systemName: "arrow.down") }; Button(role: .destructive, action: onDelete) { Image(systemName: "trash") } }.padding(.bottom, 4)
            TextField("文字内容", text: Binding(get: { element.title }, set: { var e = element; e.title = $0; onChange(e) })).textFieldStyle(.roundedBorder)
            HStack { Text("字号 \(Int(element.fontSize))"); Slider(value: Binding(get: { element.fontSize }, set: { var e = element; e.fontSize = $0; onChange(e) }), in: 12...36) }
            HStack { Text("高度 \(Int(element.height))"); Slider(value: Binding(get: { element.height }, set: { var e = element; e.height = $0; onChange(e) }), in: 32...220) }
            HStack { Text("圆角 \(Int(element.cornerRadius))"); Slider(value: Binding(get: { element.cornerRadius }, set: { var e = element; e.cornerRadius = $0; onChange(e) }), in: 0...36) }
            HStack { Text("背景色"); Spacer(); ForEach(["#1877F2","#173C67","#7C3AED","#059669","#EA580C"], id: \.self) { hex in Button { var e = element; e.colorHex = hex; onChange(e) } label: { Circle().fill(Color(hex: hex)).frame(width: 26, height: 26).overlay(Circle().stroke(.white, lineWidth: element.colorHex == hex ? 2 : 0)) } } }
        }.font(.subheadline).padding().background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 16)).padding(.horizontal).padding(.bottom, 8)
    }
}
