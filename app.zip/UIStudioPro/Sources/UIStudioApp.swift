import SwiftUI

@main struct UIStudioApp: App {
    @StateObject private var store = StudioStore()
    var body: some Scene { WindowGroup { StudioHome().environmentObject(store).preferredColorScheme(.dark) } }
}

struct DesignElement: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var kind: String
    var title: String
    var colorHex: String = "#1877F2"
    var fontSize: Double = 18
    var cornerRadius: Double = 14
    var height: Double = 56
    var freeX: Double? = nil
    var freeY: Double? = nil
    var freeWidth: Double? = nil
}
struct DesignPage: Identifiable, Codable {
    var id: UUID = UUID()
    var name: String
    var elements: [DesignElement]
    var freeLayout: Bool? = nil
}
struct DesignProject: Identifiable, Codable {
    var id: UUID = UUID()
    var name: String
    var pages: [DesignPage]
    var modified: Date = Date()
}

final class StudioStore: ObservableObject {
    @Published var projects: [DesignProject] = [] { didSet { save() } }
    private let key = "UIStudioPro.projects.v1"
    init() {
        if let data = UserDefaults.standard.data(forKey: key), let decoded = try? JSONDecoder().decode([DesignProject].self, from: data) { projects = decoded }
        if projects.isEmpty { projects = [Self.sample] }
    }
    static var sample: DesignProject {
        DesignProject(name: "车辆管理 App", pages: [
            DesignPage(name: "首页", elements: [
                DesignElement(kind: "title", title: "我的爱车", fontSize: 27, height: 52),
                DesignElement(kind: "card", title: "丰田 凯美瑞 · 2021款", colorHex: "#173C67", height: 118),
                DesignElement(kind: "text", title: "今日行驶 120 公里", height: 46),
                DesignElement(kind: "button", title: "添加记录", height: 52),
                DesignElement(kind: "toggle", title: "开启行程提醒", height: 52)
            ]),
            DesignPage(name: "设置", elements: [DesignElement(kind: "title", title: "设置"), DesignElement(kind: "toggle", title: "通知提醒")])
        ])
    }
    func save() { if let data = try? JSONEncoder().encode(projects) { UserDefaults.standard.set(data, forKey: key) } }
    func create() { projects.insert(DesignProject(name: "新项目 \(projects.count + 1)", pages: [DesignPage(name: "首页", elements: [])]), at: 0) }
    func duplicate(_ id: UUID) { guard var item = projects.first(where: { $0.id == id }) else { return }; item.id = UUID(); item.name += " 副本"; item.pages = item.pages.map { page in var copy = page; copy.id = UUID(); copy.elements = page.elements.map { element in var e = element; e.id = UUID(); return e }; return copy }; projects.insert(item, at: 0) }
    func remove(_ id: UUID) { projects.removeAll { $0.id == id } }
    func rename(_ id: UUID, to name: String) { guard let i = projects.firstIndex(where: { $0.id == id }) else { return }; projects[i].name = name }
    func update(_ project: DesignProject) { guard let index = projects.firstIndex(where: { $0.id == project.id }) else { return }; var p = project; p.modified = Date(); projects[index] = p }
}

extension Color {
    init(hex: String) {
        let raw = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        guard raw.count == 6, let n = UInt64(raw, radix: 16) else { self = .blue; return }
        self.init(red: Double((n >> 16) & 255) / 255, green: Double((n >> 8) & 255) / 255, blue: Double(n & 255) / 255)
    }
}

struct StudioHome: View {
    @EnvironmentObject var store: StudioStore
    @State private var tab = 0
    @State private var renameID: UUID?
    @State private var renameText = ""
    @State private var deleteID: UUID?
    private let columns = [GridItem(.flexible()), GridItem(.flexible())]
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 14) {
                    Image(systemName: "square.3.layers.3d.top.filled")
                        .font(.system(size: 27, weight: .bold)).foregroundStyle(.white)
                        .frame(width: 54, height: 54).background(LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 15))
                    VStack(alignment: .leading, spacing: 4) {
                        Text("UIStudio Pro").font(.title2.bold())
                        Text("iOS 可视化开发工厂").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { store.create(); tab = 0 } label: {
                        Image(systemName: "plus").font(.headline).foregroundStyle(.white).frame(width: 42, height: 42).background(.blue, in: Circle())
                    }.accessibilityLabel("新建项目")
                }.padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 18)
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        if tab == 0 { projectsContent }
                        else if tab == 1 { templatesContent }
                        else { aboutContent }
                    }.padding(20).padding(.bottom, 70)
                }
                HStack {
                    tabButton("项目", icon: "square.stack.fill", value: 0)
                    tabButton("模板", icon: "square.grid.2x2.fill", value: 1)
                    tabButton("关于", icon: "gearshape.fill", value: 2)
                }.padding(.vertical, 9).background(Color(red: 0.075, green: 0.095, blue: 0.14))
            }.background(Color(red: 0.035, green: 0.05, blue: 0.085)).toolbar(.hidden, for: .navigationBar)
        }
    }
    private func tabButton(_ title: String, icon: String, value: Int) -> some View {
        Button { tab = value } label: {
            VStack(spacing: 5) { Image(systemName: icon).font(.system(size: 20)); Text(title).font(.caption2) }
                .foregroundStyle(tab == value ? Color.blue : Color.gray).frame(maxWidth: .infinity).frame(height: 42)
        }.buttonStyle(.plain)
    }
    private var projectsContent: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("让创意变成 App").font(.system(size: 28, weight: .bold))
            Text("可视化设计 · 实时预览 · SwiftUI 源码").font(.subheadline).foregroundStyle(.secondary)
            HStack(spacing: 12) {
                Button { store.create() } label: { Label("新建项目", systemImage: "plus.square.fill").frame(maxWidth: .infinity).frame(height: 66).background(.blue.gradient, in: RoundedRectangle(cornerRadius: 16)) }.buttonStyle(.plain)
                Button { tab = 1 } label: { Label("模板中心", systemImage: "square.grid.2x2").frame(maxWidth: .infinity).frame(height: 66).background(Color.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 16)) }.buttonStyle(.plain)
            }.font(.subheadline.bold())
            HStack { Text("我的项目").font(.title3.bold()); Spacer(); Text("\(store.projects.count) 个项目").font(.caption).foregroundStyle(.secondary) }.padding(.top, 8)
            ForEach(store.projects) { project in
                NavigationLink { ProjectEditor(projectID: project.id) } label: {
                    HStack(spacing: 14) {
                        Image(systemName: "iphone.gen3.radiowaves.left.and.right").font(.title2).foregroundStyle(.cyan)
                            .frame(width: 62, height: 64).background(Color.blue.opacity(0.16), in: RoundedRectangle(cornerRadius: 14))
                        VStack(alignment: .leading, spacing: 7) {
                            Text(project.name).font(.headline)
                            Text("\(project.pages.count) 个页面 · 点击进入设计").font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer(); Image(systemName: "chevron.right").foregroundStyle(.secondary)
                    }.padding(14).background(Color.white.opacity(0.065), in: RoundedRectangle(cornerRadius: 18))
                }.buttonStyle(.plain)
                .contextMenu {
                    Button("复制项目", systemImage: "doc.on.doc") { store.duplicate(project.id) }
                    Button("重命名", systemImage: "pencil") { renameID = project.id; renameText = project.name }
                    Button("删除项目", systemImage: "trash", role: .destructive) { deleteID = project.id }
                }
            }
        }
        .alert("重命名项目", isPresented: Binding(get: { renameID != nil }, set: { if !$0 { renameID = nil } })) {
            TextField("项目名称", text: $renameText)
            Button("保存") { if let id = renameID, !renameText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { store.rename(id, to: renameText) }; renameID = nil }
            Button("取消", role: .cancel) { renameID = nil }
        }
        .confirmationDialog("确定删除此项目？此操作无法撤销。", isPresented: Binding(get: { deleteID != nil }, set: { if !$0 { deleteID = nil } })) {
            Button("删除项目", role: .destructive) { if let id = deleteID { store.remove(id) }; deleteID = nil }
        }
    }
    private var templatesContent: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("模板中心").font(.system(size: 28, weight: .bold))
            Text("选择模板，快速开启你的设计").foregroundStyle(.secondary)
            LazyVGrid(columns: columns, spacing: 14) {
                templateCard("车辆管理", detail: "汽车 · 数据卡片", icon: "car.side.fill", colors: [.blue, .cyan]) {
                    var sample = StudioStore.sample; sample.id = UUID(); sample.name = "车辆管理副本"
                    store.projects.insert(sample, at: 0); tab = 0
                }
                templateCard("空白项目", detail: "从零开始设计", icon: "square.dashed", colors: [.purple, .indigo]) { store.create(); tab = 0 }
            }
            templateCard("记账工具", detail: "收支 · 数据统计", icon: "chart.bar.fill", colors: [.green, .mint]) { createTemplate("记账工具", items: [("title","本月收支"),("card","本月结余 ¥2,680"),("text","收入 ¥8,600 · 支出 ¥5,920"),("button","添加账目")]) }
            templateCard("待办清单", detail: "效率 · 任务管理", icon: "checklist", colors: [.orange, .yellow]) { createTemplate("待办清单", items: [("title","今日任务"),("text","完成最重要的事情"),("toggle","检查项目进度"),("toggle","整理资料"),("button","添加任务")]) }
            templateCard("个人主页", detail: "名片 · 作品展示", icon: "person.crop.circle", colors: [.pink, .purple]) { createTemplate("个人主页", items: [("title","个人介绍"),("card","欢迎来到我的主页"),("text","在这里展示你的作品"),("button","联系我")]) }
            templateCard("设置面板", detail: "偏好 · 系统设置", icon: "gearshape.2", colors: [.gray, .blue]) { createTemplate("设置面板", items: [("title","偏好设置"),("toggle","消息通知"),("toggle","自动保存"),("divider","分割线"),("button","保存设置")]) }
        }
    }
    private func createTemplate(_ name: String, items: [(String,String)]) {
        let elements = items.map { DesignElement(kind: $0.0, title: $0.1) }
        store.projects.insert(DesignProject(name: name, pages: [DesignPage(name: "首页", elements: elements)]), at: 0)
        tab = 0
    }
    private func templateCard(_ title: String, detail: String, icon: String, colors: [Color], action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 12) {
                Image(systemName: icon).font(.system(size: 37)).frame(maxWidth: .infinity).frame(height: 112)
                    .background(LinearGradient(colors: colors.map { $0.opacity(0.32) }, startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 12))
                Text(title).font(.headline)
                Text(detail).font(.caption).foregroundStyle(.secondary)
                Label("使用模板", systemImage: "arrow.right.circle.fill").font(.caption.bold()).foregroundStyle(.blue)
            }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
                .background(Color.white.opacity(0.065), in: RoundedRectangle(cornerRadius: 17))
        }.buttonStyle(.plain)
    }
    private var aboutContent: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("关于 UIStudio Pro").font(.system(size: 27, weight: .bold))
            HStack(spacing: 15) {
                Image(systemName: "square.3.layers.3d.top.filled").font(.largeTitle).foregroundStyle(.blue)
                VStack(alignment: .leading) { Text("V3.0.0 · Build 6").font(.headline); Text("iOS 可视化界面设计工具").foregroundStyle(.secondary) }
            }.padding(18).frame(maxWidth: .infinity, alignment: .leading).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 18))
            Text("当前已支持").font(.headline)
            ForEach(["项目与多页面管理", "组件添加与属性调整", "撤销、重做、复制与排序", "页面实时预览", "SwiftUI 页面源码导出"], id: \.self) { item in
                Label(item, systemImage: "checkmark.circle.fill").foregroundStyle(.green).padding(12)
                    .frame(maxWidth: .infinity, alignment: .leading).background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 12))
            }
            Text("V3.0.0 增强了项目管理、模板、组件与源码生成。当前仍不支持自由坐标拖拽及完整目标 App 工程 ZIP 导出；请勿将页面源码当作完整项目。")
                .font(.footnote).foregroundStyle(.orange)
        }
    }
}
