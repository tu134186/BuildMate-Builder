import SwiftUI

@main struct UIStudioApp: App {
    @StateObject private var store = StudioStore()
    var body: some Scene { WindowGroup { StudioHome().environmentObject(store).preferredColorScheme(.dark) } }
}

struct DesignElement: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var kind: String
    var title: String
    var colorHex: String = "#1877F2"
    var fontSize: Double = 18
    var cornerRadius: Double = 14
    var height: Double = 56
}
struct DesignPage: Identifiable, Codable {
    var id: UUID = UUID()
    var name: String
    var elements: [DesignElement]
}
struct DesignProject: Identifiable, Codable {
    var id: UUID = UUID()
    var name: String
    var pages: [DesignPage]
    var modified: Date = Date()
}

final class StudioStore: ObservableObject {
    @Published var projects: [DesignProject] = [] { didSet { save() } }
    private let key = "UIStudioPro.projects.v1"
    init() {
        if let data = UserDefaults.standard.data(forKey: key), let decoded = try? JSONDecoder().decode([DesignProject].self, from: data) { projects = decoded }
        if projects.isEmpty { projects = [Self.sample] }
    }
    static var sample: DesignProject {
        DesignProject(name: "车辆管理 App", pages: [
            DesignPage(name: "首页", elements: [
                DesignElement(kind: "title", title: "我的爱车", fontSize: 27, height: 52),
                DesignElement(kind: "card", title: "丰田 凯美瑞 · 2021款", colorHex: "#173C67", height: 118),
                DesignElement(kind: "text", title: "今日行驶 120 公里", height: 46),
                DesignElement(kind: "button", title: "添加记录", height: 52),
                DesignElement(kind: "toggle", title: "开启行程提醒", height: 52)
            ]),
            DesignPage(name: "设置", elements: [DesignElement(kind: "title", title: "设置"), DesignElement(kind: "toggle", title: "通知提醒")])
        ])
    }
    func save() { if let data = try? JSONEncoder().encode(projects) { UserDefaults.standard.set(data, forKey: key) } }
    func create() { projects.insert(DesignProject(name: "新项目 \(projects.count + 1)", pages: [DesignPage(name: "首页", elements: [])]), at: 0) }
    func update(_ project: DesignProject) { guard let index = projects.firstIndex(where: { $0.id == project.id }) else { return }; var p = project; p.modified = Date(); projects[index] = p }
}

extension Color {
    init(hex: String) {
        let raw = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        guard raw.count == 6, let n = UInt64(raw, radix: 16) else { self = .blue; return }
        self.init(red: Double((n >> 16) & 255) / 255, green: Double((n >> 8) & 255) / 255, blue: Double(n & 255) / 255)
    }
}

struct StudioHome: View {
    @EnvironmentObject var store: StudioStore
    @State private var tab = 0
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    Image(systemName: "square.3.layers.3d.top.filled").font(.system(size: 30)).foregroundStyle(.blue)
                    VStack(alignment: .leading) { Text("UIStudio Pro").font(.title2.bold()); Text("iOS 可视化开发工厂").font(.caption).foregroundStyle(.secondary) }
                    Spacer()
                    Button { store.create() } label: { Image(systemName: "plus.circle.fill").font(.title2) }.accessibilityLabel("新建项目")
                }.padding()
                Picker("导航", selection: $tab) { Text("项目").tag(0); Text("模板").tag(1); Text("关于").tag(2) }.pickerStyle(.segmented).padding(.horizontal)
                if tab == 0 {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 14) {
                            Button { store.create() } label: { Label("新建项目", systemImage: "plus.square.fill").frame(maxWidth: .infinity).padding().background(.blue.gradient, in: RoundedRectangle(cornerRadius: 16)) }.buttonStyle(.plain)
                            Text("我的项目").font(.headline).padding(.top, 10)
                            ForEach(store.projects) { project in
                                NavigationLink { ProjectEditor(projectID: project.id) } label: {
                                    HStack(spacing: 14) {
                                        Image(systemName: "iphone.gen3").font(.title).foregroundStyle(.cyan).frame(width: 50, height: 60).background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
                                        VStack(alignment: .leading, spacing: 5) { Text(project.name).font(.headline); Text("\(project.pages.count) 个页面 · 点击编辑").font(.caption).foregroundStyle(.secondary) }
                                        Spacer(); Image(systemName: "chevron.right").foregroundStyle(.secondary)
                                    }.padding().background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
                                }.buttonStyle(.plain)
                            }
                        }.padding()
                    }
                } else if tab == 1 {
                    VStack(spacing: 18) {
                        Image(systemName: "square.grid.2x2.fill").font(.largeTitle).foregroundStyle(.blue)
                        Text("车辆管理模板").font(.title3.bold())
                        Text("内置双页面示例，包含标题、卡片、按钮和开关。").font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        Button("从模板创建") { var sample = StudioStore.sample; sample.id = UUID(); sample.name = "车辆管理副本"; store.projects.insert(sample, at: 0); tab = 0 }.buttonStyle(.borderedProminent)
                    }.padding().frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    VStack(spacing: 12) { Text("UIStudio Pro V1.0.0").font(.title2.bold()); Text("原生 SwiftUI 可视化编辑器\n本地保存 · 多页面 · 源码导出").multilineTextAlignment(.center).foregroundStyle(.secondary); Text("当前版本生成 SwiftUI 页面源码，不生成可独立编译的目标 App 工程。").font(.caption).multilineTextAlignment(.center).foregroundStyle(.orange) }.padding().frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            }.navigationBarHidden(true)
        }
    }
}
