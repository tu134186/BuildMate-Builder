import SwiftUI
import UIKit

struct CodeExportView: View {
    let project: DesignProject
    @Environment(\.dismiss) private var dismiss
    @State private var shareURL: URL?
    private var generated: String { SwiftSourceGenerator.generate(project) }
    var body: some View {
        NavigationStack {
            VStack(spacing: 14) {
                Text("SwiftUI 页面源码预览").font(.headline)
                Text("导出单个 Swift 文件，包含项目中所有页面。此版本暂不导出独立 Xcode 工程。")
                    .font(.caption).foregroundStyle(.orange)
                ScrollView([.vertical, .horizontal]) { Text(generated).font(.system(size: 12, design: .monospaced)).frame(maxWidth: .infinity, alignment: .leading).textSelection(.enabled).padding() }
                    .background(Color.black.opacity(0.35), in: RoundedRectangle(cornerRadius: 12))
                ShareLink(item: exportFile(), preview: SharePreview("GeneratedViews.swift")) { Label("分享 Swift 源码", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity) }.buttonStyle(.borderedProminent)
            }.padding().navigationTitle("代码工厂").navigationBarTitleDisplayMode(.inline).toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("完成") { dismiss() } } }
        }
    }
    private func exportFile() -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("GeneratedViews-\(project.id.uuidString).swift")
        try? generated.write(to: url, atomically: true, encoding: .utf8)
        return url
    }
}

enum SwiftSourceGenerator {
    static func quoted(_ string: String) -> String {
        let s = string.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"").replacingOccurrences(of: "\n", with: "\\n").replacingOccurrences(of: "\r", with: "\\r")
        return "\"\(s)\""
    }
    static func generate(_ project: DesignProject) -> String {
        var output = "import SwiftUI\n\n// UIStudio Pro generated views.\n\n"
        for (index, page) in project.pages.enumerated() {
            let free = page.freeLayout == true
            output += "struct StudioPage\(index + 1): View {\n    var body: some View {\n        ScrollView {\n"
            output += free ? "            ZStack(alignment: .topLeading) {\n" : "            VStack(alignment: .leading, spacing: 12) {\n"
            for e in page.elements {
                let before = output.count
                let label = quoted(e.title)
                let size = Int(e.fontSize)
                let radius = Int(e.cornerRadius)
                let height = Int(e.height)
                let color = colorExpression(e.colorHex)
                switch e.kind {
                case "title": output += "                Text(\(label)).font(.system(size: \(size), weight: .bold)).frame(maxWidth: .infinity, alignment: .leading).frame(height: \(height))\n"
                case "text": output += "                Text(\(label)).font(.system(size: \(size))).frame(maxWidth: .infinity, alignment: .leading).frame(height: \(height))\n"
                case "card": output += "                HStack { Image(systemName: \"car.side.fill\"); Text(\(label)).font(.system(size: \(size))); Spacer() }.padding().frame(maxWidth: .infinity).frame(height: \(height)).background(\(color), in: RoundedRectangle(cornerRadius: \(radius)))\n"
                case "button": output += "                Button(\(label)) { }.font(.system(size: \(size))).frame(maxWidth: .infinity).frame(height: \(height)).background(\(color), in: RoundedRectangle(cornerRadius: \(radius)))\n"
                case "toggle": output += "                Toggle(\(label), isOn: .constant(false)).font(.system(size: \(size))).frame(height: \(height))\n"
                case "image": output += "                Image(systemName: \(label)).resizable().scaledToFit().foregroundStyle(\(color)).frame(height: \(height))\n"
                case "icon": output += "                Image(systemName: \(label)).font(.system(size: \(size + 14))).foregroundStyle(\(color)).frame(maxWidth: .infinity).frame(height: \(height))\n"
                case "badge": output += "                Text(\(label)).padding(.horizontal, 14).background(\(color), in: Capsule()).frame(height: \(height))\n"
                case "progress": output += "                VStack(alignment: .leading) { Text(\(label)); ProgressView(value: 0.65).tint(\(color)) }.frame(height: \(height))\n"
                case "field": output += "                TextField(\(label), text: .constant(\"\")).textFieldStyle(.roundedBorder).frame(height: \(height))\n"
                case "spacer": output += "                Spacer(minLength: \(height))\n"
                default: output += "                Divider()\n"
                }
                if free {
                    let x = Int(e.freeX ?? 160), y = Int(e.freeY ?? 55), w = Int(e.freeWidth ?? 230)
                    let added = String(output.suffix(output.count - before))
                    output = String(output.prefix(before)) + added.trimmingCharacters(in: .newlines) + ".frame(width: \(w)).position(x: \(x), y: \(y))\n"
                }
            }
            output += free ? "            }.frame(width: 320, height: 550)\n" : "            }.padding()\n"
            output += "        }.navigationTitle(\(quoted(page.name)))\n    }\n}\n\n"
        }
        output += "struct StudioGeneratedRoot: View {\n    var body: some View {\n        TabView {\n"
        for (index, page) in project.pages.enumerated() {
            output += "            NavigationStack { StudioPage\(index + 1)() }.tabItem { Label(\(quoted(page.name)), systemImage: \"square.grid.2x2\") }\n"
        }
        output += "        }\n    }\n}\n"
        return output
    }
    static func colorExpression(_ hex: String) -> String {
        let raw = hex.replacingOccurrences(of: "#", with: "")
        guard raw.count == 6, let n = UInt64(raw, radix: 16) else { return "Color.blue" }
        return String(format: "Color(red: %.5f, green: %.5f, blue: %.5f)", Double((n >> 16) & 255)/255, Double((n >> 8) & 255)/255, Double(n & 255)/255)
    }
}
