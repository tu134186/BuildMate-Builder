# UIStudio Pro V1.0.0 · 可视化界面设计器

这是**可编辑的 SwiftUI iOS App 工程源码**，不是效果图。目标系统 iOS 16+。

## 已实现
- 项目列表、新建项目、本地持久化、示例模板
- 多页面创建和切换
- 6 类基础组件的添加、选中、编辑文字/字号/高度/圆角/配色
- 组件上移、下移、删除；单步撤销（最多 30 次历史）
- 真实 SwiftUI 画布预览（在编辑器内展示）
- 生成 SwiftUI 多页面代码并通过系统分享面板导出 `.swift`
- XcodeGen 工程配置及 GitHub Actions 模拟器构建工作流

## 尚未实现（不要误认为已有）
- 画布自由拖拽、复杂响应式布局、多设备模拟
- 可执行的业务逻辑、数据库、API、AI
- 完整目标 App 的 Xcode 工程 ZIP 导出
- BuildMate API 直连、IPA 自动回传

## 编译
在 macOS 安装 Xcode 与 xcodegen 后运行：

```sh
xcodegen generate
xcodebuild -project UIStudioPro.xcodeproj -scheme UIStudioPro -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' CODE_SIGNING_ALLOWED=NO build
```

真机安装需要使用自己的签名配置，或者交给已有的云端编译环境。此工程**未经过真实 Xcode 编译与真机验证**。

版本：1.0.0（Build 1）。
