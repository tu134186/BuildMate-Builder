# UIStudio Pro V3.0.0 / Build 6

## Implemented
- Optional free-layout mode per page; legacy pages remain in stack mode by default.
- Direct finger positioning in a 550-point design canvas; X/Y and width editing in inspector.
- Persists coordinates and layout mode using backward-compatible optional Codable fields.
- SwiftUI code generation emits ZStack and positioned elements for free-layout pages.
- Keeps previous project/template/components and source sharing.

## Limitations
- Free-layout canvas is a fixed design space; not responsive constraint layout.
- Preview sheet still uses stack representation; exported code is the authoritative free-layout output.
- Undo/redo does not capture each drag frame.
- Does not export a full target-app Xcode project ZIP; no real business logic engine or AI.
- Not compiled on Xcode or tested on iPhone here.
