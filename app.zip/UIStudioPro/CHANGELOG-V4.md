# V4.0.0 / Build 7
- New: export standalone XcodeGen SwiftUI project as ZIP from code factory.
- New: includes project.yml, app entrypoint, generated pages, design JSON, README.
- Fixed: preview now uses free-layout coordinates when free layout is active.
- Retained: existing project storage key and all V3 editor controls.
- Limitation: exported app is a UI scaffold; interactive business logic is not generated.
- Validation: archive checked; iOS compilation not performed in this environment.
