#import <UIKit/UIKit.h>
#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
@interface RSRootListController : PSListController @end
@implementation RSRootListController
- (NSArray *)specifiers { if (!_specifiers) { _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self]; } return _specifiers; }
@end
