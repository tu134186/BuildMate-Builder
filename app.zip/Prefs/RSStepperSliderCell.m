#import <UIKit/UIKit.h>
#import <Preferences/PSSliderTableCell.h>
@interface RSStepperSliderCell : PSSliderTableCell
@property(nonatomic,strong) UIButton *rsMinus;
@property(nonatomic,strong) UIButton *rsPlus;
@end
@implementation RSStepperSliderCell
- (UIButton *)rsButton:(NSString *)title action:(SEL)action {
 UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem]; [b setTitle:title forState:UIControlStateNormal]; b.titleLabel.font=[UIFont boldSystemFontOfSize:22]; [b addTarget:self action:action forControlEvents:UIControlEventTouchUpInside]; [self.contentView addSubview:b]; return b;
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)identifier specifier:(id)specifier {
 self=[super initWithStyle:style reuseIdentifier:identifier specifier:specifier]; if(self){self.rsMinus=[self rsButton:@"−" action:@selector(rsDecrease)]; self.rsPlus=[self rsButton:@"+" action:@selector(rsIncrease)];} return self;
}
- (UISlider *)rsSliderIn:(UIView *)view { if([view isKindOfClass:[UISlider class]])return (UISlider *)view; for(UIView *v in view.subviews){UISlider *s=[self rsSliderIn:v];if(s)return s;}return nil;}
- (void)layoutSubviews { [super layoutSubviews]; UISlider *s=[self rsSliderIn:self.contentView]; if(!s)return; CGRect f=s.frame; CGFloat side=34; self.rsMinus.frame=CGRectMake(CGRectGetMinX(f)-side,CGRectGetMidY(f)-19,side,38); self.rsPlus.frame=CGRectMake(CGRectGetMaxX(f),CGRectGetMidY(f)-19,side,38); CGFloat available=CGRectGetWidth(self.contentView.bounds); if(CGRectGetMinX(f)<side+8 || CGRectGetMaxX(f)>available-side-8){ s.frame=CGRectMake(side+12,f.origin.y,MAX(60,available-(side+12)*2),f.size.height); f=s.frame; self.rsMinus.frame=CGRectMake(4,CGRectGetMidY(f)-19,side,38); self.rsPlus.frame=CGRectMake(available-side-4,CGRectGetMidY(f)-19,side,38); } [self.contentView bringSubviewToFront:self.rsMinus];[self.contentView bringSubviewToFront:self.rsPlus]; }
- (void)rsAdjust:(NSInteger)dir { UISlider *s=[self rsSliderIn:self.contentView]; if(!s)return; CGFloat range=s.maximumValue-s.minimumValue; CGFloat step=range<=3.0?0.05:(range<=30?0.5:1.0); CGFloat val=round((s.value+dir*step)/step)*step; s.value=MIN(s.maximumValue,MAX(s.minimumValue,val)); [s sendActionsForControlEvents:UIControlEventValueChanged]; }
- (void)rsDecrease {[self rsAdjust:-1];}
- (void)rsIncrease {[self rsAdjust:1];}
@end
