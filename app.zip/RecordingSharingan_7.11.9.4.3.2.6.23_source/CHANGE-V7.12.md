# V7.12 改动说明（只改宽度）

## 1) 灵动岛向左加宽 7pt
`Tweak.xm`：
- 新增常量 `RSIslandLeftExpand = 7.0`、`RSIslandEyeFollow = 7.0`
- 新增 `RSV712ResolvePillView / RSV712CurrentPillView / RSV712FrameForPillView`
- 在 `SAUIElementView -setFrame:` 与 `SBSystemApertureContainerView -setFrame:` 中，
  录屏期间对“承载写轮眼的那颗胶囊”把 `origin.x -= 7`、`width += 7`，右边界不动；
  录屏结束 / 插件停用直接放行系统原 frame。
- 新增会话内缓存 `RSV712PillView`，每次新录屏会话重新确认目标胶囊（`RSV7114ResetAccessorySession` 里重置）。

## 2) 素材跟随
`Tweak.xm` 四处左侧落点（原生红点分支、Portal 分支、fallback 分支、`RSUpdateEyeGeometry`）：
`center.x += RSLeftXOffset() - RSIslandEyeFollow`，即素材在原有左侧 X 微调基础上再左移 7pt。

## 未改动
素材、旋转、隐藏红点、停录逻辑、设置页条目均未动；仅版本号改为 7.11.9.4.3.2.6.23。
