import ActivityKit
import WidgetKit
import SwiftUI
@main struct LiveTimerWidgetBundle: WidgetBundle {
    var body: some Widget { LiveTimerWidget() }
}
struct LiveTimerWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: TimerAttributes.self) { context in
            HStack(spacing: 14) {
                Image(systemName: "car.fill").foregroundColor(.green).font(.title2)
                VStack(alignment: .leading, spacing: 6) {
                    Text(context.attributes.label).font(.headline)
                    Text(timerInterval: context.state.startedAt...context.state.endsAt, countsDown: false)
                        .monospacedDigit().font(.title2.bold())
                }
                Spacer()
            }.padding(16).activityBackgroundTint(Color.black.opacity(0.85))
                .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) { Label("运行中", systemImage: "car.fill").foregroundColor(.green) }
                DynamicIslandExpandedRegion(.trailing) { Text("测试").font(.caption) }
                DynamicIslandExpandedRegion(.bottom) {
                    Text(timerInterval: context.state.startedAt...context.state.endsAt, countsDown: false)
                        .monospacedDigit().font(.title.bold())
                }
            } compactLeading: {
                Image(systemName: "car.fill").foregroundColor(.green)
            } compactTrailing: {
                Text(timerInterval: context.state.startedAt...context.state.endsAt, countsDown: false, showsHours: false)
                    .monospacedDigit().font(.caption2)
            } minimal: {
                Image(systemName: "car.fill").foregroundColor(.green)
            }
        }
    }
}
