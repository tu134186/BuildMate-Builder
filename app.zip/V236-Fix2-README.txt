CarIdle V2.3.6 / Build 41 - Live Activity UI Fix2

Only changed: CarIdleWidget/IdleWidget.swift
- Lock screen: explicit high-contrast white text, muted secondary text, slate dark background.
- Expanded Dynamic Island: single-line heading, balanced elapsed timer, target label, accent icon.
- Compact Dynamic Island: keep car icon and running timer, improved type.
- No change to ActivityKit request/update/end, timer calculations, main app, settings, or data.
- NiceBarX exclusion remains configured on the device, not inside this IPA.

This is source-only; cloud compilation and device testing are pending.
