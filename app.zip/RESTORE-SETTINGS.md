# V7.11.9.4.3.2.6.3 — restore Settings entry

Observed on device: 6.2 shows recording material but Settings entry is absent.

Fix: restore the original 94326 PreferenceLoader plist (entry + items) byte-for-byte, instead of the experimental bundle-only entry. Remove experimental Preferences subproject from the build, but keep its sources for future investigation. No changes to Tweak.xm.

This restores the original settings UI, NOT the experimental +/- slider. The slider is retained only as unbuilt source. No cloud build or device verification has been performed.
