# IslandFX 1.0.0 — experimental minimal prototype

Independent Theos rootless tweak. This first build draws a cyan pulsing rounded border at an approximate Dynamic Island position. It does **not** yet track native Dynamic Island state, hide the native black region, play PNG frames, or provide settings UI. It uses a noninteractive overlay window and avoids private SystemAperture hooks. The overlay may appear incorrectly on some devices and may not appear until SpringBoard initializes. Test only on a device with a recovery path.

Build: `make package FINALPACKAGE=1` using a rootless Theos environment. ZIP contains complete source. The `layout/` folder is reserved for future assets.

To disable before rebuilding: set `enabled` to false in `/var/jb/var/mobile/Library/Preferences/com.islandfx.demo.plist` and respring, or uninstall the package. No settings UI yet.
