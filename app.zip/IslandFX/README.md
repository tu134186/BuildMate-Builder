# 动态岛 V1.1.1 — 编译修复验证版

从 V1.1.0 修复诊断包 BM-27D718D5 中的两项编译配置问题：

1. Preferences 子工程显式设置 arm64/arm64e 和 rootless，避免回落到 armv7。
2. 去除对 SDK 中缺失的私有 Preferences.framework 的链接依赖，使用动态符号解析；编译头文件仍需由 Theos SDK 提供，运行时依赖系统 Preferences.framework。

不修改 Tweak 模块逻辑、设置开关、G/C 工作流或 BuildMate。

验证：ZIP/Plist 静态检查通过；云端编译及真机安装尚未验证。若后续出现其它编译错误，请导出 BuildMate 诊断包。
