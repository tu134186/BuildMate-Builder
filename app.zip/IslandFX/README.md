# IslandFX V1.1.0
Theos Rootless source. Build via `make package` (Theos must support Preference bundles).
Settings > 动态岛: master switch and four independent module switches.
All switches default OFF. Modules are stubs: no island effects are claimed or rendered yet.
Darwin notification com.islandfx.demo/preferenceschanged applies preferences without requiring a respring for changes.
This release removes V1.0.0 floating cyan ring; no SystemAperture hooks yet.
Requires PreferenceLoader. Not cloud compiled or device tested.
