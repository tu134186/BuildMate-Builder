#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

// Minimal standalone visual prototype: does not hook private SystemAperture classes.
// Position is approximate, not guaranteed to track Dynamic Island state.
@interface IFXWindow : UIWindow
@end
@implementation IFXWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event { return nil; }
@end

static IFXWindow *overlayWindow;
static CAShapeLayer *ringLayer;
static BOOL isEnabled(void) {
    NSDictionary *prefs = [NSDictionary dictionaryWithContentsOfFile:@"/var/jb/var/mobile/Library/Preferences/com.islandfx.demo.plist"];
    return prefs[@"enabled"] ? [prefs[@"enabled"] boolValue] : YES;
}
static void IFXInstall(void) {
    if (overlayWindow || !isEnabled()) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat width = 126.0, height = 38.0;
    overlayWindow = [[IFXWindow alloc] initWithFrame:CGRectMake((CGRectGetWidth(screen)-width)/2.0, 8.0, width, height)];
    overlayWindow.windowLevel = UIWindowLevelStatusBar + 1;
    overlayWindow.backgroundColor = UIColor.clearColor;
    overlayWindow.userInteractionEnabled = NO;
    overlayWindow.hidden = NO;
    ringLayer = [CAShapeLayer layer];
    ringLayer.frame = overlayWindow.bounds;
    ringLayer.path = [UIBezierPath bezierPathWithRoundedRect:CGRectInset(ringLayer.bounds, 1.5, 1.5) cornerRadius:18].CGPath;
    ringLayer.fillColor = UIColor.clearColor.CGColor;
    ringLayer.strokeColor = UIColor.systemCyanColor.CGColor;
    ringLayer.lineWidth = 2.0;
    [overlayWindow.layer addSublayer:ringLayer];
    CABasicAnimation *pulse = [CABasicAnimation animationWithKeyPath:@"opacity"];
    pulse.fromValue = @0.35;
    pulse.toValue = @1.0;
    pulse.duration = 1.2;
    pulse.autoreverses = YES;
    pulse.repeatCount = HUGE_VALF;
    [ringLayer addAnimation:pulse forKey:@"pulse"];
}
%ctor {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidFinishLaunchingNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) { IFXInstall(); }];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ IFXInstall(); });
    });
}
