# V2.2.1 Apple Native UI

基于原始 V2.1.0 完整工程。全局浅色主题、系统蓝色交互、白色卡片与浅灰背景统一覆盖 SwiftUI 页面。保留原有计时、记录、保养、备份功能及 GitHub Actions workflow。

注意：这是可编译源码候选包，当前环境未执行 Xcode 真机编译；尚非效果图逐像素复刻。
