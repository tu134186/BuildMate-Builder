# V7.11.9.4.3.2.6.4 — 新版设置入口实验修复

基于 6.2（非 6.3 回退版）。保留 RSRootController、RSAdjustCell 和全部新版滑条设置。

修复项：PreferenceLoader 入口补充 title / isController；设置 Bundle 显式 Info.plist 和资源目录；调整 aggregate Makefile 声明顺序。

限制：这些属于静态结构修复，尚无真机 PreferenceLoader 日志，不能保证设置页已经恢复。请先检查编译产物是否包含 `/var/jb/Library/PreferenceBundles/RecordingSharinganPrefs.bundle/RecordingSharinganPrefs`、`Root.plist`、`Info.plist` 及 `/var/jb/Library/PreferenceLoader/Preferences/RecordingSharingan.plist`。

录屏核心 Tweak.xm 未修改。
