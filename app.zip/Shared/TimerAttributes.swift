import ActivityKit
import Foundation
struct TimerAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var startedAt: Date
        var endsAt: Date
    }
    var label: String
}
