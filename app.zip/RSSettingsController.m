#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>
#import <notify.h>

static NSString * const RSDomain = @"com.tu.recordingsharingan.settings";
static NSString * const RSNotify = @"com.tu.recordingsharingan.settings.changed";

@interface RSAdjustCard : UIView
@property(nonatomic,strong) UISlider *slider;
@property(nonatomic,strong) UILabel *number;
@property(nonatomic,copy) NSString *key;
@property(nonatomic,assign) CGFloat lower,upper,step,initial;
- (instancetype)initWithTitle:(NSString *)title note:(NSString *)note key:(NSString *)key min:(CGFloat)min max:(CGFloat)max step:(CGFloat)step initial:(CGFloat)initial tint:(UIColor *)tint;
- (void)reloadValue;
@end

@implementation RSAdjustCard
- (instancetype)initWithTitle:(NSString *)title note:(NSString *)note key:(NSString *)key min:(CGFloat)min max:(CGFloat)max step:(CGFloat)step initial:(CGFloat)initial tint:(UIColor *)tint {
 if ((self=[super initWithFrame:CGRectZero])) {
  self.key=key;self.lower=min;self.upper=max;self.step=step;self.initial=initial;
  self.backgroundColor=UIColor.whiteColor;self.layer.cornerRadius=18;self.layer.masksToBounds=YES;
  UILabel *heading=[UILabel new];heading.text=title;heading.font=[UIFont boldSystemFontOfSize:17];heading.translatesAutoresizingMaskIntoConstraints=NO;[self addSubview:heading];
  UILabel *hint=[UILabel new];hint.text=note;hint.font=[UIFont systemFontOfSize:12];hint.textColor=UIColor.secondaryLabelColor;hint.numberOfLines=0;hint.translatesAutoresizingMaskIntoConstraints=NO;[self addSubview:hint];
  UIButton *minus=[self makeButton:@"−" tint:tint]; UIButton *plus=[self makeButton:@"+" tint:tint];
  [minus addTarget:self action:@selector(decrement) forControlEvents:UIControlEventTouchUpInside];[plus addTarget:self action:@selector(increment) forControlEvents:UIControlEventTouchUpInside];
  self.slider=[UISlider new];self.slider.minimumValue=min;self.slider.maximumValue=max;self.slider.minimumTrackTintColor=UIColor.systemBlueColor;self.slider.translatesAutoresizingMaskIntoConstraints=NO;[self.slider addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];[self addSubview:self.slider];
  self.number=[UILabel new];self.number.textAlignment=NSTextAlignmentRight;self.number.font=[UIFont monospacedDigitSystemFontOfSize:14 weight:UIFontWeightSemibold];self.number.translatesAutoresizingMaskIntoConstraints=NO;[self addSubview:self.number];
  [NSLayoutConstraint activateConstraints:@[
   [heading.topAnchor constraintEqualToAnchor:self.topAnchor constant:17],[heading.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:17],[heading.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-17],
   [hint.topAnchor constraintEqualToAnchor:heading.bottomAnchor constant:6],[hint.leadingAnchor constraintEqualToAnchor:heading.leadingAnchor],[hint.trailingAnchor constraintEqualToAnchor:heading.trailingAnchor],
   [minus.topAnchor constraintEqualToAnchor:hint.bottomAnchor constant:16],[minus.leadingAnchor constraintEqualToAnchor:heading.leadingAnchor],[minus.widthAnchor constraintEqualToConstant:42],[minus.heightAnchor constraintEqualToConstant:42],
   [self.slider.centerYAnchor constraintEqualToAnchor:minus.centerYAnchor],[self.slider.leadingAnchor constraintEqualToAnchor:minus.trailingAnchor constant:8],
   [plus.centerYAnchor constraintEqualToAnchor:minus.centerYAnchor],[plus.leadingAnchor constraintEqualToAnchor:self.slider.trailingAnchor constant:8],[plus.widthAnchor constraintEqualToConstant:42],[plus.heightAnchor constraintEqualToConstant:42],
   [self.number.centerYAnchor constraintEqualToAnchor:minus.centerYAnchor],[self.number.leadingAnchor constraintEqualToAnchor:plus.trailingAnchor constant:5],[self.number.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-14],[self.number.widthAnchor constraintEqualToConstant:57],
   [minus.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-16]
  ]];
  [self reloadValue];
 }
 return self;
}
- (UIButton *)makeButton:(NSString *)label tint:(UIColor *)tint {
 UIButton *button=[UIButton buttonWithType:UIButtonTypeSystem];[button setTitle:label forState:UIControlStateNormal];button.titleLabel.font=[UIFont systemFontOfSize:29 weight:UIFontWeightMedium];button.tintColor=tint;button.backgroundColor=[UIColor colorWithWhite:0.95 alpha:1];button.layer.cornerRadius=12;button.translatesAutoresizingMaskIntoConstraints=NO;[self addSubview:button];return button;
}
- (void)reloadValue {
 CFPreferencesAppSynchronize((__bridge CFStringRef)RSDomain);
 id stored=(__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)self.key,(__bridge CFStringRef)RSDomain);
 CGFloat v=[stored respondsToSelector:@selector(doubleValue)]?[stored doubleValue]:self.initial;
 v=MIN(self.upper,MAX(self.lower,v));self.slider.value=v;[self updateLabel:v];
}
- (void)updateLabel:(CGFloat)v {self.number.text=[NSString stringWithFormat:(self.step<0.1?@"%.2f":@"%+.1f"),v];}
- (void)saveValue:(CGFloat)value {
 value=MIN(self.upper,MAX(self.lower,round(value/self.step)*self.step));self.slider.value=value;[self updateLabel:value];
 CFPreferencesSetAppValue((__bridge CFStringRef)self.key,(__bridge CFNumberRef)@(value),(__bridge CFStringRef)RSDomain);
 CFPreferencesAppSynchronize((__bridge CFStringRef)RSDomain);
 notify_post(RSNotify.UTF8String);
}
- (void)sliderChanged:(UISlider *)slider {[self saveValue:slider.value];}
- (void)decrement {[self saveValue:self.slider.value-self.step];}
- (void)increment {[self saveValue:self.slider.value+self.step];}
@end

@interface RSSettingsController : UIViewController
@property(nonatomic,strong) NSMutableArray<RSAdjustCard *> *cards;
@property(nonatomic,strong) UISegmentedControl *mode;
@end
@implementation RSSettingsController
- (void)viewDidLoad {
 [super viewDidLoad];self.title=@"写轮眼精细调节";self.view.backgroundColor=[UIColor colorWithRed:0.95 green:0.96 blue:0.98 alpha:1];
 UIScrollView *scroll=[UIScrollView new];scroll.translatesAutoresizingMaskIntoConstraints=NO;[self.view addSubview:scroll];
 [NSLayoutConstraint activateConstraints:@[[scroll.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],[scroll.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],[scroll.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],[scroll.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor]]];
 UIStackView *stack=[UIStackView new];stack.axis=UILayoutConstraintAxisVertical;stack.spacing=14;stack.translatesAutoresizingMaskIntoConstraints=NO;[scroll addSubview:stack];
 [NSLayoutConstraint activateConstraints:@[[stack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor constant:14],[stack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor constant:-24],[stack.leadingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.leadingAnchor constant:14],[stack.trailingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.trailingAnchor constant:-14],[stack.widthAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.widthAnchor constant:-28]]];
 self.cards=[NSMutableArray new];
 [self addCard:stack title:@"灵动岛控制区域宽度" note:@"实验参数：向左扩宽，保留右边界；0 为关闭。" key:@"vcWidthDelta" min:0 max:30 step:0.5 initial:0 tint:UIColor.systemBlueColor];
 UILabel *modeLabel=[UILabel new];modeLabel.text=@"宽度实验模式";modeLabel.font=[UIFont boldSystemFontOfSize:15];[stack addArrangedSubview:modeLabel];
 self.mode=[[UISegmentedControl alloc]initWithItems:@[@"关闭",@"VC",@"容器",@"同步"]];
 id modeValue=(__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("widthMode"),(__bridge CFStringRef)RSDomain);
 self.mode.selectedSegmentIndex=modeValue?MIN(3,MAX(0,[modeValue integerValue])):0;
 [self.mode addTarget:self action:@selector(modeChanged:) forControlEvents:UIControlEventValueChanged];[stack addArrangedSubview:self.mode];
 [self addCard:stack title:@"左侧录屏素材位置" note:@"负值向左，正值向右；单独录屏优先调这里。" key:@"leftXOffset" min:-20 max:20 step:0.5 initial:0 tint:UIColor.systemGreenColor];
 [self addCard:stack title:@"右侧录屏素材位置" note:@"独立岛位置微调，不影响左侧参数。" key:@"rightXOffset" min:-20 max:20 step:0.5 initial:0 tint:UIColor.systemGreenColor];
 [self addCard:stack title:@"录屏素材上下位置" note:@"负值向上，正值向下。" key:@"yOffset" min:-12 max:12 step:0.5 initial:0 tint:UIColor.systemGreenColor];
 [self addCard:stack title:@"左侧素材尺寸" note:@"只改变左侧写轮眼显示大小。" key:@"leftSize" min:20 max:52 step:0.5 initial:31 tint:UIColor.systemPurpleColor];
 [self addCard:stack title:@"右侧素材尺寸" note:@"只改变右侧写轮眼显示大小。" key:@"rightSize" min:20 max:56 step:0.5 initial:37 tint:UIColor.systemPurpleColor];
 [self addCard:stack title:@"旋转速度" note:@"1.00 倍为原来的默认速度。" key:@"rotationSpeed" min:0.25 max:3 step:0.05 initial:1 tint:UIColor.systemOrangeColor];
 UIButton *reset=[UIButton buttonWithType:UIButtonTypeSystem];[reset setTitle:@"⟲  恢复默认参数" forState:UIControlStateNormal];reset.titleLabel.font=[UIFont boldSystemFontOfSize:17];reset.backgroundColor=[UIColor colorWithRed:0.86 green:0.92 blue:1 alpha:1];reset.layer.cornerRadius=15;[reset.heightAnchor constraintEqualToConstant:58].active=YES;[reset addTarget:self action:@selector(resetAll) forControlEvents:UIControlEventTouchUpInside];[stack addArrangedSubview:reset];
 UILabel *note=[UILabel new];note.text=@"宽度实验仅在录屏活动时介入系统布局；如出现异常，先将实验模式切换为关闭。";note.font=[UIFont systemFontOfSize:12];note.textColor=UIColor.secondaryLabelColor;note.numberOfLines=0;[stack addArrangedSubview:note];
}
- (void)addCard:(UIStackView *)stack title:(NSString *)title note:(NSString *)note key:(NSString *)key min:(CGFloat)min max:(CGFloat)max step:(CGFloat)step initial:(CGFloat)initial tint:(UIColor *)tint {
 RSAdjustCard *card=[[RSAdjustCard alloc]initWithTitle:title note:note key:key min:min max:max step:step initial:initial tint:tint];[stack addArrangedSubview:card];[self.cards addObject:card];
}
- (void)modeChanged:(UISegmentedControl *)sender {
 CFPreferencesSetAppValue(CFSTR("widthMode"),(__bridge CFNumberRef)@(sender.selectedSegmentIndex),(__bridge CFStringRef)RSDomain);CFPreferencesAppSynchronize((__bridge CFStringRef)RSDomain);notify_post(RSNotify.UTF8String);
}
- (void)resetAll {
 UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"恢复默认参数" message:@"将恢复本页所有滑块与宽度实验模式，保留素材选择和启用开关。" preferredStyle:UIAlertControllerStyleAlert];
 [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
 [alert addAction:[UIAlertAction actionWithTitle:@"恢复" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
  for (RSAdjustCard *card in self.cards) {CFPreferencesSetAppValue((__bridge CFStringRef)card.key,(__bridge CFNumberRef)@(card.initial),(__bridge CFStringRef)RSDomain);}
  CFPreferencesSetAppValue(CFSTR("widthMode"),(__bridge CFNumberRef)@0,(__bridge CFStringRef)RSDomain);
  CFPreferencesAppSynchronize((__bridge CFStringRef)RSDomain);self.mode.selectedSegmentIndex=0;
  for (RSAdjustCard *card in self.cards) [card reloadValue];notify_post(RSNotify.UTF8String);
 }]];[self presentViewController:alert animated:YES completion:nil];
}
@end
