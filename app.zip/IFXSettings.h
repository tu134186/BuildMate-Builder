#import <Foundation/Foundation.h>
FOUNDATION_EXPORT NSString * const IFXPrefsChanged;
FOUNDATION_EXPORT BOOL IFXEnabled(NSString *key, BOOL defaultValue);
