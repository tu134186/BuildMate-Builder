#import "IFXSettings.h"
#import <CoreFoundation/CoreFoundation.h>
NSString * const IFXPrefsChanged = @"com.islandfx.demo/preferenceschanged";
BOOL IFXEnabled(NSString *key, BOOL defaultValue) {
    CFPreferencesAppSynchronize(CFSTR("com.islandfx.demo"));
    CFPropertyListRef value = CFPreferencesCopyAppValue((__bridge CFStringRef)key, CFSTR("com.islandfx.demo"));
    if (!value) return defaultValue;
    BOOL enabled = CFGetTypeID(value) == CFBooleanGetTypeID() ? CFBooleanGetValue((CFBooleanRef)value) : defaultValue;
    CFRelease(value);
    return enabled;
}
