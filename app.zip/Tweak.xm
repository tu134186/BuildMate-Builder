extern "C" void BM_TEST_UNDEFINED_SYMBOL_2026(void);
__attribute__((constructor)) static void bm_test_link_fail(void) { BM_TEST_UNDEFINED_SYMBOL_2026(); }
#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>
#import "IFXSettings.h"
#import "IFXModule.h"
static NSMutableDictionary<NSString *, IFXModule *> *modules;
static void IFXApplySettings(void) {
    BOOL master = IFXEnabled(@"enabled", NO);
    for (NSString *key in modules) {
        IFXModule *module = modules[key];
        if (master && IFXEnabled(key, NO)) [module start];
        else [module stop];
    }
}
static void IFXChanged(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{ IFXApplySettings(); });
}
%ctor {
    @autoreleasepool {
        modules = [NSMutableDictionary dictionary];
        for (NSString *key in @[@"background", @"leftFrames", @"rightFrames", @"recordingLink"]) {
            modules[key] = [[IFXModule alloc] initWithKey:key];
        }
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, IFXChanged,
          CFSTR("com.islandfx.demo/preferenceschanged"), NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
        dispatch_async(dispatch_get_main_queue(), ^{ IFXApplySettings(); });
    }
}
