# ReverseLab V3.2.0 (Build 3200)

## Changes from tested V3.1.0
- Adds a one-tap guided evidence panel with five research topics: Dynamic Island/recording, layout/host, music, hooking, animation.
- Searches existing symbol, Objective-C metadata, string, dependency and branch results; shows source type and allows sharing evidence.
- Adds 200-result paging to analysis lists (rather than cutting off display at 400).
- Preserves the previously verified native picker and archive pipeline, app icon and GitHub workflow.

## Important limitations
- Keyword hits are **clues**, not proof of runtime control flow.
- Mach-O symbol and string extraction caps still exist; large binaries may be truncated.
- No full pseudocode decompiler, Capstone integration, runtime debugger or function-level CFG.
- The original `data.tar.xz`/zstd limitations remain.
- Swift syntax parsing only; Xcode build and device tests are **not** completed.
