import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct HomeView: View {
    @State private var importing = false
    @State private var importedName = ""
    @State private var importStatus = ""
    @State private var busy = false
    @State private var binaries: [EmbeddedBinary] = []
    @State private var report: AnalysisReport?
    @State private var error: String?
    @State private var search = ""
    @State private var tab = 0
    @State private var selectedBinary: EmbeddedBinary?
    @State private var addressQuery = ""
    private let blue = Color(red: 0.12, green: 0.48, blue: 0.99)
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("ReverseLab", systemImage: "cpu")
                            .font(.system(size: 30, weight: .bold, design: .rounded))
                        Text("iOS Binary Analysis Workbench")
                            .font(.subheadline).foregroundStyle(.secondary)
                        Text("本地静态分析 · iOS 16+")
                            .font(.caption).foregroundStyle(blue)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(20).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 22))
                    Button { importing = true } label: {
                        Label("导入 IPA / DEB / dylib", systemImage: "square.and.arrow.down")
                            .font(.headline).frame(maxWidth: .infinity).padding(15)
                    }
                    .buttonStyle(.borderedProminent).tint(blue)
                    if busy { ProgressView("正在读取文件…") }
                    if !importStatus.isEmpty { Text(importStatus).font(.footnote).foregroundStyle(.secondary).textSelection(.enabled) }
                    if !binaries.isEmpty {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("发现 \(binaries.count) 个 Mach-O 文件").font(.headline)
                            ForEach(binaries) { binary in
                                Button {
                                    do { report = try MachOAnalyzer.analyze(binary.data, name: binary.path); selectedBinary = binary; search = ""; tab = 0 }
                                    catch { self.error = error.localizedDescription }
                                } label: {
                                    HStack {
                                        Image(systemName: "doc.text.magnifyingglass")
                                        Text(binary.path).lineLimit(2).font(.subheadline)
                                        Spacer()
                                        Image(systemName: "chevron.right")
                                    }.padding(12).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
                                }.tint(.primary)
                            }
                        }
                    }
                    if let report {
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(report.fileName).font(.headline).lineLimit(2)
                                    Text("\(report.architecture) · \(report.fileType) · \(report.size / 1024) KB")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                ShareLink(item: report.exportText) { Image(systemName: "square.and.arrow.up") }
                            }
                            Picker("分析页", selection: $tab) {
                                Text("概览").tag(0); Text("符号").tag(1); Text("字符串").tag(2); Text("汇编").tag(3); Text("引用").tag(4); Text("ObjC").tag(5); Text("十六进制").tag(6)
                            }.pickerStyle(.menu)
                            if tab == 0 {
                                metric("加载命令", "\(report.commands)")
                                metric("符号", "\(report.symbols.count)（最多展示 5000）")
                                metric("字符串", "\(report.strings.count)（最多展示 3000）")
                                section("Segments", report.segments)
                                section("Dependencies", report.dependencies)
                                section("分析限制", report.warnings)
                                metric("直接分支引用", "\(report.crossReferences.count)")
                                metric("ObjC 元数据条目", "\(report.objcMetadata.count)")
                            } else if tab == 6 {
                                TextField("文件偏移（十六进制，如 1000）", text: $addressQuery)
                                    .textFieldStyle(.roundedBorder)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                                if let binary = selectedBinary {
                                    let raw = addressQuery.lowercased().replacingOccurrences(of: "0x", with: "")
                                    let offset = Int(raw, radix: 16) ?? 0
                                    Text(hexDump(binary.data, from: offset))
                                        .font(.system(size: 10, design: .monospaced))
                                        .textSelection(.enabled)
                                }
                            } else {
                                TextField("搜索当前结果", text: $search).textFieldStyle(.roundedBorder)
                                let items: [String] = tab == 1 ? report.symbols : tab == 2 ? report.strings : tab == 3 ? report.disassembly : tab == 4 ? report.crossReferences : report.objcMetadata
                                let filtered = search.isEmpty ? items : items.filter { $0.localizedCaseInsensitiveContains(search) }
                                Text("显示 \(min(filtered.count, 400)) / \(filtered.count) 条").font(.caption).foregroundStyle(.secondary)
                                ForEach(Array(filtered.prefix(400).enumerated()), id: \.offset) { _, value in
                                    Text(value).font(.system(size: 11, design: .monospaced))
                                        .frame(maxWidth: .infinity, alignment: .leading).textSelection(.enabled)
                                    Divider()
                                }
                            }
                        }.padding(15).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))
                    } else {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("支持 ARM64 / ARM64e", systemImage: "checkmark.seal")
                            Label("Mach-O、符号、字符串、依赖库", systemImage: "list.bullet.rectangle")
                            Label("基础 ARM64 跳转指令解析", systemImage: "point.3.connected.trianglepath.dotted")
                            Text("支持十六进制定位、Mach-O、ObjC 元数据、直接分支引用与基础 ARM64 解码。尚无伪 C 引擎；DEB 的 xz/zstd 仍需先解包。")
                                .font(.caption).foregroundStyle(.secondary)
                        }.font(.subheadline).padding(16)
                    }
                }.padding(16)
            }
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $importing) {
                UniversalBinaryPicker { result in
                    importing = false
                    switch result {
                    case .success(let url):
                        importBinary(url)
                    case .failure(let failure):
                        self.error = "文件选择失败：\(failure.localizedDescription)"
                    }
                }
            }
            .alert("分析提示", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("确定", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
        }
    }
    private func importBinary(_ url: URL) {
        busy = true
        importStatus = "正在导入：\(url.lastPathComponent)"
        // Document picker uses asCopy:true, so this is an app-accessible temporary copy.
        // File coordination handles iCloud / third-party document providers.
        DispatchQueue.global(qos: .userInitiated).async {
            let coordinator = NSFileCoordinator(filePresenter: nil)
            var coordinateError: NSError?
            var outcome: Result<[EmbeddedBinary], Error>?
            coordinator.coordinate(readingItemAt: url, options: [], error: &coordinateError) { readable in
                do {
                    let bytes = try Data(contentsOf: readable, options: .mappedIfSafe)
                    if bytes.isEmpty { throw ArchiveFailure.unsupported("文件为空") }
                    outcome = .success(try ArchiveReader.candidates(fileName: readable.lastPathComponent, data: bytes))
                } catch { outcome = .failure(error) }
            }
            let final = outcome ?? .failure(coordinateError ?? ArchiveFailure.unsupported("无法访问文件，请将文件保存到‘我的 iPhone’后再试"))
            DispatchQueue.main.async {
                busy = false
                switch final {
                case .success(let candidates):
                    binaries = candidates
                    report = nil
                    selectedBinary = nil
                    search = ""
                    tab = 0
                    importStatus = "已读取 \(url.lastPathComponent)，发现 \(candidates.count) 个 Mach-O 文件"
                    if candidates.isEmpty { error = "文件已导入，但没有找到可分析的 Mach-O。若为 xz/zstd 压缩的 DEB，请先解压提取 dylib。" }
                    if candidates.count == 1, let first = candidates.first {
                        do {
                            report = try MachOAnalyzer.analyze(first.data, name: first.path)
                            selectedBinary = first
                        } catch { self.error = "Mach-O 解析失败：\(error.localizedDescription)" }
                    }
                case .failure(let failure):
                    self.error = "导入失败：\(failure.localizedDescription)"
                    importStatus = "导入失败：\(url.lastPathComponent)"
                }
            }
        }
    }
    private func hexDump(_ data: Data, from requested: Int) -> String {
        guard !data.isEmpty else { return "空文件" }
        let start = max(0, min(requested, data.count - 1))
        let end = min(data.count, start + 1024)
        var lines: [String] = []
        for pos in stride(from: start, to: end, by: 16) {
            let chunk = data[pos..<min(end, pos + 16)]
            let hex = chunk.map { String(format: "%02X", $0) }.joined(separator: " ")
            let ascii = chunk.map { ($0 >= 32 && $0 < 127) ? String(UnicodeScalar(Int($0))!) : "." }.joined()
            lines.append(String(format: "%08X", pos) + "  " + hex.padding(toLength: 47, withPad: " ", startingAt: 0) + "  " + ascii)
        }
        return lines.joined(separator: "\n")
    }
    private func metric(_ title: String, _ value: String) -> some View {
        HStack { Text(title).foregroundStyle(.secondary); Spacer(); Text(value).fontWeight(.semibold) }
    }
    private func section(_ title: String, _ values: [String]) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.headline)
            ForEach(Array(values.prefix(30).enumerated()), id: \.offset) { _, item in
                Text(item).font(.system(size: 11, design: .monospaced)).textSelection(.enabled)
            }
        }
    }
}

// Native UIDocumentPicker with broad content types; unlike a single .item filter,
// it allows Files providers to expose unknown .deb/.dylib extensions.
struct UniversalBinaryPicker: UIViewControllerRepresentable {
    let completion: (Result<URL, Error>) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completion: completion) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let types: [UTType] = [.item, .data, .content, .archive,
            UTType(filenameExtension: "deb") ?? .data,
            UTType(filenameExtension: "dylib") ?? .data,
            UTType(filenameExtension: "ipa") ?? .data]
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let completion: (Result<URL, Error>) -> Void
        init(completion: @escaping (Result<URL, Error>) -> Void) { self.completion = completion }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            if let url = urls.first { completion(.success(url)) }
            else { completion(.failure(ArchiveFailure.unsupported("没有选择文件"))) }
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {}
    }
}
