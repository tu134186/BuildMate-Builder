import SwiftUI

@main
struct ReverseLabApp: App {
    var body: some Scene { WindowGroup { HomeView() } }
}
