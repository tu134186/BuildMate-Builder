import Foundation

struct EmbeddedBinary: Identifiable {
    let id = UUID()
    let path: String
    let data: Data
}

enum ArchiveFailure: LocalizedError {
    case unsupported(String)
    var errorDescription: String? {
        if case let .unsupported(message) = self { return message }
        return "无法解包"
    }
}

enum ArchiveReader {
    static let maxExtracted = 80 * 1024 * 1024
    static func candidates(fileName: String, data: Data) throws -> [EmbeddedBinary] {
        let name = fileName.lowercased()
        if name.hasSuffix(".ipa") || data.starts(with: [0x50,0x4b,0x03,0x04]) { return try zip(data) }
        if name.hasSuffix(".deb") || data.starts(with: Array("!<arch>\n".utf8)) { return try deb(data) }
        return [EmbeddedBinary(path: fileName, data: data)]
    }
    private static func inflate(_ bytes: Data, expected: Int, bits: Int) -> Data? {
        guard expected > 0, expected <= maxExtracted else { return nil }
        var output = Data(count: expected)
        let result = bytes.withUnsafeBytes { src in
            output.withUnsafeMutableBytes { dst in
                rl_inflate(src.bindMemory(to: UInt8.self).baseAddress, bytes.count,
                           dst.bindMemory(to: UInt8.self).baseAddress, expected, Int32(bits))
            }
        }
        return result == 0 ? output : nil
    }
    private static func zip(_ data: Data) throws -> [EmbeddedBinary] {
        let r = BinaryReader(data: data)
        guard data.count >= 22 else { throw ArchiveFailure.unsupported("ZIP 文件不完整") }
        let lower = max(0, data.count - 65557)
        guard let eocd = stride(from: data.count - 22, through: lower, by: -1).first(where: { r.u32($0) == 0x06054b50 }),
              let count = r.u16(eocd + 10), let central = r.u32(eocd + 16) else {
            throw ArchiveFailure.unsupported("找不到 ZIP 中央目录；暂不支持 ZIP64")
        }
        var cursor = Int(central)
        var found: [EmbeddedBinary] = []
        for _ in 0..<min(Int(count), 10000) {
            guard r.u32(cursor) == 0x02014b50, let method = r.u16(cursor+10),
                  let compressed = r.u32(cursor+20), let original = r.u32(cursor+24),
                  let nameLen = r.u16(cursor+28), let extra = r.u16(cursor+30),
                  let comment = r.u16(cursor+32), let local = r.u32(cursor+42) else { break }
            let path = r.text(cursor+46, Int(nameLen))
            let step = 46 + Int(nameLen) + Int(extra) + Int(comment)
            guard step > 0, cursor + step <= data.count else { break }
            cursor += step
            guard path.lowercased().hasSuffix(".dylib") || (path.hasPrefix("Payload/") && path.contains(".app/") && !path.hasSuffix("/")) else { continue }
            let start = Int(local)
            guard r.u32(start) == 0x04034b50, let localName = r.u16(start+26), let localExtra = r.u16(start+28) else { continue }
            let offset = start + 30 + Int(localName) + Int(localExtra)
            guard Int(compressed) <= maxExtracted, Int(original) <= maxExtracted,
                  offset >= 0, offset <= data.count, Int(compressed) <= data.count - offset else { continue }
            let bytes = data.subdata(in: offset..<offset+Int(compressed))
            let unpacked: Data?
            if method == 0 { unpacked = bytes }
            else if method == 8 { unpacked = inflate(bytes, expected: Int(original), bits: -15) }
            else { unpacked = nil }
            if let unpacked = unpacked, MachOAnalyzer.isMachO(unpacked) {
                found.append(EmbeddedBinary(path: path, data: unpacked))
            }
        }
        return found
    }
    private static func deb(_ data: Data) throws -> [EmbeddedBinary] {
        let r = BinaryReader(data: data)
        guard data.starts(with: Array("!<arch>\n".utf8)) else { throw ArchiveFailure.unsupported("DEB 的 ar 文件头无效") }
        var cursor = 8
        while cursor + 60 <= data.count {
            let name = r.text(cursor, 16).trimmingCharacters(in: CharacterSet(charactersIn: "/ "))
            guard let size = Int(r.text(cursor+48, 10)), size >= 0 else { break }
            let start = cursor + 60
            guard start <= data.count, size <= data.count - start else { break }
            if name.hasPrefix("data.tar") {
                let payload = data.subdata(in: start..<start+size)
                if name.hasSuffix(".gz") {
                    guard let tar = gzip(payload) else { throw ArchiveFailure.unsupported("DEB gzip 数据解压失败或文件过大") }
                    return tarCandidates(tar)
                }
                if name == "data.tar" { return tarCandidates(payload) }
                throw ArchiveFailure.unsupported("此 DEB 使用 \(name)。当前版本尚未内置 xz/zstd 解压引擎，请先提取 dylib 再导入")
            }
            cursor = start + size + (size % 2)
        }
        throw ArchiveFailure.unsupported("DEB 中未找到 data.tar")
    }
    private static func gzip(_ data: Data) -> Data? {
        // Gzip uncompressed size is stored modulo 2^32 in the last 4 bytes.
        guard data.count >= 18 else { return nil }
        let r = BinaryReader(data: data)
        guard let size = r.u32(data.count-4), size > 0 else { return nil }
        return inflate(data, expected: Int(size), bits: 31)
    }
    private static func tarCandidates(_ data: Data) -> [EmbeddedBinary] {
        let r = BinaryReader(data: data)
        var offset = 0
        var result: [EmbeddedBinary] = []
        while offset + 512 <= data.count {
            let name = r.text(offset, 100)
            if name.isEmpty { break }
            let sizeString = r.text(offset+124, 12).trimmingCharacters(in: .whitespacesAndNewlines)
            let size = Int(sizeString, radix: 8) ?? 0
            let body = offset + 512
            guard size >= 0, body <= data.count, size <= data.count-body else { break }
            if name.lowercased().hasSuffix(".dylib"), size <= maxExtracted {
                let bytes = data.subdata(in: body..<body+size)
                if MachOAnalyzer.isMachO(bytes) { result.append(EmbeddedBinary(path: name, data: bytes)) }
            }
            offset = body + ((size + 511) / 512) * 512
        }
        return result
    }
}
