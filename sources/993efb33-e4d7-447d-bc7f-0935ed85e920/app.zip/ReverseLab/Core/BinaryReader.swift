import Foundation

struct BinaryReader {
    let data: Data
    func u8(_ offset: Int) -> UInt8? { guard offset >= 0 && offset < data.count else { return nil }; return data[offset] }
    func u16(_ offset: Int, big: Bool = false) -> UInt16? {
        guard offset >= 0, offset + 2 <= data.count else { return nil }
        let v = UInt16(data[offset]) | UInt16(data[offset + 1]) << 8
        return big ? v.byteSwapped : v
    }
    func u32(_ offset: Int, big: Bool = false) -> UInt32? {
        guard offset >= 0, offset + 4 <= data.count else { return nil }
        let v = UInt32(data[offset]) | UInt32(data[offset+1]) << 8 | UInt32(data[offset+2]) << 16 | UInt32(data[offset+3]) << 24
        return big ? v.byteSwapped : v
    }
    func u64(_ offset: Int, big: Bool = false) -> UInt64? {
        guard let lo = u32(offset), let hi = u32(offset + 4) else { return nil }
        let v = UInt64(lo) | UInt64(hi) << 32
        return big ? v.byteSwapped : v
    }
    func text(_ offset: Int, _ length: Int) -> String {
        guard offset >= 0, length >= 0, offset <= data.count, length <= data.count - offset else { return "" }
        return String(decoding: data[offset..<offset+length], as: UTF8.self).trimmingCharacters(in: .controlCharacters.union(.whitespaces))
    }
    func cString(_ offset: Int, max: Int = 512) -> String {
        guard offset >= 0, offset < data.count else { return "" }
        let end = min(data.count, offset + max)
        let slice = data[offset..<end].prefix(while: { $0 != 0 })
        return String(decoding: slice, as: UTF8.self)
    }
}
