#include "Inflate.h"
#include <zlib.h>
#include <limits.h>
int rl_inflate(const uint8_t *source, size_t sourceLen, uint8_t *output, size_t outputLen, int windowBits) {
    if (sourceLen > UINT_MAX || outputLen > UINT_MAX) return -1;
    z_stream s = {0};
    s.next_in = (Bytef *)source; s.avail_in = (uInt)sourceLen;
    s.next_out = output; s.avail_out = (uInt)outputLen;
    if (inflateInit2(&s, windowBits) != Z_OK) return -2;
    int r = inflate(&s, Z_FINISH);
    int ok = (r == Z_STREAM_END && s.total_out == outputLen) ? 0 : -3;
    inflateEnd(&s);
    return ok;
}
