#ifndef RL_INFLATE_H
#define RL_INFLATE_H
#include <stddef.h>
#include <stdint.h>
// Returns 0 on success. Caller allocates output buffer to the declared uncompressed size.
int rl_inflate(const uint8_t *source, size_t sourceLen, uint8_t *output, size_t outputLen, int windowBits);
#endif
