# ReverseLab V3.1.0 (Build 3100)

## Confirmed source changes
- Native UIDocumentPicker for broad file selection including custom `.deb`, `.dylib`, `.ipa` types.
- File coordination and background reading to avoid blocking UI.
- Clear import status and explicit error messages.
- Preserves Mach-O static analysis, hex view, Objective-C metadata, and direct-branch analysis.
- Icon asset and XcodeGen configuration retained.

## Limits
- `data.tar.xz` and `data.tar.zst` still require extraction outside the app.
- No complete pseudocode decompiler, runtime injection, or full CFG engine.
- No macOS/Xcode compile or on-device test was run in this environment.
- Please test selecting a `.dylib` first, then `.ipa` and `.deb`; share exact error text if any.
