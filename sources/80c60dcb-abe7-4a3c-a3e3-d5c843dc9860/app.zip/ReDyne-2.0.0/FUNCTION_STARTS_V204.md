# ReDyne V2.0.4 — 函数入口统计修正

- 修正 BinaryParserService.m：原先 `totalFunctions` 只依赖符号表，导致已剥离符号的 dylib 常显示 0 或极少函数。
- 现在在 Mach-O 含 `LC_FUNCTION_STARTS` 时解析 ULEB128 增量并统计函数入口数量；没有该命令时保留原符号统计。
- 保留 V2.0.3 中文界面、DEB 导入及 Mach-O 引擎。
- **限制**：函数入口数量不等于函数体恢复；此版本未实现完整调用图重建、伪代码反编译或函数名称恢复。
- 尚未在 Xcode 或真机上编译验证。
