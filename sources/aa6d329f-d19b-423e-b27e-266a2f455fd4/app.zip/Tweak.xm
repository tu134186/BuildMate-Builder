#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreFoundation/CoreFoundation.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <math.h>
#import <fcntl.h>
#import <unistd.h>
#import <sys/stat.h>
#import <string.h>

// RecordingSharingan V1.0.6: standalone rendering engine.
// No RSV711BestAccessoryHostForElement / RSV6SyncEyeToElement or inherited layout hooks.
// Reconstructed from observed SystemAperture object roles and A-author weak candidate idea.
// The physical camera cutout cannot be painted over by software.
static NSString *const RSDomain = @"com.tu.recordingsharingan";
static NSHashTable<UIView *> *RSCandidates;
static __weak UIView *RSPreferred;
static __weak UIView *RSRecordingElement;
static UIImageView *RSEye;
static __weak UIWindow *RSOverlayWindow;
static NSTimer *RSTickTimer;
static BOOL RSActive = NO;
static BOOL RSInTick = NO;
static BOOL RSReady = NO;
static NSUInteger RSGeneration = 0;
static CGPoint RSLastCenter;
static BOOL RSHasCenter = NO;
static BOOL RSLastLeft = YES;
static NSTimeInterval RSLastLog = 0;
static CGFloat RSCurrentSpeed = -1;

static void RSLog(NSString *format, ...) {
    va_list args; va_start(args, format);
    NSString *line = [[NSString alloc] initWithFormat:format arguments:args]; va_end(args);
    NSString *out=[NSString stringWithFormat:@"[RS-FRESH-1.0.6] %@\n",line];
    NSLog(@"[RS-FRESH-1.0.6] %@",line);
    const char *path="/var/mobile/RecordingSharingan-Fresh.log";
    int fd=open(path,O_WRONLY|O_CREAT|O_APPEND,0644);
    if (fd>=0) { const char *bytes=out.UTF8String; if(bytes) write(fd,bytes,strlen(bytes));close(fd); }
}
static id RSSend0(id obj, SEL sel) {
    if (!obj || ![obj respondsToSelector:sel]) return nil;
    return ((id (*)(id,SEL))objc_msgSend)(obj,sel);
}
static id RSSend1(id obj, SEL sel, id arg) {
    if (!obj || ![obj respondsToSelector:sel]) return nil;
    return ((id (*)(id,SEL,id))objc_msgSend)(obj,sel,arg);
}
static id RSIvar(id obj, const char *name) {
    if (!obj) return nil;
    Ivar iv = class_getInstanceVariable(object_getClass(obj),name);
    return iv ? object_getIvar(obj,iv) : nil;
}
static id RSPref(NSString *key) {
    return CFBridgingRelease(CFPreferencesCopyAppValue((__bridge CFStringRef)key,(__bridge CFStringRef)RSDomain));
}
static BOOL RSBool(NSString *key,BOOL fallback) { id v=RSPref(key); return v ? [v boolValue] : fallback; }
static CGFloat RSNumber(NSString *key,CGFloat fallback,CGFloat lo,CGFloat hi) {
    id v=RSPref(key); CGFloat n=v?[v doubleValue]:fallback;
    return isfinite(n)?MIN(hi,MAX(lo,n)):fallback;
}
static BOOL RSIsPortal(UIView *v) {
    NSString *n=NSStringFromClass(v.class);
    return [n isEqualToString:@"SBSystemApertureSceneElementAccessoryPortalView"] ||
           [n isEqualToString:@"SBSystemApertureSceneElementAccessoryView"];
}
static BOOL RSUsable(UIView *v) {
    return v && v.window && !v.hidden && v.alpha>0.01 &&
           CGRectGetWidth(v.bounds)>=8 && CGRectGetWidth(v.bounds)<=64 &&
           CGRectGetHeight(v.bounds)>=8 && CGRectGetHeight(v.bounds)<=64;
}
static void RSTrack(UIView *v) {
    if (!v || !RSIsPortal(v)) return;
    if (!RSCandidates) RSCandidates=[NSHashTable weakObjectsHashTable];
    if (RSUsable(v)) [RSCandidates addObject:v];
    else { [RSCandidates removeObject:v]; if (RSPreferred==v) RSPreferred=nil; }
}
static UIView *RSFindRecordingElement(void) {
    // Identity is established by registeredElements, not by screen position.
    @try {
        UIApplication *app=[UIApplication sharedApplication];
        id controller=RSSend0(app,NSSelectorFromString(@"systemApertureControllerForMainDisplay"));
        id vc=RSIvar(controller,"_systemApertureViewController");
        id manager=RSIvar(vc,"_systemApertureManager");
        id registered=RSSend0(manager,NSSelectorFromString(@"registeredElements"));
        if (![registered conformsToProtocol:@protocol(NSFastEnumeration)]) return nil;
        for (id element in registered) {
            id ident=RSSend0(element,NSSelectorFromString(@"elementIdentifier"));
            if (![ident isKindOfClass:[NSString class]] ||
                [(NSString *)ident rangeOfString:@"ScreenRecording" options:NSCaseInsensitiveSearch].location==NSNotFound) continue;
            id elementVC=RSSend1(manager,NSSelectorFromString(@"elementViewControllerForElement:"),element);
            id view=RSSend0(elementVC,@selector(view));
            if (![view isKindOfClass:[UIView class]]) view=RSIvar(elementVC,"_view");
            if ([view isKindOfClass:[UIView class]] && [view window]) return view;
        }
    } @catch (NSException *e) { RSLog(@"identity exception %@",e); }
    return nil;
}
static UIWindow *RSIslandWindow(UIView *recording) {
    return recording.window;
}
static UIView *RSNearestElementOwner(UIView *view) {
    for (UIView *v=view;v;v=v.superview) {
        NSString *name=NSStringFromClass(v.class);
        if ([name isEqualToString:@"SAUIElementView"] ||
            [name isEqualToString:@"SBSystemApertureSceneElementView"]) return v;
    }
    return nil;
}
static BOOL RSIsRecordingOwner(UIView *candidate,UIView *recording) {
    if (!candidate || !recording || candidate.window!=recording.window) return NO;
    UIView *candidateOwner=RSNearestElementOwner(candidate);
    UIView *recordingOwner=RSNearestElementOwner(recording);
    // The registered ScreenRecording view is often a generic UIView. Its
    // nearest SAUI ancestor, not its object address, is the identity boundary.
    if (candidateOwner && recordingOwner) return candidateOwner==recordingOwner;
    if (candidateOwner && !recordingOwner) {
        // registeredElements returns a generic UIView detached from SAUI ancestry on iOS16.
        // In this case identity is ScreenRecording registration, and geometry must be checked.
        CGRect rr=[recording convertRect:recording.bounds toView:recording.window];
        CGRect cr=[candidate convertRect:candidate.bounds toView:recording.window];
        if (CGRectGetWidth(rr)>90 || CGRectGetHeight(rr)>75) return NO;
        return CGRectIntersectsRect(CGRectInset(rr,-16,-12),cr);
    }
    for (UIView *v=candidate;v;v=v.superview) if (v==recording) return YES;
    for (UIView *v=recording;v;v=v.superview) if (v==candidate) return YES;
    CGRect rr=[recording convertRect:recording.bounds toView:recording.window];
    CGRect cr=[candidate convertRect:candidate.bounds toView:recording.window];
    return CGRectGetWidth(rr)<=75 && CGRectGetHeight(rr)<=75 &&
           CGRectIntersectsRect(CGRectInset(rr,-12,-12),cr);
}
static BOOL RSValidIslandRect(CGRect r,UIWindow *window) {
    return !CGRectIsNull(r) && !CGRectIsEmpty(r) &&
        isfinite(r.origin.x) && isfinite(r.origin.y) &&
        CGRectGetWidth(r)>=8 && CGRectGetWidth(r)<=75 &&
        CGRectGetHeight(r)>=8 && CGRectGetHeight(r)<=70 &&
        CGRectIntersectsRect(r,CGRectInset(window.bounds,-5,-5));
}
static CGRect RSPresentedRect(UIView *view, UIWindow *window) {
    if (!view || !window) return CGRectNull;
    CALayer *presentation=(CALayer *)view.layer.presentationLayer;
    if (presentation && presentation.superlayer) {
        CGRect layerRect=[presentation convertRect:presentation.bounds toLayer:window.layer];
        if (!CGRectIsNull(layerRect) && !CGRectIsEmpty(layerRect) &&
            isfinite(layerRect.origin.x) && isfinite(layerRect.origin.y)) return layerRect;
    }
    return [view convertRect:view.bounds toView:window];
}
static void RSUpdateRotation(void) {
    if (!RSEye) return;
    CGFloat speed=RSNumber(@"rotationSpeed",1,0.25,3);
    if (fabs(speed-RSCurrentSpeed)<0.001 && [RSEye.layer animationForKey:@"rs.fresh.rotation"]) return;
    // Preserve current presentation angle when changing speed.
    CGFloat angle=0;
    CALayer *present=(CALayer *)RSEye.layer.presentationLayer;
    if (present) {
        CATransform3D tr=present.transform;
        angle=atan2(tr.m12,tr.m11);
    }
    [RSEye.layer removeAnimationForKey:@"rs.fresh.rotation"];
    CABasicAnimation *rotation=[CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotation.fromValue=@(angle); rotation.toValue=@(angle+M_PI*2);
    rotation.duration=2.0/speed;
    rotation.repeatCount=HUGE_VALF;
    rotation.removedOnCompletion=NO;
    [RSEye.layer addAnimation:rotation forKey:@"rs.fresh.rotation"];
    RSCurrentSpeed=speed;
    RSLog(@"rotation speed applied %.2f",speed);
}
static void RSPrepareEye(void);
static void RSRemoveEye(void);
static UIView *RSChooseCandidate(UIView *recording) {
    UIWindow *window=RSIslandWindow(recording);
    if (!window) return nil;
    UIView *best=nil;
    CGFloat bestScore=CGFLOAT_MAX;
    NSUInteger total=0, usable=0, owned=0, accepted=0;
    for (UIView *v in RSCandidates.allObjects) {
        total++;
        if (!RSUsable(v) || v.window!=window) continue;
        usable++;
        if (!RSIsRecordingOwner(v,recording)) continue;
        owned++;
        CGRect r=[v convertRect:v.bounds toView:window];
        if (!RSValidIslandRect(r,window)) continue;
        CGFloat x=CGRectGetMidX(r), y=CGRectGetMidY(r);
        CGFloat centerX=CGRectGetMidX(window.bounds);
        CGFloat distanceToEdge=MIN(fabs(x-(centerX-95)),fabs(x-(centerX+95)));
        CGFloat score=distanceToEdge+fabs(y-32)*0.5;
        if (v==RSPreferred) score-=8.0;
        accepted++;
        if (score<bestScore) {bestScore=score;best=v;}
    }
    static NSTimeInterval lastReject=0;
    NSTimeInterval now=CACurrentMediaTime();
    if ((!best || bestScore>48) && now-lastReject>4) {
        lastReject=now;
        RSLog(@"candidate rejected total=%lu usable=%lu owner=%lu geometries=%lu bestScore=%@ recordingClass=%@ bounds=%@ window=%@",(unsigned long)total,(unsigned long)usable,(unsigned long)owned,(unsigned long)accepted,(accepted ? [NSString stringWithFormat:@"%.1f",bestScore] : @"none"),NSStringFromClass(recording.class),NSStringFromCGRect(recording.bounds),NSStringFromClass(window.class));
    }
    if (bestScore>48.0) return nil;
    return best;
}
// Diagnostic fallback: anchored to the verified ScreenRecording view, never
// to a music/map portal. It is intentionally separate from candidate selection.
static void RSLayoutRecordingFallback(UIView *recording) {
    UIWindow *window=RSIslandWindow(recording);
    if (!window || !RSBool(@"enabled",YES)) return;
    CGRect r=[recording convertRect:recording.bounds toView:window];
    CGFloat mid=CGRectGetMidX(window.bounds);
    // A 100+ point view or a full-width transition is not a dot anchor.
    // Reject it rather than chasing the animated island's left/right edges.
    if (!RSValidIslandRect(r,window)) {
        static NSTimeInterval lastInvalid=0;
        NSTimeInterval now=CACurrentMediaTime();
        if (now-lastInvalid>4) {
            lastInvalid=now;
            RSLog(@"fallback rejected: recording rect=%@; no verified portal",NSStringFromCGRect(r));
        }
        // Keep a previously verified coordinate only for the same recording session.
        if (RSHasCenter && RSEye && RSEye.superview==window) return;
        RSRemoveEye();
        return;
    }
    CGPoint center=CGPointMake(CGRectGetMidX(r),CGRectGetMidY(r));
    BOOL left=center.x<mid;
    // Avoid side-flips caused by transient animations; only change sides
    // when a genuine small recording view has crossed the island midpoint.
    if (RSHasCenter && left!=RSLastLeft && fabs(center.x-mid)<40) left=RSLastLeft;
    CGFloat size=left?RSNumber(@"leftSize",31,20,52):RSNumber(@"rightSize",37,20,56);
    center.x+=left?RSNumber(@"leftXOffset",-2.5,-20,20):RSNumber(@"rightXOffset",0,-20,20);
    center.y+=RSNumber(@"yOffset",0,-12,12);
    RSPrepareEye();
    if (!RSEye) return;
    RSUpdateRotation();
    if (RSEye.superview!=window) { [RSEye removeFromSuperview];[window addSubview:RSEye];RSOverlayWindow=window; }
    [UIView performWithoutAnimation:^{ RSEye.bounds=CGRectMake(0,0,size,size);RSEye.center=center;RSEye.hidden=NO;RSEye.alpha=1; }];
    [window bringSubviewToFront:RSEye];
    RSLastCenter=center;RSHasCenter=YES;RSLastLeft=left;
    static NSTimeInterval lastFallbackLog=0;
    NSTimeInterval now=CACurrentMediaTime();
    if (now-lastFallbackLog>4) {
        lastFallbackLog=now;
        RSLog(@"small recording fallback side=%@ rect=%@ center=(%.1f,%.1f) eye=%p",left?@"L":@"R",NSStringFromCGRect(r),center.x,center.y,RSEye);
    }
}
static UIImage *RSImage(void) {
    NSInteger style=(NSInteger)RSNumber(@"eyeStyle",1,1,2);
    NSString *file=[NSString stringWithFormat:@"/var/jb/Library/Application Support/RecordingSharingan/eye/replay%ld.png",(long)style];
    UIImage *img=[UIImage imageWithContentsOfFile:file];
    if (!img) img=[UIImage imageWithContentsOfFile:[file stringByReplacingOccurrencesOfString:@"/var/jb/" withString:@"/"]];
    return img;
}
static void RSRemoveEye(void) {
    [RSEye removeFromSuperview]; RSEye.hidden=YES;
    RSOverlayWindow=nil; RSPreferred=nil; RSHasCenter=NO;
    RSLog(@"eye detached hidden=%d superview=%p",RSEye.hidden,RSEye.superview);
}
static void RSPrepareEye(void) {
    if (RSEye) return;
    UIImage *image=RSImage();
    if (!image) {RSLog(@"image asset missing");return;}
    RSEye=[[UIImageView alloc] initWithImage:image];
    RSEye.contentMode=UIViewContentModeScaleAspectFit;
    RSEye.userInteractionEnabled=NO;
    RSEye.layer.zPosition=9999;
    RSEye.hidden=YES;
    RSUpdateRotation();
}
static void RSLayoutEye(UIView *portal,UIView *recording) {
    UIWindow *window=RSIslandWindow(recording);
    if (!window || !portal || !RSBool(@"enabled",YES)) return;
    RSPrepareEye(); if (!RSEye) return;
    RSUpdateRotation();
    CGRect portalRect=RSPresentedRect(portal,window);
    if (!RSValidIslandRect(portalRect,window)) return;
    CGPoint center=CGPointMake(CGRectGetMidX(portalRect),CGRectGetMidY(portalRect));
    BOOL left=center.x<CGRectGetMidX(window.bounds);
    CGFloat size=left?RSNumber(@"leftSize",31,20,52):RSNumber(@"rightSize",37,20,56);
    center.x+=left?RSNumber(@"leftXOffset",-2.5,-20,20):RSNumber(@"rightXOffset",0,-20,20);
    center.y+=RSNumber(@"yOffset",0,-12,12);
    // Important difference: render in the island UIWindow, not a clipped 17/22pt portal.
    // This fixes UIView ancestor clipping, but cannot cover the physical camera cutout.
    if (RSEye.superview!=window) { [RSEye removeFromSuperview];[window addSubview:RSEye];RSOverlayWindow=window; }
    [UIView performWithoutAnimation:^{
        RSEye.bounds=CGRectMake(0,0,size,size); RSEye.center=center;
        RSEye.hidden=NO; RSEye.alpha=1;
    }];
    [window bringSubviewToFront:RSEye];
    BOOL changed=!RSHasCenter || hypot(center.x-RSLastCenter.x,center.y-RSLastCenter.y)>1.5 || left!=RSLastLeft;
    RSLastCenter=center; RSHasCenter=YES; RSLastLeft=left;
    NSTimeInterval now=CACurrentMediaTime();
    if (changed && now-RSLastLog>0.25) {
        RSLastLog=now;
        RSLog(@"overlay commit generation=%lu side=%@ portal=%p center=(%.1f,%.1f) size=%.1f window=%@",(unsigned long)RSGeneration,left?@"L":@"R",portal,center.x,center.y,size,NSStringFromClass(window.class));
    }
}
static void RSTick(void) {
    if (!RSReady || RSInTick) return;
    static NSTimeInterval lastProbe=0;
    NSTimeInterval t=CACurrentMediaTime();
    if (t-lastProbe>6.0) {lastProbe=t;RSLog(@"heartbeat candidates=%lu recording=%p eye=%p",(unsigned long)RSCandidates.count,RSRecordingElement,RSEye);}
    RSInTick=YES;
    @try {
        UIView *recording=RSFindRecordingElement();
        if (!recording) {
            if (RSActive) {RSLog(@"recording element disappeared");RSActive=NO;RSGeneration++;RSRemoveEye();}
            RSRecordingElement=nil;
            return;
        }
        if (!RSActive) {RSActive=YES;RSGeneration++;RSLog(@"recording element appeared generation=%lu",(unsigned long)RSGeneration);}
        RSRecordingElement=recording;
        RSUpdateRotation();
        UIView *candidate=RSChooseCandidate(recording);
        if (candidate) {
            if (RSPreferred!=candidate) {
                RSLog(@"candidate changed old=%p new=%p",RSPreferred,candidate);
                RSPreferred=candidate;
            }
            RSLayoutEye(candidate,recording);
        } else if (RSPreferred && RSUsable(RSPreferred) && RSIsRecordingOwner(RSPreferred,recording)) {
            RSLayoutEye(RSPreferred,recording);
        } else {
            RSLayoutRecordingFallback(recording);
        }
    } @catch (NSException *e) {RSLog(@"tick exception %@",e);}
    @finally {RSInTick=NO;}
}
static void RSScheduleTick(void) {
    if (!RSReady) return;
    dispatch_async(dispatch_get_main_queue(),^{RSTick();});
}
static void RSStart(void) {
    if (RSReady) return;
    RSReady=YES;RSCandidates=[NSHashTable weakObjectsHashTable];
    RSTickTimer=[NSTimer scheduledTimerWithTimeInterval:0.18 repeats:YES block:^(NSTimer *timer){RSTick();}];
    RSLog(@"engine started independent v1.0.6");
    RSLog(@"boot probe app=%p controller=%p",[UIApplication sharedApplication],RSSend0([UIApplication sharedApplication],NSSelectorFromString(@"systemApertureControllerForMainDisplay")));
    RSTick();
}
%hook SAUIElementView
- (void)didMoveToWindow {
    %orig;
    RSScheduleTick();
}
- (void)layoutSubviews {
    %orig;
    RSScheduleTick();
}
%end

%hook SBSystemApertureSceneElementAccessoryPortalView
- (void)didMoveToWindow {
    %orig;
    RSTrack((UIView *)self);
    RSScheduleTick();
}
- (void)layoutSubviews {
    %orig;
    RSTrack((UIView *)self);
    RSScheduleTick();
}
- (void)removeFromSuperview {
    RSTrack((UIView *)self);
    %orig;
    RSTrack((UIView *)self);
    RSScheduleTick();
}
%end

%hook SBSystemApertureSceneElementAccessoryView
- (void)didMoveToWindow {
    %orig;
    RSTrack((UIView *)self);
    RSScheduleTick();
}
- (void)layoutSubviews {
    %orig;
    RSTrack((UIView *)self);
    RSScheduleTick();
}
- (void)removeFromSuperview {
    RSTrack((UIView *)self);
    %orig;
    RSTrack((UIView *)self);
    RSScheduleTick();
}
%end

%ctor {
    @autoreleasepool {
        RSLog(@"ctor entered bundle=%@",[[NSBundle mainBundle] bundleIdentifier]);
        if (![[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@"com.apple.springboard"]) return;
        dispatch_async(dispatch_get_main_queue(),^{
            // Wait for UIApplication/SystemAperture to be initialized.
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(3.0*NSEC_PER_SEC)),dispatch_get_main_queue(),^{RSStart();});
        });
    }
}
