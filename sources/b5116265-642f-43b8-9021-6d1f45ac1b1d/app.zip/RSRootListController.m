
#import <UIKit/UIKit.h>
#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <CoreFoundation/CoreFoundation.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <notify.h>

@interface RSRootListController : PSListController <UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIDocumentPickerDelegate>
@end

@implementation RSRootListController
- (NSArray *)specifiers {
    if (!_specifiers) _specifiers = [[self loadSpecifiersFromPlistName:@"Root" target:self] retain];
    return _specifiers;
}
- (void)rsAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *a = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}
- (void)rsPickPhoto {
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        [self rsAlert:@"无法打开相册" message:@"当前系统不支持相册选择器。"]; return;
    }
    UIImagePickerController *p = [[UIImagePickerController alloc] init];
    p.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    p.delegate = self;
    p.allowsEditing = NO;
    [self presentViewController:p animated:YES completion:nil];
    [p release];
}
- (void)rsPickFile {
    UIDocumentPickerViewController *p = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[@"public.png", @"public.jpeg", @"public.image"] inMode:UIDocumentPickerModeImport];
    p.delegate = self;
    [self presentViewController:p animated:YES completion:nil];
    [p release];
}
- (NSString *)rsCustomPath {
    return @"/var/mobile/Library/Application Support/RecordingSharingan/eye/custom.png";
}
- (void)rsNotifyAndSelect:(BOOL)selectCustom {
    if (selectCustom) {
        CFPreferencesSetAppValue(CFSTR("eyeStyle"), (CFPropertyListRef)[NSNumber numberWithInt:6], CFSTR("com.tu.recordingsharingan.settings"));
        CFPreferencesAppSynchronize(CFSTR("com.tu.recordingsharingan.settings"));
    }
    notify_post("com.tu.recordingsharingan.settings.changed");
    [self reloadSpecifiers];
}
- (void)rsImportImage:(UIImage *)image {
    if (!image || image.size.width <= 0 || image.size.height <= 0) {
        [self rsAlert:@"导入失败" message:@"无法解码图片，请选择 PNG 或 JPG。"]; return;
    }
    const CGSize size = CGSizeMake(512,512);
    UIGraphicsBeginImageContextWithOptions(size, NO, 1.0);
    CGRect rect = CGRectZero;
    CGFloat ratio = MIN(size.width/image.size.width, size.height/image.size.height);
    rect.size = CGSizeMake(image.size.width*ratio, image.size.height*ratio);
    rect.origin = CGPointMake((512-rect.size.width)/2.0, (512-rect.size.height)/2.0);
    [image drawInRect:rect];
    UIImage *scaled = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    NSData *png = UIImagePNGRepresentation(scaled);
    NSString *path = [self rsCustomPath];
    NSString *dir = [path stringByDeletingLastPathComponent];
    NSError *error = nil;
    if (![[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:&error] ||
        !png || ![png writeToFile:path options:NSDataWritingAtomic error:&error]) {
        [self rsAlert:@"保存失败" message:error.localizedDescription ?: @"无法写入素材文件"]; return;
    }
    [self rsNotifyAndSelect:YES];
    [self rsAlert:@"导入成功" message:@"已生成 512×512 透明 PNG 并选择「自定义 PNG」。素材会随插件设置通知刷新。"];
}
- (void)rsRemoveCustom {
    NSError *err = nil;
    NSString *path = [self rsCustomPath];
    if ([[NSFileManager defaultManager] fileExistsAtPath:path] &&
        ![[NSFileManager defaultManager] removeItemAtPath:path error:&err]) {
        [self rsAlert:@"删除失败" message:err.localizedDescription]; return;
    }
    CFPreferencesSetAppValue(CFSTR("eyeStyle"), (CFPropertyListRef)[NSNumber numberWithInt:1], CFSTR("com.tu.recordingsharingan.settings"));
    CFPreferencesAppSynchronize(CFSTR("com.tu.recordingsharingan.settings"));
    [self rsNotifyAndSelect:NO];
    [self rsAlert:@"已恢复" message:@"已删除自定义素材并切回内置款式 1。"];
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    [image retain];
    [picker dismissViewControllerAnimated:YES completion:^{ [self rsImportImage:image]; [image release]; }];
}
- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller {}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSURL *url = [urls firstObject];
    if (!url) return;
    BOOL access = [url startAccessingSecurityScopedResource];
    NSData *data = [NSData dataWithContentsOfURL:url];
    if (access) [url stopAccessingSecurityScopedResource];
    UIImage *image = [UIImage imageWithData:data];
    [self rsImportImage:image];
}
@end
