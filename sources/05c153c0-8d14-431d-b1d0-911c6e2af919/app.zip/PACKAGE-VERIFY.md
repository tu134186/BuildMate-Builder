# 7.11.9.4.3.12 包内容验证（必须）

本版重点是设置 Bundle 打包结构；不改原有录屏挂载算法，也不启用容器宽度 hook。

编译成功不代表安装包完整。解包 DEB 后必须确认：

- `/var/jb/Library/MobileSubstrate/DynamicLibraries/RecordingSharingan.dylib` 和同名 `.plist`（实际 DEB 路径可能是 `./var/jb/...`）
- `/var/jb/Library/PreferenceBundles/RecordingSharinganPrefs.bundle/RecordingSharinganPrefs`
- `/var/jb/Library/PreferenceBundles/RecordingSharinganPrefs.bundle/Root.plist`
- `/var/jb/Library/PreferenceLoader/Preferences/RecordingSharingan.plist`

Theos rootless 工程的 Makefile 路径在构建时会映射到 `/var/jb`，请以实际 DEB 文件列表为准。

若任一文件缺失，禁止把该 DEB 当成修复成功；执行 `bash scripts/check-deb.sh <file.deb>`。

本版没有真实设备/编译环境验证；若所有文件存在但设置仍不出现，需要检查 PreferenceLoader 加载、Bundle 的动态链接依赖和系统日志。录屏无效则单独检查 SpringBoard 是否加载 dylib，不能用设置代码猜测原因。
