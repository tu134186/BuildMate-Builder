#!/bin/sh
set -eu
if [ "$#" -ne 1 ]; then echo "Usage: $0 package.deb"; exit 2; fi
if ! command -v dpkg-deb >/dev/null 2>&1; then echo "dpkg-deb not found"; exit 2; fi
LIST=$(dpkg-deb --contents "$1")
fail=0
for file in 'RecordingSharingan.dylib' 'RecordingSharingan.plist' 'RecordingSharinganPrefs.bundle/RecordingSharinganPrefs' 'RecordingSharinganPrefs.bundle/Root.plist' 'PreferenceLoader/Preferences/RecordingSharingan.plist'; do
  if printf '%s\n' "$LIST" | grep -Fq "$file"; then echo "OK $file"; else echo "MISSING $file"; fail=1; fi
done
exit "$fail"
