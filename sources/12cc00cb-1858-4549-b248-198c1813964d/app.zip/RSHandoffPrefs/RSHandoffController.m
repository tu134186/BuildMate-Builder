#import <UIKit/UIKit.h>
#include <math.h>
#import <CoreFoundation/CoreFoundation.h>
#import <notify.h>
#import <Preferences/PSViewController.h>
static CFStringRef const kDomain = CFSTR("com.tu.recordingsharingan.settings");
@interface RSHandoffController : PSViewController
@property(nonatomic,strong) UISwitch *enabledSwitch;
@property(nonatomic,strong) UISlider *slider;
@property(nonatomic,strong) UILabel *numberLabel;
@property(nonatomic,strong) UIButton *minusButton;
@property(nonatomic,strong) UIButton *plusButton;
@end
@implementation RSHandoffController
- (id)initForContentSize:(CGSize)size { return [super initForContentSize:size]; }
- (void)loadView {
    [super loadView];
    self.title = @"灵动岛接续调节";
    UIView *root=self.view; root.backgroundColor=[UIColor systemGroupedBackgroundColor];
    UIView *panel=[UIView new]; panel.translatesAutoresizingMaskIntoConstraints=NO;
    panel.backgroundColor=[UIColor secondarySystemGroupedBackgroundColor]; panel.layer.cornerRadius=15;
    [root addSubview:panel];
    UILabel *header=[UILabel new]; header.text=@"手动调节首次检查等待"; header.font=[UIFont boldSystemFontOfSize:17]; header.translatesAutoresizingMaskIntoConstraints=NO; [panel addSubview:header];
    UISwitch *toggle=[UISwitch new]; self.enabledSwitch=toggle; toggle.translatesAutoresizingMaskIntoConstraints=NO; [toggle addTarget:self action:@selector(toggleChanged:) forControlEvents:UIControlEventValueChanged]; [panel addSubview:toggle];
    UILabel *number=[UILabel new]; self.numberLabel=number; number.textAlignment=NSTextAlignmentCenter; number.font=[UIFont monospacedDigitSystemFontOfSize:36 weight:UIFontWeightSemibold]; number.translatesAutoresizingMaskIntoConstraints=NO; [panel addSubview:number];
    UISlider *slider=[UISlider new]; self.slider=slider; slider.minimumValue=10; slider.maximumValue=150; slider.translatesAutoresizingMaskIntoConstraints=NO; [slider addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged]; [panel addSubview:slider];
    UIButton *minus=[UIButton buttonWithType:UIButtonTypeSystem]; self.minusButton=minus; [minus setTitle:@"−" forState:UIControlStateNormal]; minus.titleLabel.font=[UIFont boldSystemFontOfSize:30]; minus.translatesAutoresizingMaskIntoConstraints=NO; [minus addTarget:self action:@selector(decrease) forControlEvents:UIControlEventTouchUpInside]; [panel addSubview:minus];
    UIButton *plus=[UIButton buttonWithType:UIButtonTypeSystem]; self.plusButton=plus; [plus setTitle:@"+" forState:UIControlStateNormal]; plus.titleLabel.font=[UIFont boldSystemFontOfSize:30]; plus.translatesAutoresizingMaskIntoConstraints=NO; [plus addTarget:self action:@selector(increase) forControlEvents:UIControlEventTouchUpInside]; [panel addSubview:plus];
    UIButton *reset=[UIButton buttonWithType:UIButtonTypeSystem]; [reset setTitle:@"恢复 V7.11.9.4 默认时序" forState:UIControlStateNormal]; reset.translatesAutoresizingMaskIntoConstraints=NO; [reset addTarget:self action:@selector(resetDefaults) forControlEvents:UIControlEventTouchUpInside]; [panel addSubview:reset];
    UILabel *note=[UILabel new]; note.text=@"10–150ms，每次 ±5ms。仅改变首次宿主检查；身份验证、二次确认、420ms 防抢占保护不变。若调快无效，请恢复默认。"; note.numberOfLines=0; note.font=[UIFont systemFontOfSize:13]; note.textColor=[UIColor secondaryLabelColor]; note.translatesAutoresizingMaskIntoConstraints=NO; [root addSubview:note];
    [NSLayoutConstraint activateConstraints:@[
        [panel.topAnchor constraintEqualToAnchor:root.safeAreaLayoutGuide.topAnchor constant:20], [panel.leadingAnchor constraintEqualToAnchor:root.leadingAnchor constant:16], [panel.trailingAnchor constraintEqualToAnchor:root.trailingAnchor constant:-16], [panel.heightAnchor constraintEqualToConstant:270],
        [header.topAnchor constraintEqualToAnchor:panel.topAnchor constant:22], [header.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:16],
        [toggle.centerYAnchor constraintEqualToAnchor:header.centerYAnchor], [toggle.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-16],
        [number.centerXAnchor constraintEqualToAnchor:panel.centerXAnchor], [number.topAnchor constraintEqualToAnchor:header.bottomAnchor constant:24],
        [slider.leadingAnchor constraintEqualToAnchor:minus.trailingAnchor constant:8], [slider.trailingAnchor constraintEqualToAnchor:plus.leadingAnchor constant:-8], [slider.centerYAnchor constraintEqualToAnchor:minus.centerYAnchor],
        [minus.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:15], [minus.topAnchor constraintEqualToAnchor:number.bottomAnchor constant:15], [minus.widthAnchor constraintEqualToConstant:40],
        [plus.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-15], [plus.centerYAnchor constraintEqualToAnchor:minus.centerYAnchor], [plus.widthAnchor constraintEqualToConstant:40],
        [reset.centerXAnchor constraintEqualToAnchor:panel.centerXAnchor], [reset.topAnchor constraintEqualToAnchor:minus.bottomAnchor constant:24],
        [note.topAnchor constraintEqualToAnchor:panel.bottomAnchor constant:14], [note.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:8], [note.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-8]
    ]];
}
- (void)viewWillAppear:(BOOL)animated { [super viewWillAppear:animated]; [self loadSettings]; }
- (void)loadSettings {
    CFPropertyListRef flag=CFPreferencesCopyAppValue(CFSTR("handoffManualEnabled"),kDomain);
    self.enabledSwitch.on=(flag && CFGetTypeID(flag)==CFBooleanGetTypeID() && CFBooleanGetValue((CFBooleanRef)flag)); if(flag)CFRelease(flag);
    CFPropertyListRef val=CFPreferencesCopyAppValue(CFSTR("handoffDelayMs"),kDomain); int n=40;
    if(val && CFGetTypeID(val)==CFNumberGetTypeID())CFNumberGetValue((CFNumberRef)val,kCFNumberIntType,&n); if(val)CFRelease(val);
    self.slider.value=MAX(10,MIN(150,n)); [self refresh];
}
- (void)saveNumber:(int)n { n=MAX(10,MIN(150,n)); self.slider.value=n; CFNumberRef v=CFNumberCreate(kCFAllocatorDefault,kCFNumberIntType,&n); CFPreferencesSetAppValue(CFSTR("handoffDelayMs"),v,kDomain); CFRelease(v); [self synchronize]; [self refresh]; }
- (void)synchronize { CFPreferencesAppSynchronize(kDomain); notify_post("com.tu.recordingsharingan.settings.changed"); }
- (void)refresh { int n=(int)(roundf(self.slider.value/5.f)*5); self.numberLabel.text=[NSString stringWithFormat:@"%d ms",n]; BOOL on=self.enabledSwitch.on; self.slider.enabled=on; self.minusButton.enabled=on && n>10; self.plusButton.enabled=on && n<150; }
- (void)toggleChanged:(UISwitch *)sender { CFPreferencesSetAppValue(CFSTR("handoffManualEnabled"),sender.on?kCFBooleanTrue:kCFBooleanFalse,kDomain); [self synchronize]; [self refresh]; }
- (void)sliderChanged:(UISlider *)sender { [self saveNumber:(int)(roundf(sender.value/5.f)*5)]; }
- (void)decrease { [self saveNumber:(int)(roundf(self.slider.value/5.f)*5)-5]; }
- (void)increase { [self saveNumber:(int)(roundf(self.slider.value/5.f)*5)+5]; }
- (void)resetDefaults { self.enabledSwitch.on=NO; CFPreferencesSetAppValue(CFSTR("handoffManualEnabled"),kCFBooleanFalse,kDomain); [self saveNumber:40]; }
@end
