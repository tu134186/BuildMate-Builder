# IslandScope V1.4.2 — Deep Diagnostics

Rootless Theos project. Build: `make clean package` using a configured Theos iOS 16 SDK. Not compiled or tested on a real device here.

## Observability
- Read-only, class-scoped SpringBoard hooks: `SAUIElementView`, `SBSystemApertureContainerView`, `SBRecordingIndicatorView`.
- Window attach/detach/transfer, parent changes, candidate island shape transitions, object pointer, view geometry, optional hierarchy and layer child counts.
- Sequence IDs, timestamps, rapid window-transition warnings, deduplicated stable layout heartbeat (4 seconds), capped events (16,000 per SpringBoard lifetime).
- No forced layout, no view insertion/removal, no recording controls, no background polling.
- App controls capture and deep mode; shows recent event/anomaly/transition counts, retains native Save to Files log export.

## Important limits
- Island shapes are **geometry-based candidates**, not authoritative recording/music element identity.
- Cannot prove whether RecordingSharingan mounted successfully; correlate its own logs separately.
- View pointers can be reused; sequence/timestamps are essential for interpretation.
- Deep mode adds hierarchy snapshots on changes and can increase overhead; disable it if SpringBoard becomes hot.
- Settings are read by SpringBoard at most once per 3 seconds; respring after installation.

Logs: `/var/mobile/Library/Logs/IslandScope/`, rotated at 2 MB. Package version 1.4.2, app build 141. Supports rootless iOS 16+ subject to device validation.

## V1.4.2 additions (single consolidated diagnostics release)
- Best-effort element identity through safely checked runtime getters; explicitly reports `unresolved` rather than guessing from shape.
- Recording/media *evidence* classification, never a guaranteed authoritative identity.
- Bounded child-view snapshots and ancestry on lifecycle or shape transitions.
- Captured-screen boolean at event time, per-object snapshot throttling, anomaly and migration counters.
- App monitor toggle now preserves the deep-diagnostics setting.
- Original logging/export retained. No third-party tweak hooks or writes.

**Limitations:** private iOS classes differ between builds; an identifier may be unavailable. No guarantee of recording-vs-music identity. Not built on a macOS Theos toolchain or tested on a device.

## V1.4.2 identity correlation
Adds read-only CORRELATION records on controller load/appearance/disappearance. Maps loaded controller root to descendant SAUIElementView / recording indicator and nearest SystemAperture container, plus type-checked zero-argument identity getter hints. A missing getter remains unknown; no geometry-based identity guessing. No forced layout.

## V1.4.2 focus
Read-only runtime method/ivar **names** (never raw ivar values) for selected SystemAperture classes; explicit capture-change event; correlation includes parent scene hint and capture state. `pauseState=unknown` is deliberate: UIKit capture state is not a verified pause/resume signal. Test three separate scenarios and export logs. No extra state-changing hooks.

## V1.4.2 crash fix
Removed synchronous `UIScreen.mainScreen` access from the dyld constructor after SpringBoard SIGABRT in `+[UIScreen mainScreen]` (IslandScope image offset 0x46e0). CAPTURE changes remain observed after startup.

## V1.4.2 VC 宽度诊断
新增三个阶段标记按钮（录屏、调宽、滑动），日志包含 WIDTH_PHASE / WIDTH_VIEW / WIDTH_VC，记录视图屏幕坐标、frame、bounds、父视图和控制器指针。仅观察，不强制刷新系统布局。阶段标记在监控事件时读取（配置读取最多缓存 3 秒）；每次标记后等待约 3 秒并触发一次岛交互。
