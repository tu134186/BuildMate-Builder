# ReDyne V2.0.3 CN — DEB 文件选择界面优化

- 基于 V2.0.2 中文版，仅优化 DEB 解包后的 Mach-O 选择菜单。
- 选择项显示文件名、文件大小、用途类别，不再显示完整安装路径。
- 文件用途根据文件名及安装路径启发式判断，不代表已逆向验证具体功能。
- 保留原 DEB 解包和 Mach-O 分析流程，不修改 C 分析引擎及 BuildMate 工作流。
- 仍仅支持 data.tar.gz / data.tar，暂不支持 data.tar.xz / data.tar.zst。
- 尚未进行 Xcode 编译或真机测试。
