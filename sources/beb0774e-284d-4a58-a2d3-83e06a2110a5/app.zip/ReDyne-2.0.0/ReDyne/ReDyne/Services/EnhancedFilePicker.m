#import "EnhancedFilePicker.h"
#import "LCSharedUtils.h"
#import "UIKitPrivate.h"
#import "utils.h"
#import "FoundationPrivate.h"

static BOOL enhancedFilePickerActive = NO;
static void NSFMGuestHooksInit(void);

@implementation EnhancedFilePicker

+ (void)enable {
    if (enhancedFilePickerActive) {
        return;
    }

    enhancedFilePickerActive = YES;
    NSFMGuestHooksInit();
}

+ (void)disable {
    if (!enhancedFilePickerActive) {
        return;
    }

    enhancedFilePickerActive = NO;
}

+ (BOOL)isActive {
    return enhancedFilePickerActive;
}

@end

BOOL fixFilePicker;
__attribute__((constructor))
static void NSFMGuestHooksInit() {
    if (!enhancedFilePickerActive) {
        return;
    }

    fixFilePicker = YES;

    /*
    // Hook document picker initialization
    swizzle(UIDocumentPickerViewController.class,
            @selector(initForOpeningContentTypes:asCopy:),
            @selector(hook_initForOpeningContentTypes:asCopy:));

    swizzle(UIDocumentPickerViewController.class,
            @selector(initWithDocumentTypes:inMode:),
            @selector(hook_initWithDocumentTypes:inMode:));

    swizzle(UIDocumentBrowserViewController.class,
            @selector(initForOpeningContentTypes:),
            @selector(hook_initForOpeningContentTypes));

    swizzleClassMethod(UTType.class,
                      @selector(typeWithIdentifier:),
                      @selector(hook_typeWithIdentifier:));

    if (fixFilePicker) {
        swizzle(NSURL.class,
                @selector(startAccessingSecurityScopedResource),
                @selector(hook_startAccessingSecurityScopedResource));

        swizzle(UIDocumentPickerViewController.class,
                @selector(setAllowsMultipleSelection:),
                @selector(hook_setAllowsMultipleSelection:));
    }
    */
    // swizzle(DOCConfiguration.class, @selector(setHostIdentifier:), @selector(hook_setHostIdentifier:));
}



// DEB gzip member reader, using iOS system zlib.
#include <zlib.h>
void *redyne_gzip_open(const char *path) { return (void *)gzopen(path, "rb"); }
int32_t redyne_gzip_read(void *handle, uint8_t *buffer, int32_t length) {
    if (!handle || !buffer || length <= 0) return -1;
    return (int32_t)gzread((gzFile)handle, buffer, (unsigned int)length);
}
void redyne_gzip_close(void *handle) { if (handle) gzclose((gzFile)handle); }
