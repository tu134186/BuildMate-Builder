import UIKit

protocol AnalysisMenuDelegate: AnyObject {
    func didSelectAnalysisType(_ type: AnalysisType)
}

enum AnalysisType: String, CaseIterable {
    case xrefs = "交叉引用"
    case objc = "ObjC 类"
    case imports = "导入与导出"
    case dependencies = "依赖库"
    case signature = "代码签名"
    case cfg = "控制流图"
    case callGraph = "函数调用图"
    case memoryMap = "内存映射"
    case pseudocode = "生成伪代码"
    case security = "安全性分析"
    case binaryPatching = "二进制补丁"
    case hexViewer = "十六进制查看器"
    case addressConverter = "地址转换"
    case patternScan = "特征扫描"
    case inspection = "二进制检查"

    var icon: String {
        switch self {
        case .xrefs: return "arrow.triangle.branch"
        case .objc: return "cube.box"
        case .imports: return "arrow.left.arrow.right"
        case .dependencies: return "link"
        case .signature: return "checkmark.seal"
        case .cfg: return "point.3.connected.trianglepath.dotted"
        case .callGraph: return "arrow.triangle.merge"
        case .memoryMap: return "square.stack.3d.up"
        case .pseudocode: return "doc.text.magnifyingglass"
        case .security: return "shield.checkered"
        case .binaryPatching: return "bandage"
        case .hexViewer: return "text.magnifyingglass"
        case .addressConverter: return "arrow.left.arrow.right.circle"
        case .patternScan: return "magnifyingglass"
        case .inspection: return "checklist"
        }
    }

    var description: String {
        switch self {
        case .xrefs: return "函数调用与引用"
        case .objc: return "Objective-C 运行时类"
        case .imports: return "导入与导出符号"
        case .dependencies: return "链接的依赖库与版本"
        case .signature: return "代码签名与权限声明"
        case .cfg: return "可视化控制流图"
        case .callGraph: return "函数调用关系"
        case .memoryMap: return "可视化段与节布局"
        case .pseudocode: return "高级代码结构重建"
        case .security: return "PIE、ARC、栈保护、NX、危险 API"
        case .binaryPatching: return "应用与管理二进制补丁"
        case .hexViewer: return "原始二进制十六进制查看"
        case .addressConverter: return "文件偏移与虚拟地址互转"
        case .patternScan: return "搜索字节特征"
        case .inspection: return "基于规则的二进制检查"
        }
    }
}

class AnalysisMenuViewController: UITableViewController {

    weak var delegate: AnalysisMenuDelegate?

    private let hasObjCData: Bool
    private let hasCodeSignature: Bool
    private let hasSecurityPosture: Bool
    private let availableTypes: [AnalysisType]

    init(hasObjCData: Bool = false, hasCodeSignature: Bool = false, hasSecurityPosture: Bool = false) {
        self.hasObjCData = hasObjCData
        self.hasCodeSignature = hasCodeSignature
        self.hasSecurityPosture = hasSecurityPosture

        var types = [AnalysisType]()
        for type in AnalysisType.allCases {
            switch type {
            case .objc:
                if hasObjCData { types.append(type) }
            case .signature:
                if hasCodeSignature { types.append(type) }
            case .security:
                if hasSecurityPosture { types.append(type) }
            default:
                types.append(type)
            }
        }
        self.availableTypes = types

        super.init(style: .insetGrouped)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Advanced Analysis"
        tableView.register(AnalysisMenuCell.self, forCellReuseIdentifier: "Cell")
        tableView.backgroundColor = Constants.Colors.primaryBackground
    }
    
    // MARK: - Table View
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return availableTypes.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! AnalysisMenuCell
        let type = availableTypes[indexPath.row]
        cell.configure(with: type)
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let type = availableTypes[indexPath.row]
        
        dismiss(animated: true) { [weak self] in
            self?.delegate?.didSelectAnalysisType(type)
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
}

class AnalysisMenuCell: UITableViewCell {
    
    private let iconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.tintColor = Constants.Colors.accentColor
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        return label
    }()
    
    private let descriptionLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 13, weight: .regular)
        label.textColor = .secondaryLabel
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        contentView.addSubview(iconImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(descriptionLabel)
        
        NSLayoutConstraint.activate([
            iconImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            iconImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            iconImageView.widthAnchor.constraint(equalToConstant: 32),
            iconImageView.heightAnchor.constraint(equalToConstant: 32),
            
            titleLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 16),
            titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            titleLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            
            descriptionLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            descriptionLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4),
            descriptionLabel.trailingAnchor.constraint(equalTo: titleLabel.trailingAnchor),
            descriptionLabel.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -12)
        ])
    }
    
    func configure(with type: AnalysisType) {
        iconImageView.image = UIImage(systemName: type.icon)
        titleLabel.text = type.rawValue
        descriptionLabel.text = type.description
        accessoryType = .disclosureIndicator

        // Accessibility
        isAccessibilityElement = true
        accessibilityLabel = type.rawValue
        accessibilityHint = type.description
        accessibilityTraits = .button
    }
}

