#ifndef ReDyne_Bridging_Header_h
#define ReDyne_Bridging_Header_h

#import "AppDelegate.h"
#import "SceneDelegate.h"
#import "DecompiledOutput.h"
#import "BinaryParserService.h"
#import "DisassemblerService.h"
#import "ObjCParserBridge.h"
#import "StringExtractor.h"
#import "MachOHeader.h"
#import "SymbolTable.h"
#import "DisassemblyEngine.h"
#import "ControlFlowGraph.h"
#import "RelocationInfo.h"
#import "ObjCParser.h"
#import "DyldInfo.h"
#import "CodeSignature.h"
#import "EnhancedFilePicker.h"
#import "PseudocodeGenerator.h"
#import "ARM64InstructionDecoder.h"

#import "SwiftMetadata.h"
#import "ChainedFixups.h"
#import "SecurityAnalyzer.h"

#include <stdint.h>
void *redyne_gzip_open(const char *path);
int32_t redyne_gzip_read(void *handle, uint8_t *buffer, int32_t length);
void redyne_gzip_close(void *handle);

#endif

