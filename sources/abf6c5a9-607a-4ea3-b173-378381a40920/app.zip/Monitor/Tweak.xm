#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <os/lock.h>
#import <dispatch/dispatch.h>

// IslandScope 1.4.0: observational hooks only. No hierarchy mutations, no forced layouts.
static NSString *const kDir=@"/var/mobile/Library/Logs/IslandScope";
static NSString *const kLog=@"/var/mobile/Library/Logs/IslandScope/events.log";
static NSString *const kCfg=@"/var/mobile/Library/Logs/IslandScope/config.plist";
static dispatch_queue_t gWriter;
static const unsigned long long kRotate=2ULL*1024ULL*1024ULL;
static const NSUInteger kCap=16000;
static NSUInteger gCount=0;
static NSUInteger gSequence=0;
static NSMutableDictionary<NSString *, NSNumber *> *gLastSnapshot;
static NSUInteger gDetectedRecording=0, gDetectedMedia=0;
static NSMutableDictionary<NSString *, NSDictionary *> *gState;
static NSMutableDictionary<NSString *, NSNumber *> *gLastLayout;
static BOOL gEnabled=YES;
static BOOL gDeep=YES;
static NSTimeInterval gLastConfig=0;

static NSString *ISStamp(void) {
    NSDateFormatter *f=[NSDateFormatter new];
    f.locale=[NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
    f.dateFormat=@"yyyy-MM-dd HH:mm:ss.SSS ZZZZ";
    return [f stringFromDate:[NSDate date]];
}
static void ISWrite(NSString *line) {
    if (!line || !gWriter) return;
    dispatch_async(gWriter, ^{
        @autoreleasepool {
            NSFileManager *fm=[NSFileManager defaultManager];
            if (![fm createDirectoryAtPath:kDir withIntermediateDirectories:YES attributes:nil error:nil]) return;
            unsigned long long bytes=[[fm attributesOfItemAtPath:kLog error:nil] fileSize];
            if (bytes>=kRotate) {
                NSString *old=[kDir stringByAppendingPathComponent:@"events.previous.log"];
                [fm removeItemAtPath:old error:nil];
                [fm moveItemAtPath:kLog toPath:old error:nil];
            }
            if (![fm fileExistsAtPath:kLog]) [fm createFileAtPath:kLog contents:nil attributes:nil];
            NSFileHandle *h=[NSFileHandle fileHandleForWritingAtPath:kLog];
            if (!h) return;
            @try { [h seekToEndOfFile]; [h writeData:[[line stringByAppendingString:@"\n"] dataUsingEncoding:NSUTF8StringEncoding]]; [h closeFile]; }
            @catch (NSException *e) { @try { [h closeFile]; } @catch (NSException *ignored) {} }
        }
    });
}
static void ISEmit(NSString *type, NSString *details) {
    if (gCount>=kCap) return;
    ++gCount; ++gSequence;
    NSString *line=[NSString stringWithFormat:@"%@ [IslandScope 1.4.0] #%lu %@ %@",ISStamp(),(unsigned long)gSequence,type,details?:@""];
    ISWrite(line);
    // Console output is deliberately limited to anomalies / startup to reduce SpringBoard overhead.
    if ([type isEqualToString:@"ANOMALY"] || [type isEqualToString:@"START"]) NSLog(@"%@",line);
}
static void ISReadConfig(void) {
    NSTimeInterval now=NSDate.date.timeIntervalSince1970;
    if (now-gLastConfig<3.0) return;
    gLastConfig=now;
    NSDictionary *d=[NSDictionary dictionaryWithContentsOfFile:kCfg];
    gEnabled=d[@"enabled"] ? [d[@"enabled"] boolValue] : YES;
    gDeep=d[@"deep"] ? [d[@"deep"] boolValue] : YES;
}
static NSString *ISPointer(id x) { return [NSString stringWithFormat:@"%p",x]; }
static NSString *ISKey(id x) { return ISPointer(x); }
static NSString *ISGeometry(UIView *v) {
    CGRect f=v.frame;
    return [NSString stringWithFormat:@"frame={%.1f,%.1f,%.1f,%.1f} bounds={%.1f,%.1f} hidden=%d alpha=%.2f",f.origin.x,f.origin.y,f.size.width,f.size.height,v.bounds.size.width,v.bounds.size.height,v.hidden,v.alpha];
}
static NSString *ISChain(UIView *v) {
    NSMutableArray *parts=[NSMutableArray array];
    UIView *p=v.superview;
    for (int i=0;p && i<5;i++,p=p.superview) [parts addObject:[NSString stringWithFormat:@"%@(%p)",NSStringFromClass(p.class),p]];
    return [parts componentsJoinedByString:@">"];
}
// Safe, bounded runtime inspection: only known zero-argument object getters.
static NSString *ISIdentifier(id obj) {
    if (!obj) return @"unknown";
    const char *names[]={"elementIdentifier","identifier","elementType","activityIdentifier","uniqueIdentifier"};
    for (int i=0;i<5;i++) {
        SEL sel=sel_registerName(names[i]);
        if (![obj respondsToSelector:sel]) continue;
        Method m=class_getInstanceMethod(object_getClass(obj),sel);
        if (!m || method_getNumberOfArguments(m)!=2) continue;
        char ret[128]={0}; method_getReturnType(m,ret,sizeof(ret));
        if (ret[0]!='@') continue;
        @try {
            id (*getter)(id,SEL)=(id(*)(id,SEL))method_getImplementation(m);
            id value=getter(obj,sel);
            if ([value isKindOfClass:NSString.class] || [value isKindOfClass:NSNumber.class]) {
                NSString *str=[value description];
                if (str.length>96) str=[str substringToIndex:96];
                if (str.length) return [NSString stringWithFormat:@"%s:%@",names[i],str];
            }
        } @catch(NSException *ignored) {}
    }
    return @"unknown";
}
static NSString *ISClassSummary(UIView *v) {
    NSMutableArray *items=[NSMutableArray array];
    NSUInteger limit=MIN(v.subviews.count,(NSUInteger)12);
    for(NSUInteger i=0;i<limit;i++) {
        UIView *c=v.subviews[i];
        [items addObject:[NSString stringWithFormat:@"%@(%p,h=%d,a=%.2f)",NSStringFromClass(c.class),c,c.hidden,c.alpha]];
    }
    return [NSString stringWithFormat:@"[%@]%@",[items componentsJoinedByString:@","],v.subviews.count>limit?@"+more":@""];
}
static NSString *ISRole(UIView *v) {
    NSMutableString *e=[NSMutableString stringWithFormat:@"%@ %@",NSStringFromClass(v.class),ISIdentifier(v)];
    UIView *p=v.superview;
    for(int i=0;p && i<4;i++,p=p.superview) [e appendFormat:@" %@ %@",NSStringFromClass(p.class),ISIdentifier(p)];
    NSString *x=e.lowercaseString;
    if ([x containsString:@"screenrecord"] || [x containsString:@"recordingindicator"]) return @"recording-evidence";
    if ([x containsString:@"nowplaying"] || [x containsString:@"mediaremote"]) return @"media-evidence";
    return @"unresolved"; // Never infer role from geometry alone.
}
static void ISSnapshot(UIView *v, NSString *cause) {
    if (!gDeep || !v.window) return;
    if (!gLastSnapshot) gLastSnapshot=[NSMutableDictionary new];
    NSString *key=ISKey(v); NSTimeInterval now=NSDate.date.timeIntervalSince1970;
    if (now-[gLastSnapshot[key] doubleValue]<1.5) return;
    gLastSnapshot[key]=@(now);
    UIView *host=v; for(int i=0;i<6 && host.superview;i++) host=host.superview;
    NSString *role=ISRole(v);
    ISEmit(@"SNAPSHOT",[NSString stringWithFormat:@"cause=%@ role=%@ class=%@ ptr=%@ id=%@ screenCaptured=%d host=%@(%p) chain=%@ children=%@",cause,role,NSStringFromClass(v.class),key,ISIdentifier(v),UIScreen.mainScreen.isCaptured,NSStringFromClass(host.class),host,ISChain(v),ISClassSummary(v)]);
    if ([role isEqualToString:@"recording-evidence"]) gDetectedRecording++;
    if ([role isEqualToString:@"media-evidence"]) gDetectedMedia++;
    if (gLastSnapshot.count>512) [gLastSnapshot removeAllObjects];
}
static NSString *ISShape(UIView *v) {
    CGFloat w=v.bounds.size.width,h=v.bounds.size.height;
    if (w<=0 || h<=0) return @"zero";
    if (h>=70) return @"expanded-candidate";
    if (w<=55 && h<=55) return @"compact-candidate";
    return @"pill-candidate";
}
static void ISObserve(UIView *v, BOOL moved) {
    ISReadConfig();
    if (!gEnabled || gCount>=kCap) return;
    if (!gState) { gState=[NSMutableDictionary new]; gLastLayout=[NSMutableDictionary new]; }
    NSString *key=ISKey(v);
    NSString *win=ISPointer(v.window), *parent=ISPointer(v.superview);
    NSString *geometry=ISGeometry(v), *shape=ISShape(v);
    NSDictionary *prev=gState[key];
    NSString *priorWin=prev[@"window"], *priorParent=prev[@"parent"], *priorShape=prev[@"shape"];
    BOOL changed=!prev || ![win isEqualToString:priorWin] || ![parent isEqualToString:priorParent] || ![shape isEqualToString:priorShape];
    NSTimeInterval now=NSDate.date.timeIntervalSince1970;
    NSString *type=moved?@"WINDOW":@"LAYOUT";
    if (moved || changed) {
        NSString *action=!prev?@"first-seen":(![win isEqualToString:priorWin]?([win isEqualToString:@"0x0"]?@"detach":([priorWin isEqualToString:@"0x0"]?@"attach":@"window-transfer")):(![parent isEqualToString:priorParent]?@"reparent":(![shape isEqualToString:priorShape]?@"shape-transition":@"move-callback")));
        ISEmit(type,[NSString stringWithFormat:@"action=%@ class=%@ ptr=%@ window=%@ prevWindow=%@ parent=%@ prevParent=%@ shape=%@ prevShape=%@ %@%@",action,NSStringFromClass(v.class),key,win,priorWin?:@"none",parent,priorParent?:@"none",shape,priorShape?:@"none",geometry,gDeep?[NSString stringWithFormat:@" chain=%@ children=%lu layerChildren=%lu",ISChain(v),(unsigned long)v.subviews.count,(unsigned long)v.layer.sublayers.count]:@""]);
        if (prev && ![win isEqualToString:priorWin] && now-[prev[@"time"] doubleValue]<1.2) {
            ISEmit(@"ANOMALY",[NSString stringWithFormat:@"rapid-window-transition ptr=%@ class=%@ interval=%.3fs",key,NSStringFromClass(v.class),now-[prev[@"time"] doubleValue]]);
        }
    } else if (!moved) {
        NSTimeInterval last=[gLastLayout[key] doubleValue];
        // Only emit stable layout heartbeat every 4s in deep mode; avoid high-frequency spam.
        if (gDeep && now-last>=4.0) ISEmit(@"LAYOUT",[NSString stringWithFormat:@"action=heartbeat class=%@ ptr=%@ window=%@ %@",NSStringFromClass(v.class),key,win,geometry]);
    }
    if (gDeep && (moved || changed)) {
        NSString *role=ISRole(v);
        ISEmit(@"IDENTITY",[NSString stringWithFormat:@"class=%@ ptr=%@ role=%@ identifier=%@ captured=%d parent=%@ window=%@",NSStringFromClass(v.class),key,role,ISIdentifier(v),UIScreen.mainScreen.isCaptured,parent,win]);
        if ([role isEqualToString:@"unresolved"]) ISEmit(@"INFO",[NSString stringWithFormat:@"identity-unresolved ptr=%@ (geometry is not identity evidence)",key]);
        ISSnapshot(v, moved?@"window-event":@"layout-transition");
    }
    if (moved || changed || !prev) gState[key]=@{@"window":win,@"parent":parent,@"shape":shape,@"time":@(now)};
    if (!moved) gLastLayout[key]=@(now);
    // Bounded bookkeeping; never retain UIView objects.
    if (gState.count>512) { [gState removeAllObjects]; [gLastLayout removeAllObjects]; ISEmit(@"INFO",@"state-map-reset capacity=512"); }
}

struct ISHookSlot { Class cls; IMP move; IMP layout; };
static ISHookSlot gSlots[3]={};
static IMP ISOriginal(id obj, SEL sel) {
    for (Class c=object_getClass(obj);c;c=class_getSuperclass(c))
        for (unsigned i=0;i<3;i++) if (gSlots[i].cls==c)
            return sel==@selector(didMoveToWindow)?gSlots[i].move:gSlots[i].layout;
    return NULL;
}
static void ISMove(id obj,SEL sel) {
    IMP imp=ISOriginal(obj,sel);
    if (imp) ((void(*)(id,SEL))imp)(obj,sel);
    if (imp && [obj isKindOfClass:UIView.class]) ISObserve((UIView *)obj,YES);
}
static void ISLayout(id obj,SEL sel) {
    IMP imp=ISOriginal(obj,sel);
    if (imp) ((void(*)(id,SEL))imp)(obj,sel);
    if (imp && [obj isKindOfClass:UIView.class]) ISObserve((UIView *)obj,NO);
}
static void ISHook(const char *name,unsigned slot) {
    Class cls=objc_getClass(name);
    if (!cls || ![cls isSubclassOfClass:UIView.class]) { ISEmit(@"INFO",[NSString stringWithFormat:@"class-unavailable=%s",name]); return; }
    gSlots[slot].cls=cls;
    SEL sels[]={@selector(didMoveToWindow),@selector(layoutSubviews)};
    IMP hooks[]={reinterpret_cast<IMP>(&ISMove),reinterpret_cast<IMP>(&ISLayout)};
    for (unsigned i=0;i<2;i++) {
        Method method=class_getInstanceMethod(cls,sels[i]);
        if (!method) continue;
        IMP previous=method_getImplementation(method);
        if (previous==hooks[i]) continue;
        IMP *storage=i==0?&gSlots[slot].move:&gSlots[slot].layout;
        *storage=previous;
        if (!class_addMethod(cls,sels[i],hooks[i],method_getTypeEncoding(method))) {
            unsigned n=0; Method *ownMethods=class_copyMethodList(cls,&n); Method own=NULL;
            for (unsigned j=0;j<n;j++) if (method_getName(ownMethods[j])==sels[i]) {own=ownMethods[j];break;}
            if (own) *storage=method_setImplementation(own,hooks[i]);
            else *storage=NULL;
            free(ownMethods);
        }
        if (*storage) ISEmit(@"INFO",[NSString stringWithFormat:@"hook=%s.%s",name,sel_getName(sels[i])]);
    }
}

// Lifecycle and refresh trace: no forced refresh and no mutations.
// Separate hook table, limited to the named SystemAperture classes.
struct ISExtraSlot { Class cls; SEL sel; IMP original; const char *tag; };
static ISExtraSlot gExtra[32]; static unsigned gExtraCount=0;
static NSMutableDictionary<NSString *,NSNumber *> *gExtraTimes;
static IMP ISExtraOriginal(id obj,SEL sel) {
    for (Class c=object_getClass(obj);c;c=class_getSuperclass(c))
        for (unsigned i=0;i<gExtraCount;i++) if(gExtra[i].cls==c && gExtra[i].sel==sel) return gExtra[i].original;
    return NULL;
}
// Identity correlation: observational, bounded, and limited to object-returning getters.
static NSString *ISObjectHint(id obj) {
    if (!obj) return @"nil";
    NSString *identifier=ISIdentifier(obj);
    return [NSString stringWithFormat:@"%@(%p,id=%@)",NSStringFromClass([obj class]),obj,identifier];
}
static id ISObjectGetter(id obj, const char *name) {
    if (!obj) return nil;
    SEL sel=sel_registerName(name);
    if (![obj respondsToSelector:sel]) return nil;
    Method method=class_getInstanceMethod(object_getClass(obj),sel);
    if (!method || method_getNumberOfArguments(method)!=2) return nil;
    char ret[16]={0};method_getReturnType(method,ret,sizeof(ret));
    if(ret[0]!='@') return nil;
    @try { return ((id(*)(id,SEL))method_getImplementation(method))(obj,sel); }
    @catch(NSException *ignored) { return nil; }
}
static NSString *ISControllerLinks(UIViewController *vc) {
    if (!vc || !vc.isViewLoaded) return @"view-not-loaded";
    UIView *root=vc.view;
    NSMutableArray *found=[NSMutableArray array];
    NSMutableArray *pending=[NSMutableArray arrayWithObject:root];
    NSUInteger visited=0;
    while(pending.count && visited<96 && found.count<8) {
        UIView *v=pending.lastObject;[pending removeLastObject];visited++;
        if ([NSStringFromClass(v.class) isEqualToString:@"SAUIElementView"] ||
            [NSStringFromClass(v.class) isEqualToString:@"SBRecordingIndicatorView"]) {
            UIView *container=v;
            for(unsigned i=0;i<9 && container;i++,container=container.superview) {
                if ([NSStringFromClass(container.class) isEqualToString:@"SBSystemApertureContainerView"]) break;
            }
            [found addObject:[NSString stringWithFormat:@"element=%p parent=%p container=%p window=%p",v,v.superview,container, v.window]];
        }
        for(UIView *child in v.subviews) if(pending.count<96) [pending addObject:child];
    }
    const char *selectors[]={"element","sceneElement","systemApertureElement","elementIdentifier","identifier","representedElement"};
    NSMutableArray *hints=[NSMutableArray array];
    for(unsigned i=0;i<6;i++) {
        id x=ISObjectGetter(vc,selectors[i]);
        if(x && x!=vc) [hints addObject:[NSString stringWithFormat:@"%s=%@",selectors[i],ISObjectHint(x)]];
    }
    return [NSString stringWithFormat:@"root=%p rootWindow=%p descendants=%@ getters=%@ scanned=%lu",root,root.window,[found componentsJoinedByString:@";"],[hints componentsJoinedByString:@";"],(unsigned long)visited];
}
// V1.4.0: inspect runtime metadata without invoking unknown private methods.
// These names are *candidates*, not proof that an object represents recording/media.
static void ISRuntimeInventory(const char *name) {
    Class cls=objc_getClass(name);
    if (!cls) { ISEmit(@"RUNTIME",[NSString stringWithFormat:@"class=%s status=absent",name]); return; }
    NSMutableArray *methods=[NSMutableArray array],*ivars=[NSMutableArray array];
    unsigned n=0; Method *ml=class_copyMethodList(cls,&n);
    for(unsigned i=0;i<n;i++) {
        NSString *m=NSStringFromSelector(method_getName(ml[i]));
        NSString *low=m.lowercaseString;
        if ([low containsString:@"element"] || [low containsString:@"record"] || [low containsString:@"identif"] || [low containsString:@"assertion"] || [low containsString:@"scene"] || [low containsString:@"activity"] || [low containsString:@"indicator"] || [low containsString:@"media"])
            if(methods.count<32) [methods addObject:m];
    }
    free(ml); n=0; Ivar *il=class_copyIvarList(cls,&n);
    for(unsigned i=0;i<n;i++) {
        const char *v=ivar_getName(il[i]);if(!v)continue;
        NSString *m=[NSString stringWithUTF8String:v]; NSString *low=m.lowercaseString;
        if ([low containsString:@"element"] || [low containsString:@"record"] || [low containsString:@"identif"] || [low containsString:@"assertion"] || [low containsString:@"scene"] || [low containsString:@"activity"] || [low containsString:@"indicator"] || [low containsString:@"media"])
            if(ivars.count<32) [ivars addObject:m];
    }
    free(il);
    ISEmit(@"RUNTIME",[NSString stringWithFormat:@"class=%s status=present superclass=%@ methods=%@ ivars=%@",name,NSStringFromClass(class_getSuperclass(cls)),[methods componentsJoinedByString:@","],[ivars componentsJoinedByString:@","]]);
}
static void ISCaptureChanged(NSNotification *note) {
    ISEmit(@"CAPTURE",[NSString stringWithFormat:@"event=UIScreenCapturedDidChange screenCaptured=%d note=%@ noteObject=%p pauseState=unknown",UIScreen.mainScreen.isCaptured,note.name,note.object]);
}
static void ISControllerCorrelation(id obj,SEL sel) {
    if (![obj isKindOfClass:UIViewController.class]) return;
    NSString *name=NSStringFromSelector(sel);
    if (![name isEqualToString:@"viewDidLoad"] && ![name isEqualToString:@"viewDidAppear:"] &&
        ![name isEqualToString:@"viewDidDisappear:"]) return;
    UIViewController *vc=(UIViewController *)obj;
    ISEmit(@"CORRELATION",[NSString stringWithFormat:@"vc=%p class=%@ phase=%@ parentVC=%@ parentHint=%@ parentScene=%@ screenCaptured=%d pauseState=unknown %@",vc,NSStringFromClass(vc.class),name,ISPointer(vc.parentViewController),ISObjectHint(vc.parentViewController),ISObjectHint(ISObjectGetter(vc.parentViewController,"sceneElement")),UIScreen.mainScreen.isCaptured,ISControllerLinks(vc)]);
}
static void ISExtraEvent(id obj,SEL sel) {
    ISReadConfig(); if (!gEnabled || !gDeep || gCount>=kCap) return;
    if (!gExtraTimes) gExtraTimes=[NSMutableDictionary new];
    NSString *key=[NSString stringWithFormat:@"%p:%s",obj,sel_getName(sel)];
    NSTimeInterval now=NSDate.date.timeIntervalSince1970;
    NSTimeInterval gap=([NSStringFromSelector(sel) isEqualToString:@"setNeedsLayout"] || [NSStringFromSelector(sel) isEqualToString:@"layoutIfNeeded"])?0.75:0.10;
    if (now-[gExtraTimes[key] doubleValue]<gap) return;
    gExtraTimes[key]=@(now);
    if (gExtraTimes.count>1024) [gExtraTimes removeAllObjects];
    NSString *detail=[NSString stringWithFormat:@"class=%@ ptr=%p method=%@",NSStringFromClass([obj class]),obj,NSStringFromSelector(sel)];
    if ([obj isKindOfClass:UIView.class]) {
        UIView *v=(UIView *)obj;
        detail=[detail stringByAppendingFormat:@" window=%p parent=%p %@ chain=%@",v.window,v.superview,ISGeometry(v),ISChain(v)];
    } else if ([obj isKindOfClass:UIViewController.class]) {
        UIViewController *vc=(UIViewController *)obj;
        UIView *v=vc.isViewLoaded?vc.view:nil;
        detail=[detail stringByAppendingFormat:@" view=%p window=%p parentVC=%p",v,v.window,vc.parentViewController];
    }
    ISEmit(@"LIFECYCLE",detail);
    if ([obj isKindOfClass:UIViewController.class]) ISControllerCorrelation(obj,sel);
}
static void ISExtraVoid(id obj,SEL sel) {
    IMP imp=ISExtraOriginal(obj,sel);
    if (imp) ((void(*)(id,SEL))imp)(obj,sel);
    if (imp) ISExtraEvent(obj,sel);
}
static void ISExtraBool(id obj,SEL sel,BOOL animated) {
    IMP imp=ISExtraOriginal(obj,sel);
    if (imp) ((void(*)(id,SEL,BOOL))imp)(obj,sel,animated);
    if (imp) ISExtraEvent(obj,sel);
}
static void ISInstallExtra(const char *name,const char *methodName,BOOL boolArg) {
    if (gExtraCount>=32) return;
    Class cls=objc_getClass(name); if (!cls) { ISEmit(@"INFO",[NSString stringWithFormat:@"extra-class-unavailable=%s",name]); return; }
    SEL sel=sel_registerName(methodName);
    Method method=class_getInstanceMethod(cls,sel);
    if (!method || method_getNumberOfArguments(method)!=(boolArg?3:2)) return;
    char ret[16]={0};method_getReturnType(method,ret,sizeof(ret));
    if (ret[0]!='v') return;
    IMP hook=boolArg?reinterpret_cast<IMP>(&ISExtraBool):reinterpret_cast<IMP>(&ISExtraVoid);
    IMP old=method_getImplementation(method);if(old==hook) return;
    ISExtraSlot *slot=&gExtra[gExtraCount];
    slot->cls=cls;slot->sel=sel;slot->original=old;slot->tag=methodName;
    // Adding a method to the target class avoids modifying inherited UIKit implementations.
    if (!class_addMethod(cls,sel,hook,method_getTypeEncoding(method))) {
        unsigned count=0;Method *methods=class_copyMethodList(cls,&count);Method own=NULL;
        for(unsigned j=0;j<count;j++) if(method_getName(methods[j])==sel){own=methods[j];break;}
        if(own) slot->original=method_setImplementation(own,hook);
        else slot->original=NULL;
        free(methods);
    }
    if (slot->original) {gExtraCount++;ISEmit(@"INFO",[NSString stringWithFormat:@"extra-hook=%s.%s",name,methodName]);}
}
static void ISInstallLifecycle(void) {
    const char *views[]={"SAUIElementView","SBSystemApertureContainerView","SBRecordingIndicatorView"};
    const char *methods[]={"didMoveToSuperview","setNeedsLayout","layoutIfNeeded","updateConstraints"};
    for(unsigned i=0;i<3;i++) for(unsigned j=0;j<4;j++) ISInstallExtra(views[i],methods[j],NO);
    const char *controllers[]={"SAUIElementViewController","SBSystemApertureViewController","SBRecordingIndicatorViewController"};
    for(unsigned i=0;i<3;i++) {
        ISInstallExtra(controllers[i],"viewDidLoad",NO);
        ISInstallExtra(controllers[i],"viewWillAppear:",YES);
        ISInstallExtra(controllers[i],"viewDidAppear:",YES);
        ISInstallExtra(controllers[i],"viewWillDisappear:",YES);
        ISInstallExtra(controllers[i],"viewDidDisappear:",YES);
    }
}

__attribute__((constructor)) static void ISStart(void) {
    @autoreleasepool {
        gWriter=dispatch_queue_create("com.tu.islandscope.log",DISPATCH_QUEUE_SERIAL);
        ISEmit(@"START",@"read-only observer mode; controller-element correlation + identity probe + hierarchy snapshots + transition anomalies; no layout mutations; unresolved identity is explicit");
        const char *names[]={"SBSystemApertureContainerView","SAUIElementView","SBRecordingIndicatorView"};
        for (unsigned i=0;i<3;i++) ISHook(names[i],i);
        ISInstallLifecycle();
        const char *inspect[]={"SBSystemApertureSceneElement","SAUISystemApertureManager","SAUIElementViewController","SBRecordingIndicatorViewController","SBRecordingIndicatorView","SBSystemApertureViewController","SAUIElementAssertion","SBSystemApertureController"};
        for(unsigned i=0;i<sizeof(inspect)/sizeof(inspect[0]);i++) ISRuntimeInventory(inspect[i]);
        [[NSNotificationCenter defaultCenter] addObserverForName:UIScreenCapturedDidChangeNotification object:nil queue:nil usingBlock:^(NSNotification *note) { ISCaptureChanged(note); }];
        ISEmit(@"CAPTURE",[NSString stringWithFormat:@"event=startup screenCaptured=%d pauseState=unknown",UIScreen.mainScreen.isCaptured]);
    }
}
