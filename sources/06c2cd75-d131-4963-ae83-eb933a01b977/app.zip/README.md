# IslandScope V1.3.8 — Deep Diagnostics

Rootless Theos project. Build: `make clean package` using a configured Theos iOS 16 SDK. Not compiled or tested on a real device here.

## Observability
- Read-only, class-scoped SpringBoard hooks: `SAUIElementView`, `SBSystemApertureContainerView`, `SBRecordingIndicatorView`.
- Window attach/detach/transfer, parent changes, candidate island shape transitions, object pointer, view geometry, optional hierarchy and layer child counts.
- Sequence IDs, timestamps, rapid window-transition warnings, deduplicated stable layout heartbeat (4 seconds), capped events (16,000 per SpringBoard lifetime).
- No forced layout, no view insertion/removal, no recording controls, no background polling.
- App controls capture and deep mode; shows recent event/anomaly/transition counts, retains native Save to Files log export.

## Important limits
- Island shapes are **geometry-based candidates**, not authoritative recording/music element identity.
- Cannot prove whether RecordingSharingan mounted successfully; correlate its own logs separately.
- View pointers can be reused; sequence/timestamps are essential for interpretation.
- Deep mode adds hierarchy snapshots on changes and can increase overhead; disable it if SpringBoard becomes hot.
- Settings are read by SpringBoard at most once per 3 seconds; respring after installation.

Logs: `/var/mobile/Library/Logs/IslandScope/`, rotated at 2 MB. Package version 1.3.8, app build 138. Supports rootless iOS 16+ subject to device validation.

## V1.3.8 additions (single consolidated diagnostics release)
- Best-effort element identity through safely checked runtime getters; explicitly reports `unresolved` rather than guessing from shape.
- Recording/media *evidence* classification, never a guaranteed authoritative identity.
- Bounded child-view snapshots and ancestry on lifecycle or shape transitions.
- Captured-screen boolean at event time, per-object snapshot throttling, anomaly and migration counters.
- App monitor toggle now preserves the deep-diagnostics setting.
- Original logging/export retained. No third-party tweak hooks or writes.

**Limitations:** private iOS classes differ between builds; an identifier may be unavailable. No guarantee of recording-vs-music identity. Not built on a macOS Theos toolchain or tested on a device.
