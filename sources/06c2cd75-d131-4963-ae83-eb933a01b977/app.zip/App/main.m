#import <UIKit/UIKit.h>
static NSString *const ISDir=@"/var/mobile/Library/Logs/IslandScope";
static NSString *const ISLogPath=@"/var/mobile/Library/Logs/IslandScope/events.log";
static NSString *const ISConfig=@"/var/mobile/Library/Logs/IslandScope/config.plist";
@interface ISController : UIViewController
@property(nonatomic,strong) UITextView *logView;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic,strong) UISwitch *monitorSwitch;
@property(nonatomic,strong) NSTimer *timer;
@property(nonatomic,strong) UILabel *sessionStatus;
@property(nonatomic,strong) UISwitch *deepSwitch;
@property(nonatomic,strong) UILabel *diagnostics;

@end
@implementation ISController
- (void)viewDidLoad {
 [super viewDidLoad]; self.title=@"IslandScope"; self.view.backgroundColor=[UIColor colorWithRed:0.055 green:0.065 blue:0.085 alpha:1]; self.navigationController.navigationBar.barStyle=UIBarStyleBlack; self.navigationController.navigationBar.titleTextAttributes=@{NSForegroundColorAttributeName:UIColor.whiteColor};
 UIStackView *stack=[[UIStackView alloc]init]; stack.axis=UILayoutConstraintAxisVertical; stack.spacing=12; stack.translatesAutoresizingMaskIntoConstraints=NO;
 [self.view addSubview:stack];
 [NSLayoutConstraint activateConstraints:@[[stack.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:16],[stack.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],[stack.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],[stack.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-16]]];
 UILabel *headline=[UILabel new]; headline.textColor=[UIColor colorWithRed:1 green:0.28 blue:0.34 alpha:1]; headline.text=@"灵动岛事件研究工具 · V1.3.8"; headline.font=[UIFont boldSystemFontOfSize:19]; [stack addArrangedSubview:headline];
 self.status=[UILabel new]; self.status.textColor=[UIColor lightGrayColor]; self.status.numberOfLines=0; self.status.font=[UIFont systemFontOfSize:13]; [stack addArrangedSubview:self.status];
 UIStackView *row=[UIStackView new]; row.axis=UILayoutConstraintAxisHorizontal; row.alignment=UIStackViewAlignmentCenter; row.spacing=10;
 UILabel *label=[UILabel new]; label.textColor=[UIColor whiteColor]; label.text=@"采集开关"; [row addArrangedSubview:label];
 self.monitorSwitch=[UISwitch new]; [self.monitorSwitch addTarget:self action:@selector(toggle:) forControlEvents:UIControlEventValueChanged]; [row addArrangedSubview:self.monitorSwitch]; [stack addArrangedSubview:row];
 UIStackView *buttons=[UIStackView new]; buttons.axis=UILayoutConstraintAxisHorizontal; buttons.spacing=8; buttons.distribution=UIStackViewDistributionFillEqually;
 NSUInteger buttonIndex=0; for(NSString *title in @[@"刷新",@"导出日志",@"清空日志"]) { UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem]; [b setTitle:title forState:UIControlStateNormal]; b.titleLabel.font=[UIFont systemFontOfSize:14 weight:UIFontWeightSemibold]; b.layer.cornerRadius=8; [b setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal]; b.backgroundColor=(@[[UIColor colorWithRed:0.12 green:0.34 blue:0.68 alpha:1],[UIColor colorWithRed:0.09 green:0.43 blue:0.30 alpha:1],[UIColor colorWithRed:0.54 green:0.16 blue:0.21 alpha:1]])[buttonIndex++]; [b addTarget:self action:@selector(button:) forControlEvents:UIControlEventTouchUpInside]; [buttons addArrangedSubview:b]; }
 [stack addArrangedSubview:buttons];
 UIStackView *deepRow=[UIStackView new]; deepRow.axis=UILayoutConstraintAxisHorizontal; deepRow.alignment=UIStackViewAlignmentCenter; deepRow.spacing=10;
 UILabel *deepLabel=[UILabel new]; deepLabel.text=@"全量诊断（身份 / 宿主 / 快照 / 异常）"; deepLabel.textColor=UIColor.whiteColor; deepLabel.font=[UIFont systemFontOfSize:13]; [deepRow addArrangedSubview:deepLabel];
 self.deepSwitch=[UISwitch new]; [self.deepSwitch addTarget:self action:@selector(toggleDeep:) forControlEvents:UIControlEventValueChanged]; [deepRow addArrangedSubview:self.deepSwitch]; [stack addArrangedSubview:deepRow];
 self.diagnostics=[UILabel new]; self.diagnostics.numberOfLines=0; self.diagnostics.textColor=[UIColor colorWithRed:0.50 green:0.78 blue:1 alpha:1]; self.diagnostics.font=[UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightMedium]; [stack addArrangedSubview:self.diagnostics];
 self.sessionStatus=[UILabel new]; self.sessionStatus.font=[UIFont systemFontOfSize:13 weight:UIFontWeightMedium]; self.sessionStatus.textColor=[UIColor colorWithRed:0.35 green:0.85 blue:0.62 alpha:1]; self.sessionStatus.numberOfLines=2; [stack addArrangedSubview:self.sessionStatus];
 UILabel *device=[UILabel new]; device.text=[NSString stringWithFormat:@"设备系统：%@ · 监控能力按运行时检测",UIDevice.currentDevice.systemVersion]; device.textColor=UIColor.lightGrayColor; device.font=[UIFont systemFontOfSize:12]; [stack addArrangedSubview:device];
 self.logView=[UITextView new]; self.logView.editable=NO; self.logView.font=[UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular]; self.logView.backgroundColor=[UIColor colorWithRed:0.10 green:0.11 blue:0.14 alpha:1]; self.logView.textColor=UIColor.whiteColor; self.logView.layer.cornerRadius=10; [stack addArrangedSubview:self.logView];
 [self reload]; self.timer=[NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(reload) userInfo:nil repeats:YES];
}
- (void)dealloc { [self.timer invalidate]; }
- (void)toggle:(UISwitch *)sender {
 NSError *error=nil; [[NSFileManager defaultManager] createDirectoryAtPath:ISDir withIntermediateDirectories:YES attributes:nil error:&error];
 if(error){ [self alert:error.localizedDescription]; [self reload]; return; }
 NSMutableDictionary *cfg=[NSMutableDictionary dictionaryWithContentsOfFile:ISConfig] ?: [NSMutableDictionary dictionary]; cfg[@"enabled"]=@(sender.on);
 if(![cfg writeToFile:ISConfig atomically:YES]) [self alert:@"无法写入监控配置，请检查文件权限。"];
 [self reload];
}
- (void)toggleDeep:(UISwitch *)sender {
 NSMutableDictionary *cfg=[NSMutableDictionary dictionaryWithContentsOfFile:ISConfig] ?: [NSMutableDictionary dictionary];
 cfg[@"deep"]=@(sender.on);
 if (![cfg writeToFile:ISConfig atomically:YES]) [self alert:@"深度诊断设置保存失败"];
 [self reload];
}
- (void)reload {
 NSDictionary *cfg=[NSDictionary dictionaryWithContentsOfFile:ISConfig]; self.monitorSwitch.on=cfg[@"enabled"] ? [cfg[@"enabled"] boolValue] : YES; self.deepSwitch.on=cfg[@"deep"] ? [cfg[@"deep"] boolValue] : YES;
 NSError *err=nil; NSDictionary *attrs=[[NSFileManager defaultManager] attributesOfItemAtPath:ISLogPath error:&err];
 NSString *all=[NSString stringWithContentsOfFile:ISLogPath encoding:NSUTF8StringEncoding error:nil];
 self.status.text=all.length ? [NSString stringWithFormat:@"日志已生成 · %llu 字节 · 采集 %@\n注意：日志存在不代表当前 SpringBoard 一定已加载插件",[attrs fileSize],self.monitorSwitch.on?@"开启":@"关闭"] : @"暂无日志。请确认已安装 DEB、重启 SpringBoard，并执行录屏测试。";
 NSUInteger events=0, anomalies=0, transitions=0, identity=0, snapshots=0, unresolved=0;
 NSString *sample=all.length>180000 ? [all substringFromIndex:all.length-180000] : (all ?: @"");
 for (NSString *line in [sample componentsSeparatedByString:@"\n"]) {
  if ([line containsString:@"[IslandScope 1.3.8]"]) events++;
  if ([line containsString:@" ANOMALY "]) anomalies++;
  if ([line containsString:@" IDENTITY "]) identity++;
  if ([line containsString:@" SNAPSHOT "]) snapshots++;
  if ([line containsString:@"identity-unresolved"]) unresolved++;
  if ([line containsString:@"shape-transition"] || [line containsString:@"window-transfer"] || [line containsString:@"reparent"]) transitions++;
 }
 self.diagnostics.text=[NSString stringWithFormat:@"事件 %lu · 异常 %lu · 迁移 %lu\n身份探测 %lu · 快照 %lu · 未识别 %lu",(unsigned long)events,(unsigned long)anomalies,(unsigned long)transitions,(unsigned long)identity,(unsigned long)snapshots,(unsigned long)unresolved];
 self.sessionStatus.text=self.monitorSwitch.on?@"● 自动记录已开启 · 无需手动保存\n日志自动写入，达到 2 MB 后轮换保留上一份":@"● 自动记录已关闭";
 if(!all.length){self.logView.text=@"等待真实事件……"; return;}
 NSUInteger start=all.length>14000 ? all.length-14000 : 0;
 self.logView.text=[all substringFromIndex:start];
}
- (void)button:(UIButton *)sender {
 NSString *name=[sender titleForState:UIControlStateNormal];
 if([name isEqualToString:@"刷新"]){[self reload];return;}
 if([name isEqualToString:@"导出日志"]){
  // Native Files export picker; deliberately avoid UIActivityViewController (AirDrop crash).
  NSFileManager *fm=[NSFileManager defaultManager];
  NSString *source=ISLogPath;
  if(![fm fileExistsAtPath:source]) source=[ISDir stringByAppendingPathComponent:@"events.previous.log"];
  if(![fm fileExistsAtPath:source]){ [self alert:@"暂无可导出的日志，请先进行测试。"]; return; }
  // Export staging belongs to the app's temporary area, never the shared Documents path.
  NSString *tempDir=NSTemporaryDirectory();
  if(!tempDir.length){[self alert:@"无法获取临时目录，导出已取消。"] ;return;}
  NSError *error=nil;
  BOOL isDir=NO;
  if(![fm fileExistsAtPath:tempDir isDirectory:&isDir] || !isDir){
   if(![fm createDirectoryAtPath:tempDir withIntermediateDirectories:YES attributes:nil error:&error]){
    [self alert:[NSString stringWithFormat:@"无法准备临时目录：%@",error.localizedDescription ?: @"未知错误"]];return;
   }
  }
  NSDateFormatter *fmt=[NSDateFormatter new]; fmt.dateFormat=@"yyyyMMdd-HHmmss-SSS";
  NSString *file=[NSString stringWithFormat:@"IslandScope-%@.log",[fmt stringFromDate:[NSDate date]]];
  NSString *dest=[tempDir stringByAppendingPathComponent:file];
  if(![fm copyItemAtPath:source toPath:dest error:&error]){
   [self alert:[NSString stringWithFormat:@"准备日志失败：%@",error.localizedDescription ?: @"未知错误"]];return;
  }
  NSURL *url=[NSURL fileURLWithPath:dest];
  UIDocumentPickerViewController *picker=[[UIDocumentPickerViewController alloc] initForExportingURLs:@[url] asCopy:YES];
  picker.modalPresentationStyle=UIModalPresentationFormSheet;
  [self presentViewController:picker animated:YES completion:nil];
  return;
 }
 UIAlertController *confirm=[UIAlertController alertControllerWithTitle:@"清空日志" message:@"只清空事件日志，不影响插件安装。" preferredStyle:UIAlertControllerStyleAlert];
 [confirm addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
 [confirm addAction:[UIAlertAction actionWithTitle:@"清空" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a){ for(NSString *n in @[@"events.log",@"events.previous.log"]) [[NSFileManager defaultManager] removeItemAtPath:[ISDir stringByAppendingPathComponent:n] error:nil]; [self reload]; }]];
 [self presentViewController:confirm animated:YES completion:nil];
}

- (void)alert:(NSString *)msg { UIAlertController *a=[UIAlertController alertControllerWithTitle:@"IslandScope" message:msg preferredStyle:UIAlertControllerStyleAlert]; [a addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]]; [self presentViewController:a animated:YES completion:nil]; }
@end
@interface ISDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@end
@implementation ISDelegate
- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)options {
 self.window=[[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds]; self.window.rootViewController=[[UINavigationController alloc]initWithRootViewController:[ISController new]]; [self.window makeKeyAndVisible]; return YES;
}
@end
int main(int argc,char **argv){@autoreleasepool{return UIApplicationMain(argc,argv,nil,NSStringFromClass([ISDelegate class]));}}
