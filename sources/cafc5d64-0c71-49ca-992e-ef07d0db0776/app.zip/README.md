# ReverseLab V3.4.0 — Guided Research & Full Export

Build 3400 · iOS 16+ · XcodeGen project.

## Changes
- Beginner-focused Dynamic Island research entry point.
- Evidence type filter (symbols, Objective-C, strings, dependencies, branches), text search, 50-item paging.
- One-tap **whole-import** research ZIP (all extracted Mach-O files, all extracted data, five topic files, GPT instructions and index).
- ZIP is a genuine uncompressed ZIP32 with CRC32 checksums; exported via iOS share sheet.
- Long paths remain confined to file detail; category-based research is separate from raw data.
- Previously working UIDocumentPicker and archive importer are unchanged.

## Important limits
- Export includes all data the existing analyzer extracted, not full disassembly of the original binaries. The parser still caps strings, symbols and instructions.
- Topic matches are lexical clues, not proof of control flow.
- No Ghidra-class pseudocode, runtime debugging or full function recovery.
- Build not yet verified with macOS Xcode or iPhone.
