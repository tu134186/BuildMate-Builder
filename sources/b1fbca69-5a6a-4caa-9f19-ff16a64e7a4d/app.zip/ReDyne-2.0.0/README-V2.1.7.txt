ReDyne V2.1.7 / Build 13 - Xref Function Attribution Diagnostics

Based on V2.1.6.
Changes: report marks missing owner function boundaries explicitly and groups unattributed reference addresses into investigation windows (max distance 0x100). These are NOT invented functions.
No change to ZIP/DEB import, disassembler, xref analyzer, or build workflow.
Validation: source/static checks only; requires BuildMate compilation and device test.
