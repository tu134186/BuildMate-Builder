# ReverseLab V3.6.0 / Build 3600

Expanded from V3.5.1 with twelve research categories: Dynamic Island, UI/layout, music, hooking, animation, Objective-C runtime, Swift/C++, IPC, networking/files, preferences/resources, security/anti-debugging, threading/timers. All categories use **keyword candidates**, not proven behaviors.

New per-binary `07_Focused_Disassembly.txt` exports decoded instruction windows around up to 80 matching **defined symbols** across research topics, even if beyond the first 200,000 disassembly preview. Windows are NOT recovered function boundaries. This cannot automatically recover stripped functions or map strings to instructions. Existing ZIP exporter, DEB import and G build workflow unchanged.

Roadmap not yet implemented: full package control/postinst inspection, complete ObjC class method graph, Capstone-class decoder, data xrefs, function recovery, Swift demangling, runtime tracing, dynamic hook identification, resource previews, vulnerability analysis. No claims of those features are made.

Checks: Swift parser only; macOS Xcode compile and device testing outstanding.
