import Foundation

struct EvidenceHit: Identifiable {
    let id: String
    let source: String
    let value: String
}
struct InvestigationTopic: Identifiable {
    let id: String
    let title: String
    let purpose: String
    let terms: [String]
}
enum GuidedAnalysis {
    static let topics: [InvestigationTopic] = [
        .init(id:"island",title:"灵动岛与录屏",purpose:"SystemAperture、录屏指示器、宿主和状态变化",terms:["SystemAperture","RecordingIndicator","ScreenRecording","SAUI","Aperture","isCaptured","ReplayKit","RPScreenRecorder"]),
        .init(id:"layout",title:"视图与布局",purpose:"视图层级、尺寸、坐标、宿主迁移",terms:["setFrame:","setBounds:","layoutSubviews","addSubview:","removeFromSuperview","hostView","setMask:","transform","UIView","CALayer"]),
        .init(id:"music",title:"音乐与后台",purpose:"媒体状态、后台切换、通知",terms:["MediaRemote","NowPlaying","AVPlayer","playback","applicationDidEnterBackground","MRMediaRemote"]),
        .init(id:"hook",title:"注入与 Hook",purpose:"Hook API、注入框架、方法替换",terms:["MSHook","substrate","substitute","ellekit","objc_msgSend","method_setImplementation","class_replaceMethod","dlsym","SpringBoard"]),
        .init(id:"animation",title:"动画与图层",purpose:"关键帧、旋转、遮罩、图层",terms:["rotationAnimation","CABasicAnimation","CAKeyframeAnimation","setRepeatCount:","CAShapeLayer","CGPath","setCornerRadius:","addAnimation:"] ),
        .init(id:"objc",title:"ObjC 与运行时",purpose:"类、方法、协议、消息派发",terms:["objc_","class_","sel_","protocol_","method_","NSClassFromString","respondsToSelector","performSelector"]),
        .init(id:"swift",title:"Swift 与 C++",purpose:"语言运行时、名称修饰及类型线索",terms:["_$s","__swift","swift_","__Z","std::","type metadata"]),
        .init(id:"process",title:"进程与通信",purpose:"XPC、进程、消息与服务",terms:["xpc_","NSXPC","mach_msg","bootstrap_","CFMessagePort","CPDistributedMessagingCenter","posix_spawn"]),
        .init(id:"network",title:"网络与文件",purpose:"网络连接、URL、文件读写",terms:["NSURLSession","CFNetwork","https://","http://","socket","connect","writeToFile","fileExistsAtPath","open("] ),
        .init(id:"prefs",title:"设置与资源",purpose:"偏好设置、资源路径、开关",terms:["NSUserDefaults","CFPreferences","PreferenceBundle","Root.plist","setBool:forKey:","bundleIdentifier","/Library/Preference"]),
        .init(id:"security",title:"安全与反调试",purpose:"签名、调试检测、沙盒、权限",terms:["ptrace","sysctl","SecTask","codesign","csops","sandbox","task_for_pid","amfid"]),
        .init(id:"thread",title:"线程与定时",purpose:"队列、定时器、异步事件",terms:["dispatch_async","dispatch_after","dispatch_source","NSTimer","CADisplayLink","pthread_","NSNotificationCenter"])
    ]
    static func hits(_ report: AnalysisReport, topic: InvestigationTopic, limit: Int = 120) -> [EvidenceHit] {
        let groups: [(String,[String])] = [
            ("符号",report.symbols),("ObjC",report.objcMetadata),("字符串",report.strings),
            ("依赖",report.dependencies),("分支",report.crossReferences)
        ]
        var result: [EvidenceHit] = []
        for (source, items) in groups {
            for (index, value) in items.enumerated() {
                if topic.terms.contains(where: { value.localizedCaseInsensitiveContains($0) }) {
                    result.append(.init(id:"\(source)-\(index)",source:source,value:value))
                    if result.count >= limit { return result }
                }
            }
        }
        return result
    }
}
