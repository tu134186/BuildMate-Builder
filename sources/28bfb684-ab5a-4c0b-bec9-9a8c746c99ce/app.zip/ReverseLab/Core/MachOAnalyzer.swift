import Foundation

struct AnalysisReport {
    let fileName: String
    let architecture: String
    let fileType: String
    let size: Int
    let commands: Int
    let segments: [String]
    let dependencies: [String]
    let symbols: [String]
    let strings: [String]
    let disassembly: [String]
    let crossReferences: [String]
    let objcMetadata: [String]
    let warnings: [String]
    let focusedDisassembly: [String]
    var exportText: String {
        var lines: [String] = [
            "ReverseLab 3.6.0 Static Analysis",
            "File: \(fileName)",
            "Architecture: \(architecture)",
            "Type: \(fileType)",
            "Size: \(size)",
            "Load commands: \(commands)",
            "", "SEGMENTS"
        ]
        lines.append(contentsOf: segments)
        lines.append(contentsOf: ["", "DEPENDENCIES"])
        lines.append(contentsOf: dependencies)
        lines.append(contentsOf: ["", "SYMBOLS"])
        lines.append(contentsOf: symbols)
        lines.append(contentsOf: ["", "STRINGS"])
        lines.append(contentsOf: strings)
        lines.append(contentsOf: ["", "ARM64 INSTRUCTIONS (partial decoder)"])
        lines.append(contentsOf: disassembly)
        lines.append(contentsOf: ["", "FOCUSED DISASSEMBLY WINDOWS (symbol-derived)"])
        lines.append(contentsOf: focusedDisassembly)
        lines.append(contentsOf: ["", "BRANCH CROSS REFERENCES"])
        lines.append(contentsOf: crossReferences)
        lines.append(contentsOf: ["", "OBJC METADATA"])
        lines.append(contentsOf: objcMetadata)
        lines.append(contentsOf: ["", "LIMITATIONS"])
        lines.append(contentsOf: warnings)
        return lines.joined(separator: "\n")
    }
}

enum MachOAnalyzer {
    static func isMachO(_ data: Data) -> Bool {
        guard let magic = BinaryReader(data: data).u32(0) else { return false }
        return [0xfeedfacf, 0xcffaedfe, 0xcafebabe, 0xbebafeca, 0xcafebabf, 0xbfbafeca].contains(magic)
    }
    static func analyze(_ input: Data, name: String) throws -> AnalysisReport {
        let data = try thin(input)
        let r = BinaryReader(data: data)
        guard let magic = r.u32(0), magic == 0xfeedfacf || magic == 0xcffaedfe else {
            throw ArchiveFailure.unsupported("不是受支持的 64 位 Mach-O 文件")
        }
        let big = magic == 0xcffaedfe
        guard let cpu = r.u32(4, big: big), let subtype = r.u32(8, big: big),
              let kind = r.u32(12, big: big), let commandCount = r.u32(16, big: big),
              let commandSize = r.u32(20, big: big), commandCount < 10000,
              commandSize <= data.count, 32 + Int(commandSize) <= data.count else {
            throw ArchiveFailure.unsupported("Mach-O 头部损坏")
        }
        let arch = cpu == 0x0100000c ? ((subtype & 0xff) == 2 ? "ARM64e" : "ARM64") : String(format: "CPU 0x%08X", cpu)
        let type = [2:"Executable", 6:"Dynamic Library", 8:"Bundle" ][Int(kind)] ?? "Mach-O \(kind)"
        var segments: [String] = []
        var deps: [String] = []
        var symbols: [String] = []
        var objcMetadata: [String] = []
        var warnings: [String] = []
        var symbolAddresses: [UInt64: String] = [:]
        var objcSections: [(Int, Int, String)] = []
        var textOffset: Int? = nil
        var textAddress: UInt64 = 0
        var textSize = 0
        var symtab: (Int, Int, Int, Int)? = nil
        var cursor = 32
        for _ in 0..<Int(commandCount) {
            guard let cmd = r.u32(cursor, big: big), let length = r.u32(cursor+4, big: big), length >= 8,
                  Int(length) <= data.count - cursor else { break }
            if cmd == 0x19, length >= 72 {
                let segName = r.text(cursor+8, 16)
                let vm = r.u64(cursor+24, big: big) ?? 0
                let file = r.u64(cursor+40, big: big) ?? 0
                let size = r.u64(cursor+48, big: big) ?? 0
                segments.append(String(format: "%@ VM 0x%llX File 0x%llX Size %llu", segName, vm, file, size))
                let sectionCount = Int(r.u32(cursor+64, big: big) ?? 0)
                if sectionCount < 1000 {
                    for index in 0..<sectionCount {
                        let s = cursor + 72 + index * 80
                        guard s+80 <= cursor+Int(length) else { break }
                        let sectionName = r.text(s,16)
                        if ["__objc_classname", "__objc_methname", "__objc_methtype"].contains(sectionName) {
                            let offset = Int(r.u32(s+48, big: big) ?? 0)
                            let size = Int(min(r.u64(s+40, big: big) ?? 0, 2_000_000))
                            if offset >= 0 && offset <= data.count && size <= data.count-offset { objcSections.append((offset, size, sectionName)) }
                        }
                        if sectionName == "__text" {
                            textAddress = r.u64(s+32, big: big) ?? 0
                            textSize = Int(min(r.u64(s+40, big: big) ?? 0, 32*1024*1024))
                            textOffset = Int(r.u32(s+48, big: big) ?? 0)
                        }
                    }
                }
            }
            if cmd == 0x2, length >= 24 {
                symtab = (Int(r.u32(cursor+8, big: big) ?? 0), Int(r.u32(cursor+12, big: big) ?? 0), Int(r.u32(cursor+16, big: big) ?? 0), Int(r.u32(cursor+20, big: big) ?? 0))
            }
            if [0xc,0xd,0x18,0x1f,0x80000018,0x8000001f,0x8000001c].contains(cmd), length >= 24 {
                let stringOffset = Int(r.u32(cursor+8, big: big) ?? 0)
                if stringOffset < Int(length) { deps.append(r.cString(cursor+stringOffset)) }
            }
            cursor += Int(length)
        }
        if let (symbolOffset, count, stringsOffset, stringsSize) = symtab, count < 500000,
           symbolOffset >= 0, stringsOffset >= 0, stringsSize >= 0,
           stringsOffset <= data.count, stringsSize <= data.count-stringsOffset {
            for i in 0..<count {
                let s = symbolOffset + i*16
                guard s >= 0, s+16 <= data.count else { break }
                let index = Int(r.u32(s, big: big) ?? 0)
                if index > 0 && index < stringsSize {
                    let name = r.cString(stringsOffset+index)
                    if !name.isEmpty {
                        let address = r.u64(s+8, big: big) ?? 0
                        let defined = (r.u8(s+4) ?? 0) & 0x0e != 0
                        symbols.append(String(format: "%@ 0x%llX %@", defined ? "DEF" : "UND", address, name))
                        if defined && address != 0 { symbolAddresses[address] = name }
                    }
                }
                if symbols.count >= 5000 { break }
            }
        }
        var found: [String] = []
        var current: [UInt8] = []
        func flush() {
            if current.count >= 5, let value = String(bytes: current, encoding: .utf8) {
                found.append(value)
            }
            current.removeAll(keepingCapacity: true)
        }
        for b in data {
            if b >= 32 && b <= 126 { current.append(b) }
            else { flush() }
            if found.count >= 50000 { break }
            if current.count > 512 { flush() }
        }
        flush()
        for (offset, size, sectionName) in objcSections {
            var cursor = offset
            while cursor < offset+size && objcMetadata.count < 6000 {
                let value = r.cString(cursor)
                let length = value.utf8.count
                if length >= 2 && length <= 300 { objcMetadata.append("\(sectionName): \(value)") }
                cursor += max(1, length + 1)
            }
        }
        var instructions: [String] = []
        var references: [String] = []
        let instructionPreviewLimit = 200_000
        let referenceLimit = 600_000
        var scanned = 0
        var totalBranches = 0
        if let start = textOffset, start >= 0, start <= data.count {
            let end = min(data.count, start + textSize)
            if end >= start + 4 {
                for offset in stride(from: start, to: end-3, by: 4) {
                    guard let word = r.u32(offset, big: big) else { break }
                    let pc = textAddress + UInt64(offset-start)
                    scanned += 1
                    if instructions.count < instructionPreviewLimit {
                        let decoded = decode(word, pc: pc)
                        let label = symbolAddresses[pc].map { " <\($0)>" } ?? ""
                        instructions.append(String(format: "0x%llX%@  %08X  %@", pc, label, word, decoded))
                    }
                    if let target = branchTarget(word, pc: pc) {
                        totalBranches += 1
                        if references.count < referenceLimit {
                            let targetLabel = symbolAddresses[target].map { " \($0)" } ?? ""
                            let mnemonic = (word & 0xfc000000) == 0x94000000 ? "CALL" : "BRANCH"
                            references.append(String(format: "%@ 0x%llX -> 0x%llX%@", mnemonic, pc, target, targetLabel))
                        }
                    }
                }
            }
        }
        // Address windows are derived from actual defined symbols, never invented function boundaries.
        let topicTerms = GuidedAnalysis.topics.flatMap { $0.terms }
        let matchedAddresses = symbolAddresses.keys.filter { address in
            guard let name = symbolAddresses[address] else { return false }
            return topicTerms.contains { name.localizedCaseInsensitiveContains($0) }
        }.sorted().prefix(80)
        var focused: [String] = []
        if let start = textOffset, start >= 0, start <= data.count {
            for address in matchedAddresses {
                guard address >= textAddress else { continue }
                let delta = address - textAddress
                guard delta < UInt64(textSize), delta <= UInt64(Int.max) else { continue }
                let offset = start + Int(delta)
                guard offset >= start, offset + 4 <= data.count else { continue }
                focused.append(String(format: "\n### 0x%llX %@ (symbol anchor; NOT verified function boundary)", address, symbolAddresses[address] ?? ""))
                let lower = max(start, offset - 64)
                let upper = min(data.count - 4, start + textSize - 4, offset + 128)
                if lower <= upper {
                    for location in stride(from: lower, through: upper, by: 4) {
                        guard let word = r.u32(location, big: big) else { continue }
                        let pc = textAddress + UInt64(location-start)
                        focused.append(String(format: "0x%llX  %08X  %@", pc, word, decode(word, pc: pc)))
                    }
                }
            }
        }
        warnings.append("完整扫描 __text: \(scanned) 条指令；汇编展示前 \(instructions.count) 条，后续指令未导出")
        warnings.append("直接分支总数 \(totalBranches)；已导出 \(references.count) 条（上限 \(referenceLimit)）")
        if found.count >= 50000 { warnings.append("ASCII 字符串提取达到 50,000 条上限") }
        if objcMetadata.count >= 6000 { warnings.append("ObjC 元数据达到 6,000 条上限") }
        if symbols.count >= 5000 { warnings.append("符号表达到 5,000 条上限") }
        warnings.append("反汇编为内置部分指令解码器，不是完整 Capstone/Ghidra 反编译器")
        warnings.append("交叉引用仅包括直接分支；间接调用和 Objective-C 消息发送尚未建立引用图")
        warnings.append("没有执行动态调试；函数边界及伪 C 代码未恢复")
        return AnalysisReport(fileName: name, architecture: arch, fileType: type, size: data.count, commands: Int(commandCount), segments: segments, dependencies: deps, symbols: symbols, strings: found, disassembly: instructions, crossReferences: references, objcMetadata: objcMetadata, warnings: warnings, focusedDisassembly: focused)
    }
    private static func thin(_ data: Data) throws -> Data {
        let r = BinaryReader(data: data)
        guard let magic = r.u32(0) else { throw ArchiveFailure.unsupported("空文件") }
        if magic == 0xbebafeca || magic == 0xcafebabe {
            let big = magic == 0xbebafeca
            let count = Int(r.u32(4,big:big) ?? 0)
            guard count > 0, count < 64 else { throw ArchiveFailure.unsupported("FAT 头部无效") }
            for i in 0..<count {
                let off = 8 + i*20
                guard let cpu = r.u32(off,big:big), let start = r.u32(off+8,big:big), let size = r.u32(off+12,big:big) else { continue }
                if cpu == 0x0100000c, Int(start) <= data.count, Int(size) <= data.count-Int(start) {
                    return data.subdata(in: Int(start)..<Int(start+size))
                }
            }
            throw ArchiveFailure.unsupported("FAT 中未找到 ARM64 切片")
        }
        return data
    }
    private static func branchTarget(_ w: UInt32, pc: UInt64) -> UInt64? {
        var displacement: Int64
        if (w & 0x7c000000) == 0x14000000 {
            displacement = Int64(w & 0x03ffffff)
            if displacement & 0x02000000 != 0 { displacement -= 0x04000000 }
        } else if (w & 0xff000010) == 0x54000000 || (w & 0x7e000000) == 0x34000000 || (w & 0x7e000000) == 0x36000000 {
            let bitTest = (w & 0x7e000000) == 0x36000000
            displacement = Int64((w >> 5) & (bitTest ? 0x3fff : 0x7ffff))
            let bits: Int64 = bitTest ? 14 : 19
            if displacement & (1 << (bits-1)) != 0 { displacement -= (1 << bits) }
        } else { return nil }
        return UInt64(bitPattern: Int64(bitPattern: pc) &+ (displacement << 2))
    }
    private static func decode(_ w: UInt32, pc: UInt64) -> String {
        if let detailed = ARM64Decoder.decode(w, pc: pc) { return detailed }
        if w == 0xd65f03c0 { return "ret" }
        if w == 0xd503201f { return "nop" }
        if let target = branchTarget(w, pc: pc) {
            if (w & 0xff000010) == 0x54000000 {
                let conditions = ["eq","ne","cs","cc","mi","pl","vs","vc","hi","ls","ge","lt","gt","le","al","nv"]
                return String(format: "b.%@ 0x%llX", conditions[Int(w & 15)], target)
            }
            if (w & 0x7e000000) == 0x34000000 {
                return String(format: "%@ %@%u, 0x%llX", (w & 0x01000000) != 0 ? "cbnz" : "cbz", (w & 0x80000000) != 0 ? "x" : "w", w & 31, target)
            }
            if (w & 0x7e000000) == 0x36000000 {
                return String(format: "%@ %@%u, #%u, 0x%llX", (w & 0x01000000) != 0 ? "tbnz" : "tbz", (w & 0x80000000) != 0 ? "x" : "w", w & 31, ((w >> 26) & 0x20) | ((w >> 19) & 0x1f), target)
            }
        }
        if (w & 0x9f000000) == 0x90000000 { return "adrp (page-relative address)" }
        if (w & 0x9f000000) == 0x10000000 { return "adr (pc-relative address)" }
        if (w & 0x7f800000) == 0x52800000 { return String(format: "movz w%u, #0x%X", w & 31, (w >> 5) & 0xffff) }
        if (w & 0x7f800000) == 0x72800000 { return String(format: "movk w%u, #0x%X", w & 31, (w >> 5) & 0xffff) }
        if (w & 0x7f800000) == 0x12800000 { return String(format: "movn w%u, #0x%X", w & 31, (w >> 5) & 0xffff) }
        if (w & 0xff800000) == 0xd2800000 { return String(format: "movz x%u, #0x%X", w & 31, (w >> 5) & 0xffff) }
        if (w & 0xff800000) == 0xf2800000 { return String(format: "movk x%u, #0x%X", w & 31, (w >> 5) & 0xffff) }
        if (w & 0xfc000000) == 0x94000000 || (w & 0x7c000000) == 0x14000000 {
            var imm = Int64(w & 0x03ffffff)
            if imm & 0x02000000 != 0 { imm -= 0x04000000 }
            let target = UInt64(bitPattern: Int64(bitPattern: pc) &+ (imm << 2))
            return String(format: "%@ 0x%llX", (w & 0xfc000000) == 0x94000000 ? "bl" : "b", target)
        }
        if (w & 0xfffffc1f) == 0xd61f0000 { return "br x\((w >> 5) & 31)" }
        if (w & 0xfffffc1f) == 0xd63f0000 { return "blr x\((w >> 5) & 31)" }
        return "unclassified"
    }
}
