import Foundation

/// A deliberately bounded ARM64 decoder. Unknown instructions remain explicitly unknown.
/// No function boundaries or Objective-C dispatch targets are inferred.
enum ARM64Decoder {
    private static func reg(_ n: UInt32, _ wide: Bool = true, sp: Bool = false) -> String {
        if n == 31 { return sp ? "sp" : (wide ? "xzr" : "wzr") }
        return "\(wide ? "x" : "w")\(n)"
    }
    static func decode(_ w: UInt32, pc: UInt64) -> String? {
        let rd = w & 31
        let rn = (w >> 5) & 31
        let rm = (w >> 16) & 31
        if w == 0xd65f03c0 { return "ret" }
        if (w & 0xfffffc1f) == 0xd65f0000 { return "ret \(reg(rn))" }
        if (w & 0xfffffc1f) == 0xd61f0000 { return "br \(reg(rn))" }
        if (w & 0xfffffc1f) == 0xd63f0000 { return "blr \(reg(rn))" }
        if w == 0xd503201f { return "nop" }
        // ADD/SUB (immediate): x/w, shift 0 or 12, flag-setting forms
        if (w & 0x1f000000) == 0x11000000 {
            let wide = (w & 0x80000000) != 0
            let sub = (w & 0x40000000) != 0
            let setFlags = (w & 0x20000000) != 0
            let shift = (w & 0x00c00000) >> 22
            if shift <= 1 {
                let imm = ((w >> 10) & 0xfff) << (shift == 1 ? 12 : 0)
                let op = sub ? (setFlags ? "subs" : "sub") : (setFlags ? "adds" : "add")
                if setFlags && rd == 31 { return "cmp \(reg(rn,wide,sp:true)), #\(imm)" }
                if !setFlags && imm == 0 && rn == 31 { return "mov \(reg(rd,wide,sp:true)), sp" }
                return "\(op) \(reg(rd,wide,sp: !setFlags)), \(reg(rn,wide,sp:true)), #\(imm)"
            }
        }
        // ADD/SUB shifted register (LSL form)
        if (w & 0x1f200000) == 0x0b000000 && ((w >> 22) & 3) == 0 {
            let wide = (w & 0x80000000) != 0
            let sub = (w & 0x40000000) != 0
            let flags = (w & 0x20000000) != 0
            let amount = (w >> 10) & 63
            let op = sub ? (flags ? "subs" : "sub") : (flags ? "adds" : "add")
            if flags && rd == 31 { return "cmp \(reg(rn,wide)), \(reg(rm,wide))\(amount == 0 ? "" : ", lsl #\(amount)")" }
            return "\(op) \(reg(rd,wide)), \(reg(rn,wide)), \(reg(rm,wide))\(amount == 0 ? "" : ", lsl #\(amount)")"
        }
        // MOV aliases of ORR (shifted register), only exact unshifted form
        if (w & 0x7fe0ffe0) == 0x2a0003e0 {
            let wide = (w & 0x80000000) != 0
            return "mov \(reg(rd,wide)), \(reg(rm,wide))"
        }
        // Unsigned offset loads/stores (scalar 32/64)
        if (w & 0xbfc00000) == 0xb9000000 || (w & 0xbfc00000) == 0xb9400000 ||
           (w & 0xffc00000) == 0xf9000000 || (w & 0xffc00000) == 0xf9400000 {
            let wide = (w & 0x40000000) != 0
            let load = (w & 0x00400000) != 0
            let imm = ((w >> 10) & 0xfff) * (wide ? 8 : 4)
            return "\(load ? "ldr" : "str") \(reg(rd,wide)), [\(reg(rn, true, sp:true))\(imm == 0 ? "" : ", #\(imm)") ]"
        }
        // MOVZ/MOVK/MOVN (wide move)
        let movKey = w & 0x7f800000
        if [UInt32(0x52800000),0x72800000,0x12800000].contains(movKey) {
            let wide = (w & 0x80000000) != 0
            let hw = (w >> 21) & 3
            if wide || hw < 2 {
                let op = movKey == 0x52800000 ? "movz" : (movKey == 0x72800000 ? "movk" : "movn")
                return "\(op) \(reg(rd,wide)), #0x\(String((w >> 5) & 0xffff,radix:16))\(hw == 0 ? "" : ", lsl #\(hw * 16)")"
            }
        }
        // ADR/ADRP with resolved PC-relative address
        if (w & 0x9f000000) == 0x10000000 || (w & 0x9f000000) == 0x90000000 {
            let page = (w & 0x80000000) != 0
            var imm = Int64(((w >> 5) & 0x7ffff) << 2 | ((w >> 29) & 3))
            if (imm & 0x100000) != 0 { imm -= 0x200000 }
            let base = page ? (pc & ~UInt64(4095)) : pc
            let delta = page ? imm << 12 : imm
            let target = UInt64(bitPattern: Int64(bitPattern: base) &+ delta)
            return "\(page ? "adrp" : "adr") \(reg(rd)), 0x\(String(target,radix:16))"
        }
        // LDR literal (32/64), PC relative
        if (w & 0xbf000000) == 0x18000000 {
            let wide = (w & 0x40000000) != 0
            var imm = Int64((w >> 5) & 0x7ffff)
            if imm & 0x40000 != 0 { imm -= 0x80000 }
            let target = UInt64(bitPattern: Int64(bitPattern: pc) &+ (imm << 2))
            return "ldr \(reg(rd,wide)), 0x\(String(target,radix:16))"
        }
        return nil
    }
}
