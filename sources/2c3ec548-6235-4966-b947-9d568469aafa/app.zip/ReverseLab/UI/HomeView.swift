import SwiftUI
import UniformTypeIdentifiers

struct HomeView: View {
    @State private var importing = false
    @State private var busy = false
    @State private var binaries: [EmbeddedBinary] = []
    @State private var report: AnalysisReport?
    @State private var error: String?
    @State private var search = ""
    @State private var tab = 0
    private let blue = Color(red: 0.12, green: 0.48, blue: 0.99)
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("ReverseLab", systemImage: "cpu")
                            .font(.system(size: 30, weight: .bold, design: .rounded))
                        Text("iOS Binary Analysis Workbench")
                            .font(.subheadline).foregroundStyle(.secondary)
                        Text("本地静态分析 · iOS 16+")
                            .font(.caption).foregroundStyle(blue)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(20).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 22))
                    Button { importing = true } label: {
                        Label("导入 IPA / DEB / dylib", systemImage: "square.and.arrow.down")
                            .font(.headline).frame(maxWidth: .infinity).padding(15)
                    }
                    .buttonStyle(.borderedProminent).tint(blue)
                    if busy { ProgressView("正在读取文件…") }
                    if !binaries.isEmpty {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("发现 \(binaries.count) 个 Mach-O 文件").font(.headline)
                            ForEach(binaries) { binary in
                                Button {
                                    do { report = try MachOAnalyzer.analyze(binary.data, name: binary.path); search = "" }
                                    catch { self.error = error.localizedDescription }
                                } label: {
                                    HStack {
                                        Image(systemName: "doc.text.magnifyingglass")
                                        Text(binary.path).lineLimit(2).font(.subheadline)
                                        Spacer()
                                        Image(systemName: "chevron.right")
                                    }.padding(12).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
                                }.tint(.primary)
                            }
                        }
                    }
                    if let report {
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(report.fileName).font(.headline).lineLimit(2)
                                    Text("\(report.architecture) · \(report.fileType) · \(report.size / 1024) KB")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                ShareLink(item: report.exportText) { Image(systemName: "square.and.arrow.up") }
                            }
                            Picker("分析页", selection: $tab) {
                                Text("概览").tag(0); Text("符号").tag(1); Text("字符串").tag(2); Text("汇编").tag(3); Text("引用").tag(4); Text("ObjC").tag(5)
                            }.pickerStyle(.menu)
                            if tab == 0 {
                                metric("加载命令", "\(report.commands)")
                                metric("符号", "\(report.symbols.count)（最多展示 5000）")
                                metric("字符串", "\(report.strings.count)（最多展示 3000）")
                                section("Segments", report.segments)
                                section("Dependencies", report.dependencies)
                                section("分析限制", report.warnings)
                                metric("直接分支引用", "\(report.crossReferences.count)")
                                metric("ObjC 元数据条目", "\(report.objcMetadata.count)")
                            } else {
                                TextField("搜索当前结果", text: $search).textFieldStyle(.roundedBorder)
                                let items: [String] = tab == 1 ? report.symbols : tab == 2 ? report.strings : tab == 3 ? report.disassembly : tab == 4 ? report.crossReferences : report.objcMetadata
                                let filtered = search.isEmpty ? items : items.filter { $0.localizedCaseInsensitiveContains(search) }
                                Text("显示 \(min(filtered.count, 400)) / \(filtered.count) 条").font(.caption).foregroundStyle(.secondary)
                                ForEach(Array(filtered.prefix(400).enumerated()), id: \.offset) { _, value in
                                    Text(value).font(.system(size: 11, design: .monospaced))
                                        .frame(maxWidth: .infinity, alignment: .leading).textSelection(.enabled)
                                    Divider()
                                }
                            }
                        }.padding(15).background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))
                    } else {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("支持 ARM64 / ARM64e", systemImage: "checkmark.seal")
                            Label("Mach-O、符号、字符串、依赖库", systemImage: "list.bullet.rectangle")
                            Label("基础 ARM64 跳转指令解析", systemImage: "point.3.connected.trianglepath.dotted")
                            Text("专业静态分析：Mach-O、ObjC 元数据、直接分支交叉引用、基础 ARM64 解码。暂不提供伪 C；DEB 暂不支持 xz / zstd。")
                                .font(.caption).foregroundStyle(.secondary)
                        }.font(.subheadline).padding(16)
                    }
                }.padding(16)
            }
            .navigationBarTitleDisplayMode(.inline)
            .fileImporter(isPresented: $importing, allowedContentTypes: [.data, .archive, .item], allowsMultipleSelection: false) { result in
                switch result {
                case .failure(let failure): self.error = failure.localizedDescription
                case .success(let urls):
                    guard let url = urls.first else { return }
                    let access = url.startAccessingSecurityScopedResource()
                    defer { if access { url.stopAccessingSecurityScopedResource() } }
                    do {
                        let data = try Data(contentsOf: url)
                        binaries = try ArchiveReader.candidates(fileName: url.lastPathComponent, data: data)
                        report = nil
                        if binaries.isEmpty { error = "压缩包中没有找到支持的 Mach-O 文件，或压缩格式暂不支持" }
                        if binaries.count == 1, let first = binaries.first {
                            report = try MachOAnalyzer.analyze(first.data, name: first.path)
                        }
                    } catch { self.error = error.localizedDescription }
                }
            }
            .alert("分析提示", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("确定", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
        }
    }
    private func metric(_ title: String, _ value: String) -> some View {
        HStack { Text(title).foregroundStyle(.secondary); Spacer(); Text(value).fontWeight(.semibold) }
    }
    private func section(_ title: String, _ values: [String]) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.headline)
            ForEach(Array(values.prefix(30).enumerated()), id: \.offset) { _, item in
                Text(item).font(.system(size: 11, design: .monospaced)).textSelection(.enabled)
            }
        }
    }
}
