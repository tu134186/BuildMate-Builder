# ReverseLab V2.0.0 — iOS 本地二进制分析工作台

支持 iOS 16+，SwiftUI 原生界面，XcodeGen 工程和 GitHub Actions IPA 打包。

## 本次实际实现
- 本地导入 dylib、Mach-O、IPA (ZIP) 和部分 DEB（gzip / tar）。
- FAT ARM64 切片选择、Mach-O 加载命令、架构、依赖库、符号地址与定义状态。
- 从 `__objc_classname`、`__objc_methname`、`__objc_methtype` 节提取 ObjC 元数据。
- ARM64 部分指令解码，最多扫描 200,000 条；识别直接分支目标和交叉引用。
- 可搜索的符号、字符串、指令、分支引用、ObjC 元数据视图；报告分享。

## 尚未实现，不能混淆
- 不支持 xz/zstd DEB（常见越狱 DEB 可能无法直接打开，请先提取 dylib）。
- 不是 Ghidra/IDA：未集成完整反汇编引擎，不能生成可靠伪 C 或还原原始源码。
- 不做动态调试、SpringBoard 注入、UIView 运行时层级采集；**没有** Rootless DEB 组件。
- 交叉引用只覆盖直接分支，不含 ObjC 消息派发/间接跳转。
- 不能直接读取受保护的加密 App 二进制。

## 构建
GitHub Actions 手动运行 `.github/workflows/build.yml`。也可在 macOS 使用 `xcodegen generate` 然后 `xcodebuild -project ReverseLab.xcodeproj -scheme ReverseLab -sdk iphoneos CODE_SIGNING_ALLOWED=NO build`。构建产物为未签名 IPA，需要合适的安装方式。

## 状态
本工程尚未在 macOS Xcode 上实际编译或真机验证。文件格式解析必须对不可信输入保持警惕；不要分析来历不明的恶意二进制。
