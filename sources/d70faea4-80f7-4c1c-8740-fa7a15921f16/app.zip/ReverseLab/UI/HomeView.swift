import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct HomeView: View {
    @State private var importing = false
    @State private var importedName = ""
    @State private var importStatus = ""
    @State private var busy = false
    @State private var binaries: [EmbeddedBinary] = []
    @State private var report: AnalysisReport?
    @State private var error: String?
    @State private var search = ""
    @State private var tab = 0
    @State private var selectedBinary: EmbeddedBinary?
    @State private var addressQuery = ""
    @State private var selectedTopic = "island"
    @State private var page = 0
    private let blue = Color(red: 0.12, green: 0.48, blue: 0.99)
    @State private var workspace = 0
    private var activeName: String { selectedBinary.map { ($0.path as NSString).lastPathComponent } ?? "未选择文件" }
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 10) {
                    Image(systemName: "cpu.fill").font(.title2).foregroundStyle(blue)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("ReverseLab").font(.title2.bold())
                        Text("BINARY RESEARCH STUDIO").font(.system(size: 10, weight: .semibold, design: .monospaced)).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { importing = true } label: { Image(systemName: "plus.app.fill").font(.title2) }.accessibilityLabel("导入文件")
                }.padding(.horizontal, 18).padding(.vertical, 12)
                Divider()
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        if workspace == 0 { dashboard }
                        else if workspace == 1 { filesPanel }
                        else if workspace == 2 { analysisPanel }
                        else { reportPanel }
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(16)
                }
                Divider()
                HStack(spacing: 0) {
                    navItem(0, "工作台", "square.grid.2x2")
                    navItem(1, "文件", "folder")
                    navItem(2, "分析", "waveform.path.ecg.rectangle")
                    navItem(3, "报告", "doc.text")
                }.padding(.top, 9).padding(.bottom, 5)
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $importing) {
                UniversalBinaryPicker { result in
                    importing = false
                    switch result {
                    case .success(let url): importBinary(url)
                    case .failure(let failure): self.error = "文件选择失败：\(failure.localizedDescription)"
                    }
                }
            }
            .alert("分析提示", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("确定", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
        }
    }
    private func navItem(_ index: Int, _ title: String, _ icon: String) -> some View {
        Button { workspace = index } label: {
            VStack(spacing: 4) {
                Image(systemName: icon).font(.system(size: 19))
                Text(title).font(.caption2)
            }.foregroundStyle(workspace == index ? blue : Color.secondary)
                .frame(maxWidth: .infinity)
        }.buttonStyle(.plain)
    }
    private var dashboard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text("逆向工作台").font(.title2.bold())
                    Text("本地静态分析 · iOS 16+").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "checkmark.shield.fill").foregroundStyle(.green)
            }
            Button { importing = true } label: {
                Label("导入 IPA / DEB / dylib", systemImage: "square.and.arrow.down")
                    .font(.headline).frame(maxWidth: .infinity).padding(13)
            }.buttonStyle(.borderedProminent).tint(blue)
            if busy { ProgressView("正在读取文件…") }
            if !importStatus.isEmpty { Text(importStatus).font(.caption).foregroundStyle(.secondary).lineLimit(3) }
            if let report {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(activeName).font(.headline).lineLimit(1)
                            Text("\(report.architecture) · \(report.fileType) · \(report.size / 1024) KB").font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        ShareLink(item: report.exportText) { Image(systemName: "square.and.arrow.up") }
                    }
                    HStack(spacing: 8) {
                        stat("符号", report.symbols.count)
                        stat("ObjC", report.objcMetadata.count)
                        stat("分支引用", report.crossReferences.count)
                    }
                }.padding(15).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
            }
            Text("研究工作台").font(.headline)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                module("智能线索", "自动筛选证据", "sparkle.magnifyingglass", 7)
                module("ARM64 汇编", "基础指令浏览", "chevron.left.forwardslash.chevron.right", 3)
                module("交叉引用", "直接分支目标", "arrow.triangle.branch", 4)
                module("ObjC 浏览器", "元数据查看", "curlybraces", 5)
            }
            if binaries.count > 1 {
                Button("管理全部 \(binaries.count) 个二进制文件") { workspace = 1 }
                    .font(.subheadline)
            }
            Text("提示：当前是静态线索和基础指令分析，不包含完整伪 C 反编译与运行时动态调试。")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
    private func stat(_ name: String, _ value: Int) -> some View {
        VStack(spacing: 5) {
            Text(value.formatted()).font(.system(size: 17, weight: .bold, design: .rounded)).minimumScaleFactor(0.6).lineLimit(1)
            Text(name).font(.caption2).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity).padding(9).background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
    }
    private func module(_ title: String, _ detail: String, _ icon: String, _ target: Int) -> some View {
        Button {
            tab = target; page = 0; workspace = 2
        } label: {
            VStack(alignment: .leading, spacing: 10) {
                Image(systemName: icon).font(.title2).foregroundStyle(blue)
                Text(title).font(.subheadline.bold()).foregroundStyle(.primary)
                Text(detail).font(.caption2).foregroundStyle(.secondary)
            }.frame(maxWidth: .infinity, minHeight: 85, alignment: .leading).padding(12)
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 15))
        }.buttonStyle(.plain)
    }
    private var filesPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("文件管理").font(.title2.bold())
            Text("已发现 \(binaries.count) 个 Mach-O 文件").font(.caption).foregroundStyle(.secondary)
            if binaries.isEmpty { Text("请先从工作台导入 IPA、DEB 或 dylib").foregroundStyle(.secondary) }
            ForEach(binaries) { binary in
                Button {
                    do {
                        report = try MachOAnalyzer.analyze(binary.data, name: binary.path)
                        selectedBinary = binary; search = ""; tab = 7; page = 0; workspace = 2
                    } catch { self.error = error.localizedDescription }
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "doc.zipper").font(.title3).foregroundStyle(blue)
                        VStack(alignment: .leading, spacing: 5) {
                            Text((binary.path as NSString).lastPathComponent).font(.subheadline.bold()).lineLimit(1)
                            Text(binary.path).font(.caption2).foregroundStyle(.secondary).lineLimit(2).truncationMode(.middle)
                        }
                        Spacer(minLength: 0)
                        Image(systemName: "chevron.right").font(.caption).foregroundStyle(.secondary)
                    }.padding(14).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))
                }.buttonStyle(.plain)
            }
        }
    }
    private var analysisPanel: some View {
        VStack(alignment: .leading, spacing: 13) {
            Text("逆向分析").font(.title2.bold())
            if let report {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(activeName).font(.headline).lineLimit(1)
                        Text(report.architecture).font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { workspace = 1 } label: { Label("切换", systemImage: "arrow.left.arrow.right").font(.caption) }
                }
                Picker("分析模块", selection: $tab) {
                    Text("智能线索").tag(7); Text("概览").tag(0); Text("符号").tag(1)
                    Text("字符串").tag(2); Text("汇编").tag(3); Text("引用").tag(4)
                    Text("ObjC").tag(5); Text("十六进制").tag(6)
                }.pickerStyle(.menu).onChange(of: tab) { _ in page = 0 }
                VStack(alignment: .leading, spacing: 12) {
                    if tab == 7 { guidedPanel(report) }
                    else if tab == 0 {
                        metric("加载命令", "\(report.commands)")
                        metric("符号", "\(report.symbols.count)（当前提取）")
                        metric("字符串", "\(report.strings.count)（当前提取）")
                        section("Segments", report.segments)
                        section("Dependencies", report.dependencies)
                        section("分析限制", report.warnings)
                        metric("直接分支引用", "\(report.crossReferences.count)")
                        metric("ObjC 元数据条目", "\(report.objcMetadata.count)")
                    } else if tab == 6 {
                        TextField("文件偏移（十六进制，如 1000）", text: $addressQuery)
                            .textFieldStyle(.roundedBorder).textInputAutocapitalization(.never).autocorrectionDisabled()
                        if let binary = selectedBinary {
                            let raw = addressQuery.lowercased().replacingOccurrences(of: "0x", with: "")
                            let offset = Int(raw, radix: 16) ?? 0
                            Text(hexDump(binary.data, from: offset)).font(.system(size: 10, design: .monospaced)).textSelection(.enabled)
                        }
                    } else {
                        TextField("搜索当前结果", text: $search).textFieldStyle(.roundedBorder)
                            .onChange(of: search) { _ in page = 0 }
                        let items: [String] = tab == 1 ? report.symbols : tab == 2 ? report.strings : tab == 3 ? report.disassembly : tab == 4 ? report.crossReferences : report.objcMetadata
                        let filtered = search.isEmpty ? items : items.filter { $0.localizedCaseInsensitiveContains(search) }
                        let start = min(page * 200, filtered.count)
                        let end = min(start + 200, filtered.count)
                        HStack {
                            Text("显示 \(start < end ? start + 1 : 0)–\(end) / \(filtered.count) 条")
                                .font(.caption).foregroundStyle(.secondary)
                            Spacer()
                            Button("上一页") { page = max(0, page - 1) }.disabled(page == 0)
                            Button("下一页") { page += 1 }.disabled(end >= filtered.count)
                        }
                        ForEach(Array(filtered[start..<end].enumerated()), id: \.offset) { _, value in
                            Text(value).font(.system(size: 11, design: .monospaced))
                                .frame(maxWidth: .infinity, alignment: .leading).textSelection(.enabled)
                            Divider()
                        }
                    }
                }.padding(14).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
            } else {
                Text("尚未选择文件，请前往文件页选择一个 Mach-O 文件。").foregroundStyle(.secondary)
                Button("前往文件管理") { workspace = 1 }
            }
        }
    }
    private var reportPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("证据报告").font(.title2.bold())
            if let report {
                Text(activeName).font(.headline)
                Text("完整静态分析报告包含文件信息、符号、字符串、直接分支引用与 ObjC 元数据。")
                    .font(.subheadline).foregroundStyle(.secondary)
                ShareLink(item: report.exportText) {
                    Label("导出完整分析报告", systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity).padding(12)
                }.buttonStyle(.borderedProminent)
                section("分析限制", report.warnings)
            } else { Text("请先导入并选择一个文件").foregroundStyle(.secondary) }
        }
    }
    private func guidedPanel(_ report: AnalysisReport) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("一键线索分析").font(.headline)
            Text("自动筛选证据，不会将关键词命中误判为实际执行逻辑。").font(.caption).foregroundStyle(.secondary)
            Picker("研究方向", selection: $selectedTopic) {
                ForEach(GuidedAnalysis.topics) { topic in
                    Text(topic.title).tag(topic.id)
                }
            }.pickerStyle(.menu)
            if let topic = GuidedAnalysis.topics.first(where: { $0.id == selectedTopic }) {
                Text(topic.purpose).font(.subheadline)
                let matches = GuidedAnalysis.hits(report, topic: topic)
                Text("找到 \(matches.count) 条候选线索（最多展示 120 条）")
                    .font(.caption).foregroundStyle(.secondary)
                if matches.isEmpty {
                    Text("当前已解析的数据没有命中；不代表二进制中不存在相关逻辑。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                ForEach(matches) { hit in
                    VStack(alignment: .leading, spacing: 3) {
                        Text(hit.source).font(.caption2).foregroundStyle(.secondary)
                        Text(hit.value).font(.system(size: 11, design: .monospaced)).textSelection(.enabled)
                    }
                    Divider()
                }
                ShareLink(item: matches.map { "[\($0.source)] \($0.value)" }.joined(separator: "\n")) {
                    Label("导出当前线索", systemImage: "square.and.arrow.up")
                }
            }
        }
    }
    private func importBinary(_ url: URL) {
        busy = true
        importStatus = "正在导入：\(url.lastPathComponent)"
        // Document picker uses asCopy:true, so this is an app-accessible temporary copy.
        // File coordination handles iCloud / third-party document providers.
        DispatchQueue.global(qos: .userInitiated).async {
            let coordinator = NSFileCoordinator(filePresenter: nil)
            var coordinateError: NSError?
            var outcome: Result<[EmbeddedBinary], Error>?
            coordinator.coordinate(readingItemAt: url, options: [], error: &coordinateError) { readable in
                do {
                    let bytes = try Data(contentsOf: readable, options: .mappedIfSafe)
                    if bytes.isEmpty { throw ArchiveFailure.unsupported("文件为空") }
                    outcome = .success(try ArchiveReader.candidates(fileName: readable.lastPathComponent, data: bytes))
                } catch { outcome = .failure(error) }
            }
            let final = outcome ?? .failure(coordinateError ?? ArchiveFailure.unsupported("无法访问文件，请将文件保存到‘我的 iPhone’后再试"))
            DispatchQueue.main.async {
                busy = false
                switch final {
                case .success(let candidates):
                    binaries = candidates
                    report = nil
                    selectedBinary = nil
                    search = ""
                    tab = 0
                    importStatus = "已读取 \(url.lastPathComponent)，发现 \(candidates.count) 个 Mach-O 文件"
                    workspace = candidates.count > 1 ? 1 : 0
                    if candidates.isEmpty { error = "文件已导入，但没有找到可分析的 Mach-O。若为 xz/zstd 压缩的 DEB，请先解压提取 dylib。" }
                    if candidates.count == 1, let first = candidates.first {
                        do {
                            report = try MachOAnalyzer.analyze(first.data, name: first.path)
                            selectedBinary = first
                        } catch { self.error = "Mach-O 解析失败：\(error.localizedDescription)" }
                    }
                case .failure(let failure):
                    self.error = "导入失败：\(failure.localizedDescription)"
                    importStatus = "导入失败：\(url.lastPathComponent)"
                }
            }
        }
    }
    private func hexDump(_ data: Data, from requested: Int) -> String {
        guard !data.isEmpty else { return "空文件" }
        let start = max(0, min(requested, data.count - 1))
        let end = min(data.count, start + 1024)
        var lines: [String] = []
        for pos in stride(from: start, to: end, by: 16) {
            let chunk = data[pos..<min(end, pos + 16)]
            let hex = chunk.map { String(format: "%02X", $0) }.joined(separator: " ")
            let ascii = chunk.map { ($0 >= 32 && $0 < 127) ? String(UnicodeScalar(Int($0))!) : "." }.joined()
            lines.append(String(format: "%08X", pos) + "  " + hex.padding(toLength: 47, withPad: " ", startingAt: 0) + "  " + ascii)
        }
        return lines.joined(separator: "\n")
    }
    private func metric(_ title: String, _ value: String) -> some View {
        HStack { Text(title).foregroundStyle(.secondary); Spacer(); Text(value).fontWeight(.semibold) }
    }
    private func section(_ title: String, _ values: [String]) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.headline)
            ForEach(Array(values.prefix(30).enumerated()), id: \.offset) { _, item in
                Text(item).font(.system(size: 11, design: .monospaced)).textSelection(.enabled)
            }
        }
    }
}

// Native UIDocumentPicker with broad content types; unlike a single .item filter,
// it allows Files providers to expose unknown .deb/.dylib extensions.
struct UniversalBinaryPicker: UIViewControllerRepresentable {
    let completion: (Result<URL, Error>) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completion: completion) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let types: [UTType] = [.item, .data, .content, .archive,
            UTType(filenameExtension: "deb") ?? .data,
            UTType(filenameExtension: "dylib") ?? .data,
            UTType(filenameExtension: "ipa") ?? .data]
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true)
        picker.allowsMultipleSelection = false
        picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let completion: (Result<URL, Error>) -> Void
        init(completion: @escaping (Result<URL, Error>) -> Void) { self.completion = completion }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            if let url = urls.first { completion(.success(url)) }
            else { completion(.failure(ArchiveFailure.unsupported("没有选择文件"))) }
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {}
    }
}
