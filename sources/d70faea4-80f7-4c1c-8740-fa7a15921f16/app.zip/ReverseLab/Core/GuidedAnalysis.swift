import Foundation

struct EvidenceHit: Identifiable {
    let id: String
    let source: String
    let value: String
}
struct InvestigationTopic: Identifiable {
    let id: String
    let title: String
    let purpose: String
    let terms: [String]
}
enum GuidedAnalysis {
    static let topics: [InvestigationTopic] = [
        .init(id:"island",title:"灵动岛与录屏",purpose:"查找录屏状态、SystemAperture 与岛屿宿主线索",terms:["SystemAperture","RecordingIndicator","ScreenRecording","SAUI","Aperture","isCaptured","ReplayKit"]),
        .init(id:"layout",title:"视图尺寸与宿主",purpose:"查找尺寸、位置、容器和迁移相关的静态线索",terms:["setFrame:","setBounds:","layoutSubviews","addSubview:","hostView","sceneView","setMask:","transform"]),
        .init(id:"music",title:"音乐与状态切换",purpose:"查找媒体状态与通知监听线索",terms:["MediaRemote","NowPlaying","AVPlayer","playback","applicationDidEnterBackground","Notification"]),
        .init(id:"hook",title:"注入与 Hook",purpose:"查找注入入口和运行时方法替换线索",terms:["MSHook","substrate","objc_msgSend","method_setImplementation","dlsym","SpringBoard"]),
        .init(id:"animation",title:"动画与图层",purpose:"查找旋转、路径、图层与动画线索",terms:["rotationAnimation","CABasicAnimation","setRepeatCount:","CAShapeLayer","CGPath","setCornerRadius:","addAnimation:"])
    ]
    static func hits(_ report: AnalysisReport, topic: InvestigationTopic, limit: Int = 120) -> [EvidenceHit] {
        let groups: [(String,[String])] = [
            ("符号",report.symbols),("ObjC",report.objcMetadata),("字符串",report.strings),
            ("依赖",report.dependencies),("分支",report.crossReferences)
        ]
        var result: [EvidenceHit] = []
        for (source, items) in groups {
            for (index, value) in items.enumerated() {
                if topic.terms.contains(where: { value.localizedCaseInsensitiveContains($0) }) {
                    result.append(.init(id:"\(source)-\(index)",source:source,value:value))
                    if result.count >= limit { return result }
                }
            }
        }
        return result
    }
}
