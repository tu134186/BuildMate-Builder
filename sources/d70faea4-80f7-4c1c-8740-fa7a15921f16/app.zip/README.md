# ReverseLab V3.3.0 (Build 3300)

## Changes
- Four-tab UI: Workbench, Files, Analysis, Reports.
- Compact header and file summary with concise dylib filenames; full paths in file manager.
- Separate analysis module picker, pagination, and report export.
- Fix literal `(matches.count)` count rendering in guided analysis.
- Automatically open Files tab for multi-binary DEB imports.
- Preserve V3.2.0 archive reader, Mach-O analysis core, icon and GitHub workflow.

## Limitations
- Static analysis only. No full pseudocode decompiler or function-level CFG.
- Mach-O extraction caps remain; no change to DEB xz/zstd handling.
- Swift source syntax parsing verified; no Xcode/iPhone build verification.
