ReDyne V2.1.6 / Build 12 - ARM64 Address References

Changes:
- Decode ADR/ADRP, ADD/SUB immediate and integer LDR/STR unsigned immediate before generic fallback.
- Connect conservative ADRP+ADD and ADRP+LDR register-state analysis to xref collection.
- Reset register state across branches, calls, returns, and noncontiguous instructions.
- Remove arbitrary nearest-symbol +1024 attribution.
- Preserve existing ZIP/DEB/dylib import and FAT selection.

Limitations:
- No Xcode/iPhone build was performed here; compilation and real-device validation required.
- Not a full A64 disassembler, CFG analysis, indirect stub resolver, or ObjC selector resolver.
- Some xrefs remain incomplete; counts are not correctness proof.
- ARM64E authenticated pointers and ObjC metadata references require future work.

Test: compile in BuildMate, install V2.1.6 IPA, import ios16dao.dylib directly, export HTML and share it for comparison.
