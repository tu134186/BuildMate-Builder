#import "EnhancedFilePicker.h"
#import "LCSharedUtils.h"
#import "UIKitPrivate.h"
#import "utils.h"
#import "FoundationPrivate.h"

static BOOL enhancedFilePickerActive = NO;
static void NSFMGuestHooksInit(void);

@implementation EnhancedFilePicker

+ (void)enable {
    if (enhancedFilePickerActive) {
        return;
    }

    enhancedFilePickerActive = YES;
    NSFMGuestHooksInit();
}

+ (void)disable {
    if (!enhancedFilePickerActive) {
        return;
    }

    enhancedFilePickerActive = NO;
}

+ (BOOL)isActive {
    return enhancedFilePickerActive;
}

@end

BOOL fixFilePicker;
__attribute__((constructor))
static void NSFMGuestHooksInit() {
    if (!enhancedFilePickerActive) {
        return;
    }

    fixFilePicker = YES;

    /*
    // Hook document picker initialization
    swizzle(UIDocumentPickerViewController.class,
            @selector(initForOpeningContentTypes:asCopy:),
            @selector(hook_initForOpeningContentTypes:asCopy:));

    swizzle(UIDocumentPickerViewController.class,
            @selector(initWithDocumentTypes:inMode:),
            @selector(hook_initWithDocumentTypes:inMode:));

    swizzle(UIDocumentBrowserViewController.class,
            @selector(initForOpeningContentTypes:),
            @selector(hook_initForOpeningContentTypes));

    swizzleClassMethod(UTType.class,
                      @selector(typeWithIdentifier:),
                      @selector(hook_typeWithIdentifier:));

    if (fixFilePicker) {
        swizzle(NSURL.class,
                @selector(startAccessingSecurityScopedResource),
                @selector(hook_startAccessingSecurityScopedResource));

        swizzle(UIDocumentPickerViewController.class,
                @selector(setAllowsMultipleSelection:),
                @selector(hook_setAllowsMultipleSelection:));
    }
    */
    // swizzle(DOCConfiguration.class, @selector(setHostIdentifier:), @selector(hook_setHostIdentifier:));
}



// DEB gzip member reader, using iOS system zlib.
#include <zlib.h>
void *redyne_gzip_open(const char *path) { return (void *)gzopen(path, "rb"); }
int32_t redyne_gzip_read(void *handle, uint8_t *buffer, int32_t length) {
    if (!handle || !buffer || length <= 0) return -1;
    return (int32_t)gzread((gzFile)handle, buffer, (unsigned int)length);
}
void redyne_gzip_close(void *handle) { if (handle) gzclose((gzFile)handle); }

// ZIP method 8 uses raw DEFLATE streams (no zlib or gzip wrapper).
int32_t redyne_zip_inflate(const uint8_t *input, int32_t inputLength, uint8_t *output, int32_t outputLength) {
    if (!input || !output || inputLength < 0 || outputLength < 0) return -1;
    z_stream stream = {0};
    stream.next_in = (Bytef *)input;
    stream.avail_in = (uInt)inputLength;
    stream.next_out = (Bytef *)output;
    stream.avail_out = (uInt)outputLength;
    if (inflateInit2(&stream, -MAX_WBITS) != Z_OK) return -1;
    int status = inflate(&stream, Z_FINISH);
    int32_t count = (status == Z_STREAM_END && stream.avail_in == 0 && stream.total_out == (uLong)outputLength) ? (int32_t)stream.total_out : -1;
    inflateEnd(&stream);
    return count;
}
int32_t redyne_zip_crc32_matches(const uint8_t *data, int32_t length, uint32_t expected) {
    if (length < 0 || (length > 0 && !data)) return 0;
    uLong checksum = crc32(0L, Z_NULL, 0);
    checksum = crc32(checksum, data, (uInt)length);
    return checksum == expected;
}
