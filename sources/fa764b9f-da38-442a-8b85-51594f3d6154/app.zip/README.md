# 写轮眼 V1.0.0 独立重构实验版

这是全新 `Tweak.xm`，**不是** 7119432/9436 的外围补丁。原有 7119432 的宿主选择、挂载、左侧宽度修改、刷新循环均未引入。

## 实际实现
- 从 `UIApplication -> systemApertureControllerForMainDisplay -> _systemApertureViewController -> _systemApertureManager -> registeredElements` 识别 ScreenRecording；这条链路已在旧机日志验证。
- 使用 AccessoryPortalView/AccessoryView 生命周期建立弱引用候选集合，弱引用管理思想参考 A 先生逆向。
- 每次仅维护一个 UIImageView；**直接挂在 SBSystemApertureWindow**，不挂在 17×22 / 22×22 的 Portal 叶节点，避免叶节点裁剪。
- 不再调用 `RSV711BestAccessoryHostForElement()`、`RSV6SyncEyeToElement()`，也不再改 SystemApertureContainerView 的宽度。
- 复用原工程两张 PNG、原偏好域以及 PreferenceLoader 设置界面资源。

## 实验限制（务必阅读）
- A 先生二进制尚未完整还原；这是**依据部分已确认机制的独立实现**，不是逐指令复制。
- 当前无法在本环境 Theos 编译/真机运行；构建与效果待测试。
- 窗口级叠加绕开 UIView 裁剪，但**无法遮盖真实摄像头硬件挖孔**。如果图片中心仍落在硬件区域，需要后续基于真机画面校准位置。
- 本实验版不包含旧版原生红点隐藏和细粒度暂停保留；先验证独立宿主与首次显示。可能出现系统红点同时显示，或切换期间短暂隐藏。
- 采用同一个 Package ID，会覆盖原版。请保留 7119432 的 DEB/源码用于回退。
- 如出现 SpringBoard 安全模式，卸载本版，恢复 7119432。

## 编译
将本 ZIP 交给 BuildMate 的 Theos DEB 流程；不要改变 G/C 编译工作流。

## 证据与推断边界
已验证：ScreenRecording identifier、SystemAperture controller/manager、AccessoryPortalView、A 先生 SAUIElementView 候选弱引用机制。
推断/实验：窗口级素材叠加、候选几何约束、默认左右判定、首次布局效果。
