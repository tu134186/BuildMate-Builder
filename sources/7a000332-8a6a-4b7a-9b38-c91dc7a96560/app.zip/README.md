# ReverseLab V3.0.0 — iOS 静态逆向工作台

## 真实可用的实现
- SwiftUI iOS 16+ App，AppIcon 已配置
- 文件 App 导入：使用通用项目类型，修复先前仅靠 .data/.archive 导致部分文件灰色的问题
- Mach-O ARM64/ARM64e 文件头、段、依赖库、符号、Objective-C 名称区读取
- FAT ARM64 切片提取；IPA/ZIP 解包（stored/deflate）；DEB ar + tar/gzip 解包
- 基础 ARM64 指令与直接分支交叉引用；支持搜索、文本报告导出
- 交互式十六进制查看器，支持按文件偏移定位
- GitHub Actions + XcodeGen 未签名 IPA 打包

## 重要限制（请先读）
- 尚未集成 Capstone / LLVM / Ghidra 反编译引擎；不是专业伪 C 反编译器。
- 当前 ARM64 指令解码只覆盖部分指令；交叉引用仅限直接分支。
- DEB 中的 data.tar.xz / data.tar.zst 尚不能直接解包。可先在 Filza 提取 dylib 后导入。
- IPA/DEB/二进制可能非常大，建议先导入单独 dylib。
- 本环境没有 macOS/Xcode，未完成真机或 Xcode 构建验证。

## 编译
在 GitHub 仓库根目录上传全部文件，Actions → ReverseLab IPA Build → Run workflow。
生成的 IPA 可尝试通过 TrollStore 安装。

## 版本
3.0.0 / Build 3000。请勿将该版本宣传为完整反编译器。
