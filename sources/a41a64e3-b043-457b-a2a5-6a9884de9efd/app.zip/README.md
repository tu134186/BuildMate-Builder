# ReverseLab V3.5.1 / Build 3501

## New capabilities
- ARM64 instruction decoding: ADD/SUB, MOV, MOVZ/MOVK/MOVN, LDR/STR, ADR/ADRP, LDR literal, BR/BLR/RET (selected encodings).
- Scans __text up to 32 MiB for direct branches; retains a 200,000-instruction disassembly preview for memory safety.
- Distinguishes direct CALL (BL) and BRANCH, exports up to 600,000 references.
- Adds `06_Inbound_Branches.txt` reverse target-address index for each dylib.
- Raises ASCII strings limit from 3,000 to 50,000.
- Preserves V3.4.1 file import, DEB handling, research topics and ZIP export.

## Limits
- Not a full decompiler, function boundary recovery or Objective-C call graph.
- Full disassembly beyond 200,000 lines is not exported; direct branches are scanned across the section.
- Large files can take time and memory; no macOS Xcode or device test completed.

## 3.5.1 build fix
- Correct Swift interpolation in MachOAnalyzer.swift lines 173, 179, 187 and 188.
- BuildMate workflow untouched. Xcode full build not verified.
