# ReDyne V2.0.2 CN — DEB 导入说明

在首页选择 `.deb`，应用读取 Debian ar 容器，定位 `data.tar` 或 `data.tar.gz`，遍历 tar 中的普通文件，使用 Mach-O magic 检测实际二进制（不只根据扩展名），然后弹出可选文件列表。选择后进入原有分析界面。

支持：未压缩 TAR、GZIP TAR。当前**不支持** data.tar.xz、data.tar.zst、data.tar.bz2；这类包会给出明确提示，不会误当成 Mach-O 分析。没有执行安装脚本，也不会安装 DEB。

安全限制：DEB 120 MB、解压数据 200 MB、最多 60 个 Mach-O；不会按 tar 中的路径写入文件系统，而是写到随机临时目录，避免路径穿越。

本版本未在 macOS/Xcode 或真机编译验证。原始 MIT LICENSE 保留。
