import UIKit
import UniformTypeIdentifiers
import SwiftUI
import Combine

@objc class FilePickerViewController: UIViewController {

    // MARK: - SwiftUI File Picker
    private var sceneDelegateWrapper: SceneDelegateWrapper!
    private var swiftUIFilePickerViewController: SwiftUIFilePickerViewController!

    // MARK: - UI Elements
    
    private let tableView: UITableView = {
        let table = UITableView(frame: .zero, style: .insetGrouped)
        table.translatesAutoresizingMaskIntoConstraints = false
        table.register(UITableViewCell.self, forCellReuseIdentifier: "FileCell")
        return table
    }()
    
    private let selectButton: UIButton = {
        var config = UIButton.Configuration.filled()
        config.title = "选择二进制文件"
        config.baseBackgroundColor = Constants.Colors.accentColor
        config.baseForegroundColor = .white
        config.cornerStyle = .medium
        config.contentInsets = NSDirectionalEdgeInsets(top: 16, leading: 20, bottom: 16, trailing: 20)
        
        let button = UIButton(configuration: config, primaryAction: nil)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let infoLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "选择 dylib 或 Mach-O 文件进行分析"
        label.textAlignment = .center
        label.textColor = .secondaryLabel
        label.font = .systemFont(ofSize: 14)
        label.numberOfLines = 0
        return label
    }()
    
    // MARK: - Properties
    
    private var recentFiles: [String] = []
    
    // MARK: - Properties for Scene Delegate
    private var storedSceneDelegate: SceneDelegate?

    @objc func setSceneDelegate(_ sceneDelegate: SceneDelegate) {
        print("setSceneDelegate called with sceneDelegate: \(sceneDelegate)")
        storedSceneDelegate = sceneDelegate
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "ReDyne"
        view.backgroundColor = Constants.Colors.primaryBackground

        if let sceneDelegate = storedSceneDelegate {
            print("Initializing SwiftUI file picker with scene delegate")
            sceneDelegateWrapper = SceneDelegateWrapper(sceneDelegate: sceneDelegate)
            swiftUIFilePickerViewController = SwiftUIFilePickerViewController(
                sceneDelegateWrapper: sceneDelegateWrapper,
                onFileSelected: { [weak self] url in
                    print("📁 SwiftUI file selected: \(url)")
                    self?.handleSwiftUIFileSelection(url)
                }
            )
            print("SwiftUI file picker initialized successfully")
        } else {
            print("No scene delegate available for SwiftUI file picker")
        }

        setupUI()
        setupActions()
        setupDragAndDrop()
        loadRecentFiles()
        configureFilePickerMode()

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "gear"),
            style: .plain,
            target: self,
            action: #selector(showSettings)
        )
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        presentOnboardingIfNeeded()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadRecentFiles()
        updateInfoLabel()
    }

    // MARK: - Onboarding

    private func presentOnboardingIfNeeded() {
        guard !UserDefaults.standard.bool(forKey: Constants.UserDefaultsKeys.hasCompletedOnboarding) else { return }

        let onboarding = OnboardingViewController()
        onboarding.modalPresentationStyle = .fullScreen
        onboarding.onComplete = { [weak self] trySample in
            UserDefaults.standard.set(true, forKey: Constants.UserDefaultsKeys.hasCompletedOnboarding)
            if trySample {
                self?.openSampleBinary()
            }
        }
        present(onboarding, animated: false)
    }

    private func openSampleBinary() {
        // Look for a sample Mach-O binary in the app bundle
        if let sampleURL = Bundle.main.url(forResource: "sample", withExtension: nil)
            ?? Bundle.main.url(forResource: "sample", withExtension: "dylib")
            ?? Bundle.main.url(forResource: "sample_binary", withExtension: nil) {

            // Copy to a temp directory so we have write access
            let tempDir = FileManager.default.temporaryDirectory
                .appendingPathComponent(Constants.File.tempDirectoryName, isDirectory: true)
            try? FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)

            let destination = tempDir.appendingPathComponent(sampleURL.lastPathComponent)
            try? FileManager.default.removeItem(at: destination)

            do {
                try FileManager.default.copyItem(at: sampleURL, to: destination)
                processFile(at: destination)
            } catch {
                ErrorHandler.showError(ReDyneError.invalidFile, in: self)
            }
        } else {
            let alert = UIAlertController(
                title: "Sample Binary Not Available",
                message: "Sample binary not included in this build. Use the file picker to import a Mach-O binary.",
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "确定", style: .default))
            present(alert, animated: true)
        }
    }
    
    private func updateInfoLabel() {
        let mode = UserDefaults.standard.useLegacyFilePicker ? "Legacy (Enhanced)" : "Modern"
        infoLabel.text = "选择 dylib、Mach-O 或 DEB 安装包\n支持拖放导入 · 文件选择模式：\(mode)"
    }

    private func configureFilePickerMode() {
        if UserDefaults.standard.useLegacyFilePicker {
            EnhancedFilePicker.enable()
        } else {
            EnhancedFilePicker.disable()
        }

        #if DEBUG
        Constants.logFilePickerMode()
        #endif
    }
    
    // MARK: - Setup
    
    private func setupUI() {
        view.addSubview(tableView)
        view.addSubview(selectButton)
        view.addSubview(infoLabel)
        
        tableView.delegate = self
        tableView.dataSource = self
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: selectButton.topAnchor, constant: -20),
            
            selectButton.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            selectButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            selectButton.bottomAnchor.constraint(equalTo: infoLabel.topAnchor, constant: -12),
            selectButton.heightAnchor.constraint(greaterThanOrEqualToConstant: 50),
            
            infoLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            infoLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            infoLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20)
        ])
    }
    
    private func setupActions() {
        selectButton.addTarget(self, action: #selector(selectFile), for: .touchUpInside)
    }
    
    private func setupDragAndDrop() {
        let dropInteraction = UIDropInteraction(delegate: self)
        view.addInteraction(dropInteraction)
        
        selectButton.isUserInteractionEnabled = true
    }
    
    private func loadRecentFiles() {
        recentFiles = UserDefaults.standard.getRecentFiles()
        tableView.reloadData()
    }
    
    // MARK: - Actions
    
    @objc private func selectFile() {
        if UserDefaults.standard.useLegacyFilePicker {
            print("Presenting SwiftUI file picker (Legacy mode)")
            if swiftUIFilePickerViewController != nil {
                swiftUIFilePickerViewController.presentFilePicker()
            } else {
                print("SwiftUI file picker not initialized")
                fallbackToUIKitPicker()
            }
        } else {
            print("Presenting UIKit file picker (Modern mode)")
            let contentTypes = Constants.FileTypes.binaryUTTypes()
            let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: contentTypes)
            documentPicker.delegate = self
            documentPicker.allowsMultipleSelection = false
            documentPicker.shouldShowFileExtensions = true
            present(documentPicker, animated: true)
        }
    }

    private func fallbackToUIKitPicker() {
        print("Falling back to UIKit picker")
        let contentTypes = Constants.FileTypes.binaryUTTypes()
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: contentTypes)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        documentPicker.shouldShowFileExtensions = true
        present(documentPicker, animated: true)
    }
    
    @objc private func showSettings() {
        let alert = UIAlertController(title: "设置", message: nil, preferredStyle: .actionSheet)
        let currentMode = UserDefaults.standard.useLegacyFilePicker
        let pickerTitle = currentMode ? "✓ Use Legacy File Picker (Two-Tap)" : "Use Legacy File Picker (Two-Tap)"
        alert.addAction(UIAlertAction(title: pickerTitle, style: .default) { [weak self] _ in
            self?.toggleFilePickerStyle()
        })
        
        alert.addAction(UIAlertAction(title: "Clear Recent Files", style: .destructive) { [weak self] _ in
            self?.clearRecentFiles()
        })
        
        alert.addAction(UIAlertAction(title: "About ReDyne", style: .default) { [weak self] _ in
            self?.showAbout()
        })
        
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        
        if let popover = alert.popoverPresentationController {
            popover.barButtonItem = navigationItem.rightBarButtonItem
        }
        
        present(alert, animated: true)
    }
    
    private func toggleFilePickerStyle() {
        let isLegacy = UserDefaults.standard.useLegacyFilePicker
        UserDefaults.standard.useLegacyFilePicker = !isLegacy

        configureFilePickerMode()

        let newMode = !isLegacy ? "Legacy (Enhanced)" : "Modern"
        let message = "File picker changed to \(newMode) mode.\n\nLegacy mode: Enhanced file access with broader compatibility.\nModern mode: Standard iOS file picker."

        let alert = UIAlertController(
            title: "File Picker Updated",
            message: message,
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "确定", style: .default) { [weak self] _ in
            self?.updateInfoLabel()
        })
        present(alert, animated: true)
    }
    
    private func clearRecentFiles() {
        UserDefaults.standard.clearRecentFiles()
        loadRecentFiles()
    }
    
    private func showAbout() {
        let alert = UIAlertController(
            title: "ReDyne",
            message: "A sophisticated dylib decompiler for iOS.\n\nVersion 1.0\n\nDeep Mach-O parsing, ARM64/x86_64 disassembly, control flow analysis, and pseudocode generation. (later)",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "确定", style: .default))
        present(alert, animated: true)
    }
    
    // MARK: - Debian package import

    private func openDebPackage(at url: URL) {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            let items = try DebArchiveReader.extractMachOFiles(from: url)
            let alert = UIAlertController(title: "DEB 安装包", message: "找到 \(items.count) 个 Mach-O 文件。请选择要分析的文件。", preferredStyle: .actionSheet)
            for item in items {
                alert.addAction(UIAlertAction(title: item.name, style: .default) { [weak self] _ in
                    self?.processFile(at: item.url, addToRecent: false)
                })
            }
            alert.addAction(UIAlertAction(title: "取消", style: .cancel))
            if let popover = alert.popoverPresentationController {
                popover.sourceView = selectButton
                popover.sourceRect = selectButton.bounds
            }
            present(alert, animated: true)
        } catch {
            let alert = UIAlertController(title: "无法导入 DEB", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "确定", style: .default))
            present(alert, animated: true)
        }
    }

    // MARK: - File Processing
    
    private func processFile(at url: URL, addToRecent: Bool = true) {
        if url.pathExtension.lowercased() == "deb" {
            openDebPackage(at: url)
            return
        }
        guard FileManager.default.fileExists(atPath: url.path) else {
            ErrorHandler.showError(ReDyneError.invalidFile, in: self)
            return
        }
        
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            if let fileSize = attributes[.size] as? Int64, fileSize > Constants.File.maxFileSize {
                ErrorHandler.showError(ReDyneError.fileTooLarge(size: fileSize, limit: Constants.File.maxFileSize), in: self)
                return
            }
        } catch {
            ErrorHandler.log(error)
        }
        
        if addToRecent {
            UserDefaults.standard.addRecentFile(url.path)
            loadRecentFiles()
        }
        
        let decompileVC = DecompileViewController(fileURL: url)
        navigationController?.pushViewController(decompileVC, animated: true)
    }
}

// MARK: - UITableViewDataSource

extension FilePickerViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recentFiles.isEmpty ? 1 : recentFiles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FileCell", for: indexPath)
        cell.accessoryType = .disclosureIndicator
        
        if recentFiles.isEmpty {
            cell.textLabel?.text = "No recent files"
            cell.textLabel?.textColor = .secondaryLabel
            cell.selectionStyle = .none
            cell.accessoryType = .none
        } else {
            let path = recentFiles[indexPath.row]
            cell.textLabel?.text = (path as NSString).lastPathComponent
            cell.detailTextLabel?.text = path
            cell.textLabel?.textColor = .label
            cell.selectionStyle = .default
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "最近文件"
    }
}

// MARK: - UITableViewDelegate

extension FilePickerViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        guard !recentFiles.isEmpty else { return }
        
        let path = recentFiles[indexPath.row]
        
        if let bookmarkData = UserDefaults.standard.getFileBookmark(for: path) {
            do {
                var isStale = false
                let url = try URL(
                    resolvingBookmarkData: bookmarkData,
                    options: .withoutUI,
                    relativeTo: nil,
                    bookmarkDataIsStale: &isStale
                )
                
                guard url.startAccessingSecurityScopedResource() else {
                    showFileNotFoundAlert(at: indexPath)
                    return
                }
                
                if isStale {
                    if let newBookmarkData = try? url.bookmarkData(
                        options: .minimalBookmark,
                        includingResourceValuesForKeys: nil,
                        relativeTo: nil
                    ) {
                        UserDefaults.standard.saveFileBookmark(newBookmarkData, for: path)
                    }
                }
                
                processFile(at: url, addToRecent: false)
                
                return
            } catch {
                ErrorHandler.log(error)
            }
        }
        
        let url = URL(fileURLWithPath: path)
        if FileManager.default.fileExists(atPath: path) {
            processFile(at: url, addToRecent: false)
        } else {
            showFileNotFoundAlert(at: indexPath)
        }
    }
    
    private func showFileNotFoundAlert(at indexPath: IndexPath) {
        let alert = UIAlertController(
            title: "File Not Found",
            message: "The selected file no longer exists.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Remove from Recent", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            let path = self.recentFiles[indexPath.row]
            self.recentFiles.remove(at: indexPath.row)
            UserDefaults.standard.set(self.recentFiles, forKey: Constants.UserDefaultsKeys.recentFiles)
            
            UserDefaults.standard.removeFileBookmark(for: path)
            
            self.tableView.reloadData()
        })
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        present(alert, animated: true)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete && !recentFiles.isEmpty {
            let path = recentFiles[indexPath.row]
            recentFiles.remove(at: indexPath.row)
            UserDefaults.standard.set(recentFiles, forKey: Constants.UserDefaultsKeys.recentFiles)
            
            UserDefaults.standard.removeFileBookmark(for: path)
            
            if recentFiles.isEmpty {
                tableView.reloadData()
            } else {
                tableView.deleteRows(at: [indexPath], with: .fade)
            }
        }
    }
}

// MARK: - UIDocumentPickerDelegate

extension FilePickerViewController: UIDocumentPickerDelegate {
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        
        if UserDefaults.standard.useLegacyFilePicker {
            confirmAndProcessFile(at: url)
        } else {
            showOpenConfirmation(for: url)
        }
    }
    
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
    }
    
    private func showOpenConfirmation(for url: URL) {
        let fileName = url.lastPathComponent
        let fileSize = getFileSize(at: url)
        
        let alert = UIAlertController(
            title: "Open File?",
            message: "File: \(fileName)\nSize: \(fileSize)\n\nThis will start analyzing the binary. Continue?",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "打开", style: .default) { [weak self] _ in
            self?.confirmAndProcessFile(at: url)
        })
        
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        
        present(alert, animated: true)
    }
    
    private func confirmAndProcessFile(at url: URL) {
        guard FileManager.default.fileExists(atPath: url.path) else {
            ErrorHandler.showError(ReDyneError.invalidFile, in: self)
            return
        }

        // Handle different behavior for asCopy modes
        if UserDefaults.standard.useLegacyFilePicker {
            let isInAppContainer = url.path.contains("/Containers/Data/Application/") && 
                                  (url.path.contains("-Inbox/") || url.path.contains("/Documents/"))
            
            print("🔍 File path: \(url.path)")
            print("🔍 Is in app container: \(isInAppContainer)")

            if isInAppContainer {
                print("File in app container, processing directly")
                processFile(at: url)
                return
            }
        }

        print("Attempting security-scoped resource access")
        guard url.startAccessingSecurityScopedResource() else {
            ErrorHandler.showError(ReDyneError.fileAccessDenied, in: self)
            return
        }

        do {
            let bookmarkData = try url.bookmarkData(
                options: .minimalBookmark,
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            UserDefaults.standard.saveFileBookmark(bookmarkData, for: url.path)
        } catch {
            ErrorHandler.log(error)
        }

        processFile(at: url)
    }
    
    private func getFileSize(at url: URL) -> String {
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            if let size = attributes[.size] as? Int64 {
                let formatter = ByteCountFormatter()
                formatter.allowedUnits = [.useKB, .useMB, .useGB]
                formatter.countStyle = .file
                return formatter.string(fromByteCount: size)
            }
        } catch {
            return "未知"
        }
        return "未知"
    }

    // MARK: - SwiftUI File Picker Handling

    private func handleSwiftUIFileSelection(_ url: URL) {
        confirmAndProcessFile(at: url)
    }
}

// MARK: - SwiftUI File Picker Controller

class SwiftUIFilePickerViewController {
    private var sceneDelegateWrapper: SceneDelegateWrapper
    private var onFileSelected: (URL) -> Void

    init(sceneDelegateWrapper: SceneDelegateWrapper, onFileSelected: @escaping (URL) -> Void) {
        self.sceneDelegateWrapper = sceneDelegateWrapper
        self.onFileSelected = onFileSelected
    }

    func presentFilePicker() {
        print("SwiftUIFilePickerViewController.presentFilePicker() called")
        
        let contentTypes = [UTType.item, UTType.folder]
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: contentTypes, asCopy: true)
        documentPicker.allowsMultipleSelection = false
        documentPicker.shouldShowFileExtensions = true
        
        let delegate = DocumentPickerDelegate { [weak self] urls in
            print("Document picker callback with \(urls.count) URLs")
            guard let self = self, let url = urls.first else {
                print("No URLs or self is nil")
                return
            }
            self.onFileSelected(url)
        }
        documentPicker.delegate = delegate
        
        objc_setAssociatedObject(documentPicker, "delegate", delegate, .OBJC_ASSOCIATION_RETAIN)
        
        if let rootVC = sceneDelegateWrapper.sceneDelegate?.window.rootViewController {
            print("Presenting document picker directly")
            rootVC.present(documentPicker, animated: true)
        } else {
            print("No root view controller available")
        }
    }
}

private class DocumentPickerDelegate: NSObject, UIDocumentPickerDelegate {
    private let onPick: ([URL]) -> Void
    
    init(onPick: @escaping ([URL]) -> Void) {
        self.onPick = onPick
    }
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        onPick(urls)
    }
    
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("Document picker cancelled")
    }
}

// MARK: - SwiftUI File Picker View

struct SwiftUIFilePickerView: View {
    @ObservedObject var sceneDelegateWrapper: SceneDelegateWrapper
    @State private var isPresented = false

    var onFileSelected: ([URL]) -> Void

    var body: some View {
        Color.clear
            .documentPicker(
                isPresented: $isPresented,
                types: [UTType.item, UTType.folder],
                multiple: false,
                sceneDelegateWrapper: sceneDelegateWrapper,
                onPick: onFileSelected
            )
            .onAppear {
                print("SwiftUIFilePickerView appeared, triggering presentation")
                DispatchQueue.main.async {
                    print("Setting isPresented = true")
                    isPresented = true
                }
            }
    }
}

// MARK: - UIDropInteractionDelegate

extension FilePickerViewController: UIDropInteractionDelegate {
    
    func dropInteraction(_ interaction: UIDropInteraction, canHandle session: UIDropSession) -> Bool {
        return session.hasItemsConforming(toTypeIdentifiers: [
            "public.file-url",
            "public.url",
            "public.data"
        ])
    }
    
    func dropInteraction(_ interaction: UIDropInteraction, sessionDidUpdate session: UIDropSession) -> UIDropProposal {
        return UIDropProposal(operation: .copy)
    }
    
    func dropInteraction(_ interaction: UIDropInteraction, performDrop session: UIDropSession) {
        session.loadObjects(ofClass: URL.self) { [weak self] urls in
            guard let self = self,
                  let url = urls.first as? URL else { return }
            
            DispatchQueue.main.async {
                if UserDefaults.standard.useLegacyFilePicker {
                    self.confirmAndProcessFile(at: url)
                } else {
                    self.showOpenConfirmation(for: url)
                }
            }
        }
    }
    
    func dropInteraction(_ interaction: UIDropInteraction, sessionDidEnter session: UIDropSession) {
        UIView.animate(withDuration: 0.2) {
            self.selectButton.alpha = 0.7
            self.selectButton.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
        }
    }
    
    func dropInteraction(_ interaction: UIDropInteraction, sessionDidExit session: UIDropSession) {
        UIView.animate(withDuration: 0.2) {
            self.selectButton.alpha = 1.0
            self.selectButton.transform = .identity
        }
    }
    
    func dropInteraction(_ interaction: UIDropInteraction, sessionDidEnd session: UIDropSession) {
        UIView.animate(withDuration: 0.2) {
            self.selectButton.alpha = 1.0
            self.selectButton.transform = .identity
        }
    }
}




// MARK: - DEB ar/tar reader (bounded, no shell execution)
private enum DebArchiveReader {
    struct Item { let name: String; let url: URL }
    private static let maxArchive = 120 * 1024 * 1024
    private static let maxPayload = 200 * 1024 * 1024

    static func extractMachOFiles(from url: URL) throws -> [Item] {
        let deb = try Data(contentsOf: url, options: .mappedIfSafe)
        guard deb.count <= maxArchive, deb.starts(with: Data("!<arch>\n".utf8)) else {
            throw failure("不是有效的 DEB 文件，或安装包超过 120 MB")
        }
        var offset = 8
        var payload: Data?
        var compression = ""
        while offset + 60 <= deb.count {
            let header = deb.subdata(in: offset..<(offset + 60))
            guard header[58] == 0x60 && header[59] == 0x0A else { throw failure("DEB ar 文件头损坏") }
            let name = String(decoding: header.prefix(16), as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let lengthText = String(decoding: header[48..<58], as: UTF8.self).trimmingCharacters(in: .whitespaces)
            guard let size = Int(lengthText), size >= 0, size <= deb.count - offset - 60 else { throw failure("DEB 成员长度无效") }
            let start = offset + 60
            if name.hasPrefix("data.tar") {
                payload = deb.subdata(in: start..<(start + size))
                compression = name
                break
            }
            offset = start + size + (size % 2)
        }
        guard let packed = payload else { throw failure("DEB 缺少 data.tar 数据包") }
        let tar: Data
        if compression == "data.tar" {
            tar = packed
        } else if compression == "data.tar.gz" {
            tar = try inflateGzip(packed)
        } else {
            throw failure("当前版本支持 data.tar.gz 和 data.tar；此包使用 \(compression)。XZ/Zstandard 尚未支持，请先解包后导入 dylib")
        }
        guard tar.count <= maxPayload else { throw failure("解压后的数据超过 200 MB") }
        let destination = FileManager.default.temporaryDirectory.appendingPathComponent("ReDyne-DEB-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        var cursor = 0
        var results: [Item] = []
        while cursor + 512 <= tar.count {
            let header = tar.subdata(in: cursor..<(cursor + 512))
            if header.allSatisfy({ $0 == 0 }) { break }
            let rawName = String(decoding: header[0..<100].prefix(while: { $0 != 0 }), as: UTF8.self)
            let prefix = String(decoding: header[345..<500].prefix(while: { $0 != 0 }), as: UTF8.self)
            let name = prefix.isEmpty ? rawName : prefix + "/" + rawName
            let sizeText = String(decoding: header[124..<136].prefix(while: { $0 != 0 }), as: UTF8.self).trimmingCharacters(in: .whitespaces)
            guard let size = Int(sizeText, radix: 8), size >= 0, size <= maxPayload else { throw failure("TAR 文件长度无效") }
            let start = cursor + 512
            guard size <= tar.count - start else { throw failure("TAR 内容截断") }
            let type = header[156]
            if (type == 0 || type == 48), results.count < 60 {
                let data = tar.subdata(in: start..<(start + size))
                if isMachO(data) {
                    let filename = URL(fileURLWithPath: name).lastPathComponent
                    let safeName = filename.isEmpty ? "binary" : filename
                    let fileURL = destination.appendingPathComponent(String(results.count) + "-" + safeName)
                    try data.write(to: fileURL, options: .atomic)
                    results.append(Item(name: name, url: fileURL))
                }
            }
            let blocks = (size + 511) / 512
            guard blocks <= (tar.count - start) / 512 else { throw failure("TAR 偏移无效") }
            cursor = start + blocks * 512
        }
        if results.isEmpty { throw failure("安装包中没有发现可分析的 Mach-O 文件") }
        return results
    }

    private static func isMachO(_ data: Data) -> Bool {
        guard data.count >= 4 else { return false }
        let magic = Array(data.prefix(4))
        return [[0xcf,0xfa,0xed,0xfe], [0xfe,0xed,0xfa,0xcf],
                [0xce,0xfa,0xed,0xfe], [0xfe,0xed,0xfa,0xce],
                [0xca,0xfe,0xba,0xbe], [0xbe,0xba,0xfe,0xca],
                [0xca,0xfe,0xba,0xbf], [0xbf,0xba,0xfe,0xca]].contains(magic)
    }

    private static func inflateGzip(_ packed: Data) throws -> Data {
        let path = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".gz")
        try packed.write(to: path, options: .atomic)
        defer { try? FileManager.default.removeItem(at: path) }
        guard let handle = redyne_gzip_open(path.path) else { throw failure("GZIP 解压初始化失败") }
        defer { redyne_gzip_close(handle) }
        var result = Data()
        var buffer = [UInt8](repeating: 0, count: 65536)
        while true {
            let n = redyne_gzip_read(handle, &buffer, Int32(buffer.count))
            if n < 0 { throw failure("GZIP 数据损坏") }
            if n == 0 { break }
            guard result.count + Int(n) <= maxPayload else { throw failure("GZIP 解压超出 200 MB 限制") }
            result.append(contentsOf: buffer.prefix(Int(n)))
        }
        return result
    }

    private static func failure(_ message: String) -> NSError {
        NSError(domain: "ReDyne.DEB", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
    }
}
