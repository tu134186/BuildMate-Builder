import Foundation

struct ResearchDocument {
    let path: String
    let text: String
}

enum ResearchExport {
    static func documents(_ binaries: [EmbeddedBinary], packageName: String, selectedTopic: String) -> [ResearchDocument] {
        var docs: [ResearchDocument] = []
        let selected = GuidedAnalysis.topics.first(where: { $0.id == selectedTopic }) ?? GuidedAnalysis.topics[0]
        var index = ["# ReverseLab research package", "", "Package: \(packageName)", "Mach-O count: \(binaries.count)", "Selected topic: \(selected.title)", "", "## How to use with GPT", "Upload this ZIP and ask GPT to first read 00_START_HERE.md and 01_INDEX.txt, then inspect the requested topic and binary reports. Cite actual binary name and evidence line; do not treat string matches as verified execution paths.", "", "## Limits", "Data are extracted by the current static parser. String/symbol/instruction caps may truncate results. No decompiler or dynamic tracing is included."]
        var summary: [String] = ["BINARY INDEX", "Package: \(packageName)"]
        var topicAll: [String: [String]] = [:]
        for topic in GuidedAnalysis.topics { topicAll[topic.id] = ["TOPIC: \(topic.title)", "PURPOSE: \(topic.purpose)", "Evidence below is a keyword candidate, NOT proof of runtime behavior."] }
        for (i, binary) in binaries.enumerated() {
            let base = String(format: "Binaries/%02d_%@", i+1, safeName((binary.path as NSString).lastPathComponent))
            do {
                let r = try MachOAnalyzer.analyze(binary.data, name: binary.path)
                summary += ["", "\(i+1). \(binary.path)", "   \(r.architecture) | \(r.fileType) | \(r.size) bytes", "   Symbols: \(r.symbols.count); strings: \(r.strings.count); ObjC: \(r.objcMetadata.count); branches: \(r.crossReferences.count)"]
                var overview: [String] = []
                overview.append("File: \(binary.path)")
                overview.append("Arch: \(r.architecture)")
                overview.append("Type: \(r.fileType)")
                overview.append("Size: \(r.size)")
                overview.append("Load commands: \(r.commands)")
                overview.append("")
                overview.append("SEGMENTS")
                overview.append(contentsOf: r.segments)
                overview.append("")
                overview.append("DEPENDENCIES")
                overview.append(contentsOf: r.dependencies)
                overview.append("")
                overview.append("LIMITATIONS")
                overview.append(contentsOf: r.warnings)
                docs.append(ResearchDocument(path: base + "/00_Overview.txt", text: overview.joined(separator: "\n")))
                docs.append(ResearchDocument(path: base + "/01_Symbols.txt", text: r.symbols.joined(separator: "\n")))
                docs.append(ResearchDocument(path: base + "/02_Strings.txt", text: r.strings.joined(separator: "\n")))
                docs.append(ResearchDocument(path: base + "/03_ObjC.txt", text: r.objcMetadata.joined(separator: "\n")))
                docs.append(ResearchDocument(path: base + "/04_Disassembly.txt", text: r.disassembly.joined(separator: "\n")))
                docs.append(ResearchDocument(path: base + "/05_Branch_Xrefs.txt", text: r.crossReferences.joined(separator: "\n")))
                let grouped = Dictionary(grouping: r.crossReferences) { line -> String in
                    guard let range = line.range(of: " -> ") else { return "unknown" }
                    return String(line[range.upperBound...].split(separator: " ").first ?? "unknown")
                }
                var inbound: [String] = ["DIRECT BRANCH INBOUND INDEX", "Targets are raw branch destinations, NOT recovered function boundaries.", ""]
                for target in grouped.keys.sorted() {
                    let callers = grouped[target] ?? []
                    inbound.append("\(target)  incoming=\(callers.count)")
                    inbound.append(contentsOf: callers.prefix(500))
                    if callers.count > 500 { inbound.append("... truncated target inbound list at 500") }
                }
                docs.append(ResearchDocument(path: base + "/06_Inbound_Branches.txt", text: inbound.joined(separator: "\n")))

                for topic in GuidedAnalysis.topics {
                    let hits = GuidedAnalysis.hits(r, topic: topic, limit: Int.max)
                    topicAll[topic.id, default: []].append("\n### \(binary.path) | \(hits.count) matches")
                    topicAll[topic.id, default: []].append(contentsOf: hits.map { "[\($0.source)] \($0.value)" })
                }
            } catch {
                summary += ["", "\(i+1). \(binary.path): ERROR \(error.localizedDescription)"]
            }
        }
        for topic in GuidedAnalysis.topics {
            docs.append(.init(path: "Topics/\(topic.id)_\(safeName(topic.title)).txt", text: (topicAll[topic.id] ?? []).joined(separator: "\n")))
        }
        index += ["", "## Contents", "01_INDEX.txt: all binaries", "Topics/: research topics across ALL binaries", "Binaries/: separate original extracted results for EACH binary", "", "## Data integrity", "All exported lines originate from this app's parser; no original source code is reconstructed. Binary Mach-O bytes are not included in this report ZIP."]
        docs.insert(.init(path: "01_INDEX.txt", text: summary.joined(separator: "\n")), at: 0)
        docs.insert(.init(path: "00_START_HERE.md", text: index.joined(separator: "\n")), at: 0)
        return docs
    }
    private static func safeName(_ value: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "._-"))
        let cleaned = String(value.unicodeScalars.map { allowed.contains($0) ? Character($0) : "_" })
        return String(cleaned.prefix(80))
    }
    static func createZIP(_ docs: [ResearchDocument], name: String) throws -> URL {
        let dest = FileManager.default.temporaryDirectory.appendingPathComponent("ReverseLab-\(safeName(name))-Research.zip")
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString+".zip")
        FileManager.default.createFile(atPath: tmp.path, contents: nil)
        let handle = try FileHandle(forWritingTo: tmp)
        defer { try? handle.close() }
        var central = Data()
        var position: UInt32 = 0
        var count = 0
        for doc in docs {
            let file = Data(doc.text.utf8)
            let path = Data(doc.path.utf8)
            guard file.count < Int(UInt32.max), path.count < 65535, position < UInt32.max else { throw NSError(domain: "ReverseLab", code: 2, userInfo: [NSLocalizedDescriptionKey:"报告太大，无法生成 ZIP32"]) }
            let checksum = crc32(file)
            var local = Data()
            local.put32(0x04034b50); local.put16(20); local.put16(0x0800); local.put16(0); local.put16(0); local.put16(0)
            local.put32(checksum); local.put32(UInt32(file.count)); local.put32(UInt32(file.count)); local.put16(UInt16(path.count)); local.put16(0)
            try handle.write(contentsOf: local); try handle.write(contentsOf: path); try handle.write(contentsOf: file)
            var c = Data()
            c.put32(0x02014b50); c.put16(20); c.put16(20); c.put16(0x0800); c.put16(0); c.put16(0); c.put16(0)
            c.put32(checksum); c.put32(UInt32(file.count)); c.put32(UInt32(file.count)); c.put16(UInt16(path.count)); c.put16(0); c.put16(0)
            c.put16(0); c.put16(0); c.put32(0); c.put32(position)
            c.append(path); central.append(c)
            let delta = local.count + path.count + file.count
            guard UInt64(position)+UInt64(delta) < UInt64(UInt32.max) else { throw NSError(domain:"ReverseLab",code:3,userInfo:[NSLocalizedDescriptionKey:"ZIP 超过 4GB 限制"]) }
            position += UInt32(delta); count += 1
        }
        guard central.count < Int(UInt32.max), count < 65535 else { throw NSError(domain:"ReverseLab",code:4,userInfo:[NSLocalizedDescriptionKey:"ZIP 条目过多"]) }
        try handle.write(contentsOf: central)
        var end = Data()
        end.put32(0x06054b50); end.put16(0); end.put16(0); end.put16(UInt16(count)); end.put16(UInt16(count))
        end.put32(UInt32(central.count)); end.put32(position); end.put16(0)
        try handle.write(contentsOf: end)
        try? FileManager.default.removeItem(at: dest)
        try FileManager.default.moveItem(at: tmp, to: dest)
        return dest
    }
    private static func crc32(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xffffffff
        for byte in data {
            crc ^= UInt32(byte)
            for _ in 0..<8 { crc = (crc >> 1) ^ ((crc & 1) != 0 ? 0xedb88320 : 0) }
        }
        return ~crc
    }
}
private extension Data {
    mutating func put16(_ value: UInt16) { append(UInt8(truncatingIfNeeded:value)); append(UInt8(truncatingIfNeeded:value >> 8)) }
    mutating func put32(_ value: UInt32) { put16(UInt16(truncatingIfNeeded:value)); put16(UInt16(truncatingIfNeeded:value >> 16)) }
}
