import Foundation
import UIKit

/// Generates comprehensive, professional HTML analysis reports from DecompiledOutput.
/// Phase 5, item 29 / To-Do 17.4 - Analysis Report Generation.
class ReportGenerator {

    // MARK: - Public API

    /// Generate a complete HTML analysis report from the decompiled output.
    /// - Parameters:
    ///   - output: The full DecompiledOutput model.
    ///   - fileName: Display name of the binary file.
    /// - Returns: A complete HTML document string ready to be written to a file.
    static func generateHTML(from output: DecompiledOutput, fileName: String) -> String {
        var html = htmlHeader(fileName: fileName)
        html += reportHeader(fileName: fileName, output: output)
        html += openContent()
        html += binaryOverviewSection(output: output)
        html += securityAssessmentSection(output: output)
        html += statisticsSummarySection(output: output)
        html += segmentsAndSectionsSection(output: output)
        html += symbolTableSection(output: output)
        html += reverseRelationsSection(output: output)
        html += importsSection(output: output)
        html += exportsSection(output: output)
        html += objcClassesSection(output: output)
        html += swiftTypesSection(output: output)
        html += closeContent()
        html += reportFooter()
        html += htmlFooter()
        return localizeReportHTML(html)
    }

    private static func localizeReportHTML(_ source: String) -> String {
        var html = source
        html = html.replacingOccurrences(of: ">Binary Overview<", with: ">二进制概览<")
        html = html.replacingOccurrences(of: ">Security Assessment<", with: ">安全评估<")
        html = html.replacingOccurrences(of: ">Statistics Summary<", with: ">统计汇总<")
        html = html.replacingOccurrences(of: ">Segments &amp; Sections<", with: ">段与节<")
        html = html.replacingOccurrences(of: ">Symbol Table<", with: ">符号表<")
        html = html.replacingOccurrences(of: ">Protection Indicators<", with: ">安全防护指标<")
        html = html.replacingOccurrences(of: ">Dangerous APIs Found<", with: ">检测到的高风险 API<")
        html = html.replacingOccurrences(of: ">Insecure Functions Found<", with: ">检测到的不安全函数<")
        html = html.replacingOccurrences(of: ">Architecture<", with: ">架构<")
        html = html.replacingOccurrences(of: ">Platform<", with: ">平台<")
        html = html.replacingOccurrences(of: ">File Size<", with: ">文件大小<")
        html = html.replacingOccurrences(of: ">Entry Point<", with: ">入口地址<")
        html = html.replacingOccurrences(of: ">File Type<", with: ">文件类型<")
        html = html.replacingOccurrences(of: ">Encrypted<", with: ">是否加密<")
        html = html.replacingOccurrences(of: ">Protection<", with: ">防护项目<")
        html = html.replacingOccurrences(of: ">Status<", with: ">状态<")
        html = html.replacingOccurrences(of: ">Severity<", with: ">严重程度<")
        html = html.replacingOccurrences(of: ">Detail<", with: ">详情<")
        html = html.replacingOccurrences(of: ">Function<", with: ">函数<")
        html = html.replacingOccurrences(of: ">Risk<", with: ">风险<")
        html = html.replacingOccurrences(of: ">Imported<", with: ">是否导入<")
        html = html.replacingOccurrences(of: ">Symbols (Total)<", with: ">符号总数<")
        html = html.replacingOccurrences(of: ">Symbols (Defined)<", with: ">已定义符号<")
        html = html.replacingOccurrences(of: ">Symbols (Undefined)<", with: ">未定义符号<")
        html = html.replacingOccurrences(of: ">Functions<", with: ">函数数量<")
        html = html.replacingOccurrences(of: ">Strings<", with: ">字符串<")
        html = html.replacingOccurrences(of: ">Instructions<", with: ">指令数量<")
        html = html.replacingOccurrences(of: ">Segments<", with: ">段数量<")
        html = html.replacingOccurrences(of: ">Sections<", with: ">节数量<")
        html = html.replacingOccurrences(of: ">Cross-References<", with: ">交叉引用<")
        html = html.replacingOccurrences(of: ">Linked Libraries<", with: ">链接库<")
        html = html.replacingOccurrences(of: ">Address<", with: ">地址<")
        html = html.replacingOccurrences(of: ">Name<", with: ">名称<")
        html = html.replacingOccurrences(of: ">Type<", with: ">类型<")
        html = html.replacingOccurrences(of: ">Scope<", with: ">作用域<")
        html = html.replacingOccurrences(of: ">Defined<", with: ">已定义<")
        html = html.replacingOccurrences(of: ">Undefined<", with: ">未定义<")
        html = html.replacingOccurrences(of: ">External<", with: ">外部<")
        html = html.replacingOccurrences(of: ">Present<", with: ">存在<")
        html = html.replacingOccurrences(of: ">Absent<", with: ">不存在<")
        html = html.replacingOccurrences(of: ">Uncertain<", with: ">不确定<")
        html = html.replacingOccurrences(of: ">Yes<", with: ">是<")
        html = html.replacingOccurrences(of: ">No<", with: ">否<")
        html = html.replacingOccurrences(of: ">High<", with: ">高<")
        html = html.replacingOccurrences(of: ">Medium<", with: ">中<")
        html = html.replacingOccurrences(of: ">Low<", with: ">低<")
        html = html.replacingOccurrences(of: ">Info<", with: ">提示<")
        html = html.replacingOccurrences(of: ">Critical<", with: ">严重<")
        return html
    }

    // MARK: - HTML Structure

    private static func htmlHeader(fileName: String) -> String {
        return """
        <!DOCTYPE html>
        <html lang="zh-CN">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>\(escapeHTML(fileName)) - ReDyne Analysis Report</title>
            <style>
                \(cssStyles())
            </style>
        </head>
        <body>
        <div class="report-container">
        """
    }

    private static func htmlFooter() -> String {
        return """
        </div>
        </body>
        </html>
        """
    }

    private static func openContent() -> String {
        return "<div class=\"content\">\n"
    }

    private static func closeContent() -> String {
        return "</div>\n"
    }

    // MARK: - Report Header

    private static func reportHeader(fileName: String, output: DecompiledOutput) -> String {
        let dateString = DateFormatter.reportDateFormatter.string(from: output.processingDate)
        return """
        <div class="report-header">
            <div class="report-header-brand">ReDyne</div>
            <h1>分析报告</h1>
            <div class="report-header-meta">
                <span>\(escapeHTML(fileName))</span>
                <span class="separator">|</span>
                <span>Generated \(escapeHTML(dateString))</span>
                <span class="separator">|</span>
                <span>ReDyne v2.1.7</span>
            </div>
        </div>
        """
    }

    // MARK: - Report Footer

    private static func reportFooter() -> String {
        let dateString = DateFormatter.reportDateFormatter.string(from: Date())
        return """
        <div class="report-footer">
            <p>Generated by <strong>ReDyne v2.1.7</strong> &mdash; Mach-O Binary Analysis Tool</p>
            <p>\(escapeHTML(dateString))</p>
        </div>
        """
    }

    // MARK: - Section 1: Binary Overview

    private static func binaryOverviewSection(output: DecompiledOutput) -> String {
        let header = output.header
        let arch: String
        if header.is64Bit {
            arch = "\(header.cpuType) (64-bit)"
        } else {
            arch = "\(header.cpuType) (32-bit)"
        }
        let platform = header.platformName ?? "Unknown"
        let fileSize = Constants.formatBytes(Int64(output.fileSize))
        let uuid = header.uuid ?? "N/A"
        let entryPoint: String
        if header.hasEntryPoint {
            entryPoint = Constants.formatAddress(header.entryPointAddress)
        } else {
            entryPoint = "N/A"
        }
        let pie = header.isPIE ? "Yes" : "No"
        let fileType = header.fileType

        return """
        <div class="section">
            <h2 class="section-title">Binary Overview</h2>
            <div class="info-grid">
                \(infoItem(label: "Architecture", value: escapeHTML(arch)))
                \(infoItem(label: "Platform", value: escapeHTML(platform)))
                \(infoItem(label: "File Size", value: escapeHTML(fileSize)))
                \(infoItem(label: "UUID", value: escapeHTML(uuid)))
                \(infoItem(label: "Entry Point", value: escapeHTML(entryPoint)))
                \(infoItem(label: "PIE", value: escapeHTML(pie)))
                \(infoItem(label: "File Type", value: escapeHTML(fileType)))
                \(infoItem(label: "Encrypted", value: header.isEncrypted ? "Yes" : "No"))
            </div>
        </div>
        """
    }

    // MARK: - Section 2: Security Assessment

    private static func securityAssessmentSection(output: DecompiledOutput) -> String {
        guard let posture = output.securityPosture as? SecurityPosture else {
            return """
            <div class="section">
                <h2 class="section-title">Security Assessment</h2>
                <p class="no-data">Security analysis data not available for this binary.</p>
            </div>
            """
        }

        var html = """
        <div class="section">
            <h2 class="section-title">Security Assessment</h2>
        """

        // Overall posture rating
        let postureColor = postureRatingColor(posture: posture)
        html += """
            <div class="posture-banner" style="border-left-color: \(postureColor);">
                <div class="posture-rating" style="color: \(postureColor);">\(escapeHTML(posture.postureSummary))</div>
                <div class="posture-detail">\(escapeHTML(posture.postureDetail))</div>
                <div class="posture-counts">
                    \(posture.criticalCount > 0 ? "<span class=\"count-badge critical\">\(posture.criticalCount) Critical</span>" : "")
                    \(posture.highCount > 0 ? "<span class=\"count-badge high\">\(posture.highCount) High</span>" : "")
                    \(posture.mediumCount > 0 ? "<span class=\"count-badge medium\">\(posture.mediumCount) Medium</span>" : "")
                    \(posture.lowCount > 0 ? "<span class=\"count-badge low\">\(posture.lowCount) Low</span>" : "")
                    \(posture.infoCount > 0 ? "<span class=\"count-badge info\">\(posture.infoCount) Info</span>" : "")
                </div>
            </div>
        """

        // Protection indicators table
        if !posture.findings.isEmpty {
            html += """
                <h3 class="subsection-title">Protection Indicators</h3>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Protection</th>
                                <th>Status</th>
                                <th>Severity</th>
                                <th>Detail</th>
                            </tr>
                        </thead>
                        <tbody>
            """
            for (index, finding) in posture.findings.enumerated() {
                let rowClass = index % 2 == 0 ? "row-even" : "row-odd"
                let statusClass = statusCSSClass(for: finding.status)
                let severityClass = severityCSSClass(for: finding.severity)
                html += """
                            <tr class="\(rowClass)">
                                <td><strong>\(escapeHTML(finding.name))</strong><br><span class="detail-text">\(escapeHTML(finding.findingDescription))</span></td>
                                <td><span class="status-badge \(statusClass)">\(escapeHTML(finding.statusString))</span></td>
                                <td><span class="severity-badge \(severityClass)">\(escapeHTML(finding.severityString))</span></td>
                                <td class="detail-text">\(escapeHTML(finding.detail))</td>
                            </tr>
                """
            }
            html += """
                        </tbody>
                    </table>
                </div>
            """
        }

        // Dangerous APIs
        if posture.hasDangerousAPIs {
            html += """
                <h3 class="subsection-title">Dangerous APIs Found</h3>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Function</th>
                                <th>Risk</th>
                                <th>Severity</th>
                                <th>Imported</th>
                            </tr>
                        </thead>
                        <tbody>
            """
            for (index, api) in posture.dangerousAPIs.enumerated() {
                let rowClass = index % 2 == 0 ? "row-even" : "row-odd"
                let severityClass = severityCSSClass(for: api.severity)
                html += """
                            <tr class="\(rowClass)">
                                <td><code>\(escapeHTML(api.functionName))</code></td>
                                <td>\(escapeHTML(api.riskDescription))</td>
                                <td><span class="severity-badge \(severityClass)">\(escapeHTML(api.severityString))</span></td>
                                <td>\(api.isImported ? "Yes" : "No")</td>
                            </tr>
                """
            }
            html += """
                        </tbody>
                    </table>
                </div>
            """
        }

        // Insecure functions
        if posture.hasInsecureFunctions {
            html += """
                <h3 class="subsection-title">Insecure Functions Found</h3>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Function</th>
                                <th>Risk</th>
                                <th>Severity</th>
                            </tr>
                        </thead>
                        <tbody>
            """
            for (index, fn) in posture.insecureFunctions.enumerated() {
                let rowClass = index % 2 == 0 ? "row-even" : "row-odd"
                let severityClass = severityCSSClass(for: fn.severity)
                html += """
                            <tr class="\(rowClass)">
                                <td><code>\(escapeHTML(fn.functionName))</code></td>
                                <td>\(escapeHTML(fn.riskDescription))</td>
                                <td><span class="severity-badge \(severityClass)">\(escapeHTML(fn.severityString))</span></td>
                            </tr>
                """
            }
            html += """
                        </tbody>
                    </table>
                </div>
            """
        }

        // Dangerous entitlements
        if posture.hasDangerousEntitlements {
            html += """
                <h3 class="subsection-title">Dangerous Entitlements</h3>
                <ul class="entitlement-list">
            """
            for entitlement in posture.dangerousEntitlements {
                html += "    <li><code>\(escapeHTML(entitlement))</code></li>\n"
            }
            html += "</ul>\n"
        }

        html += "</div>\n"
        return html
    }

    // MARK: - Section 3: Statistics Summary

    private static func statisticsSummarySection(output: DecompiledOutput) -> String {
        var rows: [(String, String)] = [
            ("Symbols (Total)", "\(output.totalSymbols)"),
            ("Symbols (Defined)", "\(output.definedSymbols)"),
            ("Symbols (Undefined)", "\(output.undefinedSymbols)"),
            ("Functions", "\(output.totalFunctions)"),
            ("Strings", "\(output.totalStrings)"),
            ("Instructions", "\(output.totalInstructions)"),
            ("Segments", "\(output.segments.count)"),
            ("Sections", "\(output.sections.count)")
        ]
        if output.totalImports > 0 {
            rows.append(("Imports", "\(output.totalImports)"))
        }
        if output.totalExports > 0 {
            rows.append(("Exports", "\(output.totalExports)"))
        }
        if output.totalObjCClasses > 0 {
            rows.append(("ObjC Classes", "\(output.totalObjCClasses)"))
        }
        if output.totalObjCMethods > 0 {
            rows.append(("ObjC Methods", "\(output.totalObjCMethods)"))
        }
        if output.totalXrefs > 0 {
            rows.append(("Cross-References", "\(output.totalXrefs)"))
        }
        if output.totalLinkedLibraries > 0 {
            rows.append(("Linked Libraries", "\(output.totalLinkedLibraries)"))
        }

        var html = """
        <div class="section">
            <h2 class="section-title">Statistics Summary</h2>
            <div class="stats-grid">
        """
        for (label, value) in rows {
            html += """
                <div class="stat-card">
                    <div class="stat-value">\(value)</div>
                    <div class="stat-label">\(escapeHTML(label))</div>
                </div>
            """
        }
        html += """
            </div>
        </div>
        """
        return html
    }

    // MARK: - Section 4: Segments & Sections

    private static func segmentsAndSectionsSection(output: DecompiledOutput) -> String {
        guard !output.segments.isEmpty else {
            return ""
        }

        var html = """
        <div class="section">
            <h2 class="section-title">Segments &amp; Sections</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Segment</th>
                            <th>VM Address</th>
                            <th>VM Size</th>
                            <th>File Offset</th>
                            <th>File Size</th>
                            <th>Protection</th>
                        </tr>
                    </thead>
                    <tbody>
        """

        for (index, segment) in output.segments.enumerated() {
            let rowClass = index % 2 == 0 ? "row-even" : "row-odd"
            html += """
                        <tr class="\(rowClass)">
                            <td><strong>\(escapeHTML(segment.name))</strong></td>
                            <td><code>\(Constants.formatAddress(segment.vmAddress))</code></td>
                            <td>\(Constants.formatBytes(Int64(segment.vmSize)))</td>
                            <td><code>0x\(String(format: "%llX", segment.fileOffset))</code></td>
                            <td>\(Constants.formatBytes(Int64(segment.fileSize)))</td>
                            <td><span class="prot-badge">\(escapeHTML(segment.protection))</span></td>
                        </tr>
            """

            // List sections within this segment
            let childSections = output.sections.filter { $0.segmentName == segment.name }
            for section in childSections {
                html += """
                        <tr class="\(rowClass) section-row">
                            <td class="section-indent">\(escapeHTML(section.sectionName))</td>
                            <td><code>\(Constants.formatAddress(section.address))</code></td>
                            <td>\(Constants.formatBytes(Int64(section.size)))</td>
                            <td><code>0x\(String(format: "%X", section.offset))</code></td>
                            <td></td>
                            <td></td>
                        </tr>
                """
            }
        }

        html += """
                    </tbody>
                </table>
            </div>
        </div>
        """
        return html
    }

    // MARK: - Section 5: Symbol Table

    private static func symbolTableSection(output: DecompiledOutput) -> String {
        guard !output.symbols.isEmpty else {
            return ""
        }

        let sortedSymbols = output.symbols.sortedByAddress()
        let maxSymbols = 3000
        let displaySymbols = Array(sortedSymbols.prefix(maxSymbols))
        let totalCount = output.symbols.count
        let truncated = totalCount > maxSymbols

        var html = """
        <div class="section">
            <h2 class="section-title">符号表\(truncated ? "（展示前 \(maxSymbols) / \(totalCount)）" : "（\(totalCount)）")</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Address</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Scope</th>
                        </tr>
                    </thead>
                    <tbody>
        """

        for (index, symbol) in displaySymbols.enumerated() {
            let rowClass = index % 2 == 0 ? "row-even" : "row-odd"
            let displayName = symbol.demangledName ?? symbol.name
            html += """
                        <tr class="\(rowClass)">
                            <td><code>\(Constants.formatAddress(symbol.address))</code></td>
                            <td class="symbol-name">\(escapeHTML(displayName))</td>
                            <td><span class="type-badge">\(escapeHTML(symbol.type))</span></td>
                            <td>\(escapeHTML(symbol.scope))</td>
                        </tr>
            """
        }

        if truncated {
            html += """
                        <tr class="truncation-row">
                            <td colspan="4">... and \(totalCount - maxSymbols) more symbols not shown</td>
                        </tr>
            """
        }

        html += """
                    </tbody>
                </table>
            </div>
        </div>
        """
        return html
    }

    // MARK: - Reverse engineering relationships (bounded export)
    // All addresses and references below come from the existing analysis engine.
    // Do not label a string hit as a confirmed hook or infer missing edges.
    private static func reverseRelationsSection(output: DecompiledOutput) -> String {
        let keywords = ["SystemAperture", "SAUI", "ScreenRecording", "RecordingIndicator",
                        "NowPlaying", "MSHook", "SpringBoard", "DynamicIsland", "Aperture"]
        func matches(_ value: String) -> Bool {
            return keywords.contains { value.localizedCaseInsensitiveContains($0) }
        }
        let relevantSymbols = output.symbols.filter { matches($0.name) || matches($0.demangledName ?? "") }
        let relevantStrings = output.strings.filter { matches($0.content) }
        var html = """
        <div class="section">
            <h2 class="section-title">逆向线索与调用关系</h2>
            <p class="detail-text">以下为静态分析线索。名称匹配不代表确认 Hook；交叉引用不等于运行时调用。仅导出有依据的数据，限制每张表的行数以控制报告体积。</p>
            <h3 class="subsection-title">关键符号（\(relevantSymbols.count) 项）</h3>
            <div class="table-container"><table><thead><tr><th>地址</th><th>符号名称</th><th>类型</th></tr></thead><tbody>
        """
        for symbol in relevantSymbols.prefix(300) {
            html += "<tr><td><code>\(Constants.formatAddress(symbol.address))</code></td><td class=\"symbol-name\">\(escapeHTML(symbol.demangledName ?? symbol.name))</td><td>\(escapeHTML(symbol.type))</td></tr>"
        }
        if relevantSymbols.isEmpty { html += "<tr><td colspan=\"3\">未找到匹配符号（不代表二进制未使用相关功能）</td></tr>" }
        html += "</tbody></table></div>"
        html += "<h3 class=\"subsection-title\">关键字符串（\(relevantStrings.count) 项）</h3><div class=\"table-container\"><table><thead><tr><th>地址</th><th>字符串</th><th>节</th></tr></thead><tbody>"
        for item in relevantStrings.prefix(300) {
            html += "<tr><td><code>\(Constants.formatAddress(item.address))</code></td><td class=\"symbol-name\">\(escapeHTML(String(item.content.prefix(500))))</td><td>\(escapeHTML(item.section))</td></tr>"
        }
        if relevantStrings.isEmpty { html += "<tr><td colspan=\"3\">未找到匹配字符串</td></tr>" }
        html += "</tbody></table></div>"

        if let analysis = output.xrefAnalysis as? XrefAnalysisResult {
            // Mach-O addresses here are VM addresses in the selected architecture slice.
            // An instruction normally lives *inside* its owner function, not at its entry.
            let orderedFunctions = output.functions.sorted { $0.startAddress < $1.startAddress }
            func owner(_ address: UInt64) -> String {
                var low = 0
                var high = orderedFunctions.count
                while low < high {
                    let middle = low + (high - low) / 2
                    if orderedFunctions[middle].startAddress <= address { low = middle + 1 }
                    else { high = middle }
                }
                guard low > 0 else { return "" }
                let candidate = orderedFunctions[low - 1]
                guard address >= candidate.startAddress && address < candidate.endAddress else { return "" }
                return candidate.demangledName ?? candidate.name
            }
            // Only defined symbols with meaningful addresses are exact symbol targets.
            let symbolAddresses = Set(relevantSymbols.filter { $0.address != 0 }.map { $0.address })
            let stringRanges: [(UInt64, UInt64)] = relevantStrings.compactMap { item in
                let length = UInt64(item.content.utf8.count + 1)
                guard length > 0, item.address <= UInt64.max - length else { return nil }
                return (item.address, item.address + length)
            }
            func relevantTarget(_ address: UInt64) -> Bool {
                if symbolAddresses.contains(address) { return true }
                return stringRanges.contains { address >= $0.0 && address < $0.1 }
            }
            let targeted = analysis.allXrefs.filter { ref in
                relevantTarget(ref.toAddress) || relevantTarget(ref.fromAddress) ||
                matches(ref.fromSymbol) || matches(ref.toSymbol) ||
                matches(owner(ref.fromAddress)) || matches(owner(ref.toAddress))
            }
            html += "<h3 class=\"subsection-title\">关联交叉引用（\(targeted.count) 项）</h3><p class=\"detail-text\">函数归属仅采用已识别的函数范围；未识别时明确标记，不推测最近函数。</p><div class=\"table-container\"><table><thead><tr><th>来源地址</th><th>所属函数</th><th>目标地址</th><th>目标函数</th><th>类型</th><th>指令</th></tr></thead><tbody>"
            for ref in targeted.prefix(1200) {
                let sourceName = owner(ref.fromAddress)
                let targetName = owner(ref.toAddress)
                html += "<tr><td><code>\(Constants.formatAddress(ref.fromAddress))</code></td><td>\(escapeHTML(sourceName.isEmpty ? (ref.fromSymbol.isEmpty ? "未识别函数边界" : ref.fromSymbol) : sourceName))</td><td><code>\(Constants.formatAddress(ref.toAddress))</code></td><td>\(escapeHTML(targetName.isEmpty ? ref.toSymbol : targetName))</td><td>\(escapeHTML(ref.xrefType.displayName))</td><td><code>\(escapeHTML(ref.instruction))</code></td></tr>"
            }
            if targeted.isEmpty { html += "<tr><td colspan=\"6\">尚未建立关键地址的直接引用；ARM64E 的 ADRP+ADD、GOT 和间接 BLR 仍需单独解析</td></tr>" }
            // Cluster unattributed reference sites by address proximity. These are
            // investigation windows, NOT inferred functions or call graph edges.
            let unknownSites = Array(Set(targeted.filter { owner($0.fromAddress).isEmpty }.map { $0.fromAddress })).sorted()
            var windows: [(UInt64, UInt64, Int)] = []
            for address in unknownSites {
                if let last = windows.last, address >= last.1 && address - last.1 <= 0x100 {
                    windows[windows.count - 1] = (last.0, address, last.2 + 1)
                } else {
                    windows.append((address, address, 1))
                }
            }
            html += "<h3 class=\"subsection-title\">未识别函数边界的引用区域（\(unknownSites.count) 个地址）</h3>"
            html += "<p class=\"detail-text\">以下仅按指令地址相距不超过 0x100 分组，供进一步核查；分组边界不代表真实函数入口或结束地址。</p>"
            html += "<div class=\"table-container\"><table><thead><tr><th>首个引用地址</th><th>最后引用地址</th><th>不同引用位置</th><th>结论</th></tr></thead><tbody>"
            for window in windows.prefix(200) {
                html += "<tr><td><code>\(Constants.formatAddress(window.0))</code></td><td><code>\(Constants.formatAddress(window.1))</code></td><td>\(window.2)</td><td>函数边界待识别</td></tr>"
            }
            if windows.isEmpty { html += "<tr><td colspan=\"4\">本次关键引用均已落入已识别函数范围</td></tr>" }
            html += "</tbody></table></div>"
            html += "</tbody></table></div>"
            let calls = analysis.allXrefs.filter { $0.xrefType == .call }
            html += "<h3 class=\"subsection-title\">调用边示例（总计 \(calls.count)，展示前 300 项）</h3><div class=\"table-container\"><table><thead><tr><th>调用指令地址</th><th>所属函数</th><th>目标地址</th><th>目标函数</th><th>指令</th></tr></thead><tbody>"
            for ref in calls.prefix(300) {
                let sourceName = owner(ref.fromAddress)
                let targetName = owner(ref.toAddress)
                html += "<tr><td><code>\(Constants.formatAddress(ref.fromAddress))</code></td><td>\(escapeHTML(sourceName.isEmpty ? (ref.fromSymbol.isEmpty ? "未识别函数边界" : ref.fromSymbol) : sourceName))</td><td><code>\(Constants.formatAddress(ref.toAddress))</code></td><td>\(escapeHTML(targetName.isEmpty ? ref.toSymbol : targetName))</td><td><code>\(escapeHTML(ref.instruction))</code></td></tr>"
            }
            html += "</tbody></table></div>"
            html += "<p class=\"detail-text\">调用边为静态分析推断，间接调用可能没有真实目标地址；函数归属依据已识别的入口与结束范围，不能视为已确认 Hook。</p>"
        } else {
            html += "<p class=\"no-data\">本次分析未提供交叉引用数据，无法生成调用关系。</p>"
        }
        html += "<h3 class=\"subsection-title\">函数入口（展示前 300 项）</h3><div class=\"table-container\"><table><thead><tr><th>入口地址</th><th>结束地址</th><th>函数名称</th></tr></thead><tbody>"
        for function in output.functions.prefix(300) {
            html += "<tr><td><code>\(Constants.formatAddress(function.startAddress))</code></td><td><code>\(Constants.formatAddress(function.endAddress))</code></td><td>\(escapeHTML(function.demangledName ?? function.name))</td></tr>"
        }
        if output.functions.isEmpty { html += "<tr><td colspan=\"3\">当前分析未返回函数明细</td></tr>" }
        html += "</tbody></table></div></div>"
        return html
    }

    // MARK: - Section 6: Imports

    private static func importsSection(output: DecompiledOutput) -> String {
        guard let analysis = output.importExportAnalysis as? ImportExportAnalysis,
              !analysis.imports.isEmpty else {
            return ""
        }

        let imports = analysis.imports.sortedByName()

        var html = """
        <div class="section">
            <h2 class="section-title">Imports (\(imports.count))</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Library</th>
                        </tr>
                    </thead>
                    <tbody>
        """

        for (index, imp) in imports.enumerated() {
            let rowClass = index % 2 == 0 ? "row-even" : "row-odd"
            html += """
                        <tr class="\(rowClass)">
                            <td><code>\(escapeHTML(imp.displayName))</code>\(imp.isWeak ? " <span class=\"weak-badge\">weak</span>" : "")</td>
                            <td>\(escapeHTML(imp.libraryName))</td>
                        </tr>
            """
        }

        html += """
                    </tbody>
                </table>
            </div>
        </div>
        """
        return html
    }

    // MARK: - Section 7: Exports

    private static func exportsSection(output: DecompiledOutput) -> String {
        guard let analysis = output.importExportAnalysis as? ImportExportAnalysis,
              !analysis.exports.isEmpty else {
            return ""
        }

        let exports = analysis.exports.sortedByName()

        var html = """
        <div class="section">
            <h2 class="section-title">Exports (\(exports.count))</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Address</th>
                        </tr>
                    </thead>
                    <tbody>
        """

        for (index, exp) in exports.enumerated() {
            let rowClass = index % 2 == 0 ? "row-even" : "row-odd"
            html += """
                        <tr class="\(rowClass)">
                            <td><code>\(escapeHTML(exp.displayName))</code></td>
                            <td><code>\(Constants.formatAddress(exp.address))</code></td>
                        </tr>
            """
        }

        html += """
                    </tbody>
                </table>
            </div>
        </div>
        """
        return html
    }

    // MARK: - Section 8: ObjC Classes

    private static func objcClassesSection(output: DecompiledOutput) -> String {
        guard let objcResult = output.objcAnalysis as? ObjCAnalysisResult,
              !objcResult.classes.isEmpty else {
            return ""
        }

        let classes = objcResult.classes.sortedByName()

        var html = """
        <div class="section">
            <h2 class="section-title">Objective-C Classes (\(classes.count))</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Class</th>
                            <th>Superclass</th>
                            <th>Methods</th>
                            <th>Properties</th>
                            <th>Protocols</th>
                        </tr>
                    </thead>
                    <tbody>
        """

        for (index, cls) in classes.enumerated() {
            let rowClass = index % 2 == 0 ? "row-even" : "row-odd"
            let protocols = cls.protocols.isEmpty ? "-" : cls.protocols.joined(separator: ", ")
            html += """
                        <tr class="\(rowClass)">
                            <td><strong>\(escapeHTML(cls.name))</strong>\(cls.isSwift ? " <span class=\"swift-badge\">Swift</span>" : "")</td>
                            <td>\(escapeHTML(cls.superclassName.isEmpty ? "-" : cls.superclassName))</td>
                            <td>\(cls.totalMethods)</td>
                            <td>\(cls.properties.count)</td>
                            <td class="detail-text">\(escapeHTML(protocols))</td>
                        </tr>
            """
        }

        html += """
                    </tbody>
                </table>
            </div>
        </div>
        """
        return html
    }

    // MARK: - Section 9: Swift Types

    private static func swiftTypesSection(output: DecompiledOutput) -> String {
        guard let swiftMeta = output.swiftMetadata as? SwiftMetadataAnalysis,
              swiftMeta.hasSwiftMetadata,
              !swiftMeta.types.isEmpty else {
            return ""
        }

        let types = swiftMeta.types.sorted { $0.name < $1.name }

        var html = """
        <div class="section">
            <h2 class="section-title">Swift Types (\(types.count))</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Kind</th>
                            <th>Fields</th>
                            <th>Generic</th>
                            <th>VTable</th>
                        </tr>
                    </thead>
                    <tbody>
        """

        for (index, type) in types.enumerated() {
            let rowClass = index % 2 == 0 ? "row-even" : "row-odd"
            html += """
                        <tr class="\(rowClass)">
                            <td><strong>\(escapeHTML(type.name))</strong></td>
                            <td><span class="kind-badge">\(escapeHTML(type.kindString))</span></td>
                            <td>\(type.fieldCount)</td>
                            <td>\(type.isGeneric ? "Yes" : "No")</td>
                            <td>\(type.hasVTable ? "Yes" : "No")</td>
                        </tr>
            """
        }

        html += """
                    </tbody>
                </table>
            </div>
        </div>
        """
        return html
    }

    // MARK: - HTML Helpers

    private static func infoItem(label: String, value: String) -> String {
        return """
            <div class="info-item">
                <div class="info-label">\(label)</div>
                <div class="info-value">\(value)</div>
            </div>
        """
    }

    private static func escapeHTML(_ string: String) -> String {
        return string
            .replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
    }

    private static func postureRatingColor(posture: SecurityPosture) -> String {
        if posture.criticalCount > 0 { return "#dc3545" }
        if posture.highCount > 0 { return "#e67e22" }
        if posture.mediumCount > 0 { return "#f39c12" }
        if posture.lowCount > 0 { return "#3498db" }
        return "#27ae60"
    }

    private static func statusCSSClass(for status: SecurityIndicatorStatus) -> String {
        switch status {
        case .present:       return "status-present"
        case .absent:        return "status-absent"
        case .uncertain:     return "status-uncertain"
        case .notApplicable: return "status-na"
        @unknown default:    return "status-uncertain"
        }
    }

    private static func severityCSSClass(for severity: SecurityFindingSeverity) -> String {
        switch severity {
        case .info:     return "sev-info"
        case .low:      return "sev-low"
        case .medium:   return "sev-medium"
        case .high:     return "sev-high"
        case .critical: return "sev-critical"
        @unknown default: return "sev-info"
        }
    }

    // MARK: - CSS Styles

    private static func cssStyles() -> String {
        return """
        /* Reset */
        *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, Helvetica, Arial, sans-serif;
            background: #f0f2f5;
            color: #1a1a2e;
            line-height: 1.6;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        .report-container {
            max-width: 1200px;
            margin: 24px auto;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            overflow: hidden;
        }

        /* Header */
        .report-header {
            background: linear-gradient(135deg, #16213e 0%, #0f3460 50%, #1a1a2e 100%);
            color: #ffffff;
            padding: 48px 40px 36px 40px;
            text-align: center;
        }
        .report-header-brand {
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 4px;
            text-transform: uppercase;
            color: #e94560;
            margin-bottom: 8px;
        }
        .report-header h1 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 16px;
            letter-spacing: -0.5px;
        }
        .report-header-meta {
            font-size: 13px;
            color: rgba(255,255,255,0.7);
        }
        .report-header-meta .separator {
            margin: 0 12px;
            opacity: 0.4;
        }

        /* Content */
        .content {
            padding: 32px 40px;
        }

        /* Sections */
        .section {
            margin-bottom: 40px;
            page-break-inside: avoid;
        }
        .section-title {
            font-size: 20px;
            font-weight: 700;
            color: #0f3460;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e94560;
        }
        .subsection-title {
            font-size: 16px;
            font-weight: 600;
            color: #16213e;
            margin: 24px 0 12px 0;
        }

        /* Info Grid */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 12px;
        }
        .info-item {
            background: #f8f9fb;
            padding: 14px 16px;
            border-radius: 8px;
            border-left: 3px solid #0f3460;
        }
        .info-label {
            font-size: 11px;
            font-weight: 700;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 4px;
        }
        .info-value {
            font-size: 15px;
            font-weight: 500;
            color: #1a1a2e;
            font-family: 'SF Mono', 'Menlo', 'Monaco', 'Courier New', monospace;
            word-break: break-all;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
            gap: 12px;
        }
        .stat-card {
            background: linear-gradient(135deg, #0f3460, #16213e);
            color: #ffffff;
            padding: 20px 16px;
            border-radius: 10px;
            text-align: center;
        }
        .stat-value {
            font-size: 28px;
            font-weight: 800;
            line-height: 1.1;
            margin-bottom: 4px;
        }
        .stat-label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.8;
        }

        /* Tables */
        .table-container {
            overflow-x: auto;
            border-radius: 8px;
            border: 1px solid #e0e4e8;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }
        thead {
            background: #16213e;
            color: #ffffff;
        }
        th {
            padding: 10px 14px;
            text-align: left;
            font-weight: 600;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            white-space: nowrap;
        }
        td {
            padding: 8px 14px;
            border-bottom: 1px solid #f0f2f5;
            vertical-align: top;
        }
        .row-even { background: #ffffff; }
        .row-odd  { background: #f8f9fb; }
        tbody tr:hover { background: #eef1f6; }
        .truncation-row td {
            text-align: center;
            color: #6c757d;
            font-style: italic;
            padding: 12px;
        }

        /* Section rows (nested sections inside segments) */
        .section-row td { font-size: 12px; color: #6c757d; }
        .section-indent { padding-left: 32px !important; }

        /* Code / mono */
        code {
            font-family: 'SF Mono', 'Menlo', 'Monaco', 'Courier New', monospace;
            font-size: 12px;
            background: #f0f2f5;
            padding: 1px 5px;
            border-radius: 3px;
            word-break: break-all;
        }
        .symbol-name {
            font-family: 'SF Mono', 'Menlo', 'Monaco', 'Courier New', monospace;
            font-size: 12px;
            word-break: break-all;
            max-width: 500px;
        }
        .detail-text {
            font-size: 12px;
            color: #6c757d;
        }

        /* Security Posture Banner */
        .posture-banner {
            background: #f8f9fb;
            border-left: 5px solid #27ae60;
            border-radius: 8px;
            padding: 20px 24px;
            margin-bottom: 20px;
        }
        .posture-rating {
            font-size: 22px;
            font-weight: 800;
            margin-bottom: 6px;
        }
        .posture-detail {
            font-size: 14px;
            color: #495057;
            margin-bottom: 12px;
        }
        .posture-counts {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        .count-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 700;
        }
        .count-badge.critical { background: #f8d7da; color: #721c24; }
        .count-badge.high     { background: #fce4cc; color: #7c4a15; }
        .count-badge.medium   { background: #fff3cd; color: #856404; }
        .count-badge.low      { background: #d1ecf1; color: #0c5460; }
        .count-badge.info     { background: #e2e3e5; color: #383d41; }

        /* Status & Severity Badges */
        .status-badge, .severity-badge {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 600;
            white-space: nowrap;
        }
        .status-present   { background: #d4edda; color: #155724; }
        .status-absent    { background: #f8d7da; color: #721c24; }
        .status-uncertain { background: #fff3cd; color: #856404; }
        .status-na        { background: #e2e3e5; color: #383d41; }

        .sev-info     { background: #e2e3e5; color: #383d41; }
        .sev-low      { background: #d1ecf1; color: #0c5460; }
        .sev-medium   { background: #fff3cd; color: #856404; }
        .sev-high     { background: #fce4cc; color: #7c4a15; }
        .sev-critical { background: #f8d7da; color: #721c24; }

        /* Misc badges */
        .type-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 8px;
            font-size: 11px;
            font-weight: 600;
            background: #e8eaf6;
            color: #283593;
        }
        .prot-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 8px;
            font-size: 11px;
            font-weight: 600;
            background: #e0f2f1;
            color: #00695c;
            font-family: 'SF Mono', 'Menlo', monospace;
        }
        .kind-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 8px;
            font-size: 11px;
            font-weight: 600;
            background: #fce4ec;
            color: #880e4f;
        }
        .swift-badge {
            display: inline-block;
            padding: 1px 6px;
            border-radius: 6px;
            font-size: 10px;
            font-weight: 700;
            background: #ff6f00;
            color: #ffffff;
        }
        .weak-badge {
            display: inline-block;
            padding: 1px 6px;
            border-radius: 6px;
            font-size: 10px;
            font-weight: 600;
            background: #fff3cd;
            color: #856404;
        }

        /* Entitlement List */
        .entitlement-list {
            list-style: none;
            padding: 0;
        }
        .entitlement-list li {
            padding: 8px 14px;
            background: #fff5f5;
            border-left: 3px solid #dc3545;
            border-radius: 4px;
            margin-bottom: 6px;
            font-size: 13px;
        }

        /* No Data */
        .no-data {
            color: #6c757d;
            font-style: italic;
            padding: 20px;
            text-align: center;
            background: #f8f9fb;
            border-radius: 8px;
        }

        /* Footer */
        .report-footer {
            background: #f8f9fb;
            padding: 20px 40px;
            text-align: center;
            color: #6c757d;
            font-size: 12px;
            border-top: 1px solid #e0e4e8;
        }
        .report-footer p { margin-bottom: 4px; }

        /* Print Media Query */
        @media print {
            body { background: #ffffff; }
            .report-container {
                margin: 0;
                box-shadow: none;
                border-radius: 0;
            }
            .report-header {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .section { page-break-inside: avoid; }
            .table-container { overflow: visible; }
            thead {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .stat-card {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .content { padding: 20px; }
            .report-header { padding: 32px 20px 24px 20px; }
            .report-header h1 { font-size: 24px; }
            .info-grid { grid-template-columns: 1fr; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .report-header-meta .separator { display: none; }
            .report-header-meta span { display: block; margin-bottom: 2px; }
        }
        """
    }
}
