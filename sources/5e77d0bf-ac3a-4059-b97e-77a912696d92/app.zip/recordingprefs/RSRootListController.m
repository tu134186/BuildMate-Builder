#import <UIKit/UIKit.h>
#import <math.h>
#import <CoreFoundation/CoreFoundation.h>
#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <Preferences/PSSliderTableCell.h>
#import <objc/message.h>

static NSString * const RSNotification = @"com.tu.recordingsharingan.settings.changed";
static NSString * const RSDomain = @"com.tu.recordingsharingan.settings";
static void RSWrite(NSString *key, id value) {
    CFPreferencesSetAppValue((__bridge CFStringRef)key, (__bridge CFPropertyListRef)value, (__bridge CFStringRef)RSDomain);
    CFPreferencesAppSynchronize((__bridge CFStringRef)RSDomain);
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(), (__bridge CFStringRef)RSNotification, NULL, NULL, YES);
}
@interface RSStepSliderCell : PSSliderTableCell
@property(nonatomic,strong) UIButton *minusButton;
@property(nonatomic,strong) UIButton *plusButton;
@end
@implementation RSStepSliderCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)identifier specifier:(PSSpecifier *)specifier {
    self = [super initWithStyle:style reuseIdentifier:identifier specifier:specifier];
    if (self) {
        _minusButton = [UIButton buttonWithType:UIButtonTypeSystem];
        _plusButton = [UIButton buttonWithType:UIButtonTypeSystem];
        for (UIButton *button in @[_minusButton,_plusButton]) {
            button.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
            button.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1];
            button.layer.cornerRadius = 4;
            [self.contentView addSubview:button];
        }
        [_minusButton setTitle:@"−" forState:UIControlStateNormal];
        [_plusButton setTitle:@"+" forState:UIControlStateNormal];
        [_minusButton addTarget:self action:@selector(decrement) forControlEvents:UIControlEventTouchUpInside];
        [_plusButton addTarget:self action:@selector(increment) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    UISlider *slider = nil;
    for (UIView *view in self.contentView.subviews) if ([view isKindOfClass:[UISlider class]]) { slider=(UISlider *)view; break; }
    if (!slider) return;
    CGRect f=slider.frame;
    CGFloat w=self.contentView.bounds.size.width;
    // Keep the native slider's vertical placement and leave room for step buttons.
    CGFloat buttonSize=22;
    _minusButton.frame=CGRectMake(MAX(8,CGRectGetMinX(f)-buttonSize-5),CGRectGetMidY(f)-11,buttonSize,buttonSize);
    _plusButton.frame=CGRectMake(MIN(w-buttonSize-45,CGRectGetMaxX(f)+4),CGRectGetMidY(f)-11,buttonSize,buttonSize);
    CGFloat start=CGRectGetMaxX(_minusButton.frame)+5;
    CGFloat end=CGRectGetMinX(_plusButton.frame)-5;
    if (end>start+45) slider.frame=CGRectMake(start,f.origin.y,end-start,f.size.height);
}
- (void)decrement { [self change:-1]; }
- (void)increment { [self change:1]; }
- (void)change:(NSInteger)direction {
    NSString *key=[self.specifier propertyForKey:@"key"];
    if (!key) return;
    double step=[[self.specifier propertyForKey:@"step"] doubleValue]; if(step<=0)step=0.5;
    double lo=[[self.specifier propertyForKey:@"min"] doubleValue];
    double hi=[[self.specifier propertyForKey:@"max"] doubleValue];
    CFPropertyListRef current=CFPreferencesCopyAppValue((__bridge CFStringRef)key,(__bridge CFStringRef)RSDomain);
    double value=current ? [(__bridge id)current doubleValue] : [[self.specifier propertyForKey:@"default"] doubleValue];
    if(current)CFRelease(current);
    value=MIN(hi,MAX(lo,round((value+direction*step)/step)*step));
    RSWrite(key,@(value));
    UISlider *slider=nil;
    for(UIView *view in self.contentView.subviews)if([view isKindOfClass:[UISlider class]]){slider=(UISlider *)view;break;}
    if(slider){[slider setValue:value animated:YES];[slider sendActionsForControlEvents:UIControlEventValueChanged];}
}
@end
@interface RSRootListController : PSListController @end
@implementation RSRootListController
- (NSArray *)specifiers {
    if (!_specifiers) _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    return _specifiers;
}
- (void)showHelp {
    NSString *message=@"启用插件：控制录屏写轮眼显示。\n\n写轮眼素材：选择素材 1 或素材 2。\n\n旋转速度：调整写轮眼旋转速度。\n\n单独录屏岛左侧扩宽：调整原生灵动岛录屏容器左边缘，默认扩宽 7pt，右边缘保持不变；不作用于音乐独立岛。\n\n单独录屏水平偏移：仅用于单独录屏，默认向右 5.5pt，不影响音乐独立岛。\n\n左侧水平偏移：调整音乐等非单独录屏场景的左侧素材，点 + 向右移动 0.5pt，点 − 向左移动 0.5pt。\n\n右侧水平偏移：单独调整右侧素材。\n\n上下位置偏移：同时调整上下位置。\n\n左侧动画大小／右侧动画大小：分别调整两侧素材尺寸。\n\n恢复默认参数：恢复推荐数值，不改变素材选择。";
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"插件功能详细说明" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"明白了" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)resetDefaults {
    NSDictionary *values=@{@"rotationSpeed":@1.0,@"leftXOffset":@(-0.5),@"soloXOffset":@5.5,@"soloIslandWidthExtra":@7.0,@"rightXOffset":@0.0,@"yOffset":@0.0,@"leftSize":@31.0,@"rightSize":@37.0};
    for(NSString *key in values)CFPreferencesSetAppValue((__bridge CFStringRef)key,(__bridge CFPropertyListRef)values[key],(__bridge CFStringRef)RSDomain);
    CFPreferencesAppSynchronize((__bridge CFStringRef)RSDomain);
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),(__bridge CFStringRef)RSNotification,NULL,NULL,YES);
    [self reloadSpecifiers];
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"已恢复" message:@"写轮眼参数已恢复为默认值。" preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
@end
